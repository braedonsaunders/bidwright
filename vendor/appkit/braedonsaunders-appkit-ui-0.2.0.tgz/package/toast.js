'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// A sonner-compatible toast primitive. The public surface mirrors sonner so an
// app switches by changing the import:
//     import { toast, Toaster } from 'sonner'   →   from '@braedonsaunders/appkit-ui'
// `toast()` is a global imperative function (no provider/hook needed); a single
// <Toaster /> mounted at the app root subscribes and renders. Tokenized +
// animated with the appkit design system.
import * as React from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Check, CircleAlert, Info, Loader2, TriangleAlert, X } from 'lucide-react';
import { cn } from './utils.js';
let counter = 0;
class Observer {
    subscribers = [];
    subscribe(fn) {
        this.subscribers.push(fn);
        return () => {
            const i = this.subscribers.indexOf(fn);
            if (i > -1)
                this.subscribers.splice(i, 1);
        };
    }
    publish(t) {
        this.subscribers.forEach((s) => s(t));
    }
    create(data) {
        const id = data.id ?? ++counter;
        const { message, ...rest } = data;
        this.publish({ ...rest, id, title: message ?? data.title, type: data.type ?? 'default' });
        return id;
    }
    dismiss(id) {
        if (id == null)
            return id;
        this.publish({ id, dismiss: true });
        return id;
    }
    message = (message, data) => this.create({ ...data, message, type: 'default' });
    success = (message, data) => this.create({ ...data, message, type: 'success' });
    error = (message, data) => this.create({ ...data, message, type: 'error' });
    warning = (message, data) => this.create({ ...data, message, type: 'warning' });
    info = (message, data) => this.create({ ...data, message, type: 'info' });
    loading = (message, data) => this.create({ duration: Infinity, ...data, message, type: 'loading' });
    custom = (jsx, data) => {
        const id = data?.id ?? ++counter;
        this.publish({ ...data, id, type: 'default', jsx: jsx(id) });
        return id;
    };
    promise = (promise, opts) => {
        const id = this.loading(opts.loading);
        promise.then((data) => this.create({ id, message: typeof opts.success === 'function' ? opts.success(data) : opts.success, type: 'success', duration: undefined }), (err) => this.create({ id, message: typeof opts.error === 'function' ? opts.error(err) : opts.error, type: 'error', duration: undefined }));
        return id;
    };
}
const ToastState = new Observer();
function toastFunction(message, data) {
    return ToastState.create({ ...data, message });
}
/** sonner-compatible global toast API. */
export const toast = Object.assign(toastFunction, {
    success: ToastState.success,
    error: ToastState.error,
    warning: ToastState.warning,
    info: ToastState.info,
    message: ToastState.message,
    loading: ToastState.loading,
    custom: ToastState.custom,
    promise: ToastState.promise,
    dismiss: (id) => ToastState.dismiss(id),
});
const POSITION_CLASS = {
    'top-left': 'top-0 left-0 items-start',
    'top-center': 'top-0 left-1/2 -translate-x-1/2 items-center',
    'top-right': 'top-0 right-0 items-end',
    'bottom-left': 'bottom-0 left-0 items-start',
    'bottom-center': 'bottom-0 left-1/2 -translate-x-1/2 items-center',
    'bottom-right': 'bottom-0 right-0 items-end',
};
const TYPE_ICON = {
    default: null,
    success: _jsx(Check, { className: "size-4" }),
    error: _jsx(CircleAlert, { className: "size-4" }),
    warning: _jsx(TriangleAlert, { className: "size-4" }),
    info: _jsx(Info, { className: "size-4" }),
    loading: _jsx(Loader2, { className: "size-4 animate-spin motion-reduce:animate-none" }),
};
const RICH = {
    default: 'border-border bg-elevated text-fg',
    success: 'border-success/25 bg-success-subtle text-success',
    error: 'border-danger/25 bg-danger-subtle text-danger',
    warning: 'border-warning/25 bg-warning-subtle text-warning',
    info: 'border-info/25 bg-info-subtle text-info',
    loading: 'border-border bg-elevated text-fg',
};
const ACCENT = {
    default: 'text-fg-muted',
    success: 'text-success',
    error: 'text-danger',
    warning: 'text-warning',
    info: 'text-info',
    loading: 'text-fg-muted',
};
export function Toaster({ position = 'bottom-right', richColors = false, duration = 4000, closeButton = false, visibleToasts = 4, className, }) {
    const [toasts, setToasts] = React.useState([]);
    const [mounted, setMounted] = React.useState(false);
    React.useEffect(() => setMounted(true), []);
    React.useEffect(() => ToastState.subscribe((t) => {
        if ('dismiss' in t) {
            setToasts((prev) => prev.filter((x) => x.id !== t.id));
            return;
        }
        setToasts((prev) => {
            const existing = prev.find((x) => x.id === t.id);
            if (existing)
                return prev.map((x) => (x.id === t.id ? { ...x, ...t } : x));
            const next = [t, ...prev];
            return next.slice(0, visibleToasts);
        });
    }), [visibleToasts]);
    if (!mounted || typeof document === 'undefined')
        return null;
    const isTop = position.startsWith('top');
    return createPortal(_jsx("div", { className: cn('pointer-events-none fixed z-[80] flex w-full max-w-[420px] flex-col gap-2 p-4 sm:p-6', POSITION_CLASS[position], className), children: _jsx(AnimatePresence, { initial: false, children: toasts.map((t) => (_jsx(ToastRow, { toast: t, defaultDuration: duration, richColors: richColors, closeButton: closeButton, isTop: isTop }, t.id))) }) }), document.body);
}
function ToastRow({ toast: t, defaultDuration, richColors, closeButton, isTop, }) {
    const d = t.duration ?? (t.type === 'loading' ? Infinity : defaultDuration);
    const timer = React.useRef(null);
    const startedAt = React.useRef(0);
    const remaining = React.useRef(d);
    const clearTimer = React.useCallback(() => {
        if (timer.current)
            clearTimeout(timer.current);
        timer.current = null;
    }, []);
    const runTimer = React.useCallback(() => {
        if (!Number.isFinite(remaining.current))
            return;
        clearTimer();
        startedAt.current = Date.now();
        timer.current = setTimeout(() => {
            t.onAutoClose?.(t.id);
            ToastState.dismiss(t.id);
        }, remaining.current);
    }, [clearTimer, t]);
    React.useEffect(() => {
        remaining.current = d;
        runTimer();
        return clearTimer;
        // Re-arm whenever the toast content/duration changes (e.g. promise resolve).
    }, [clearTimer, d, runTimer]);
    function pauseTimer() {
        if (!timer.current)
            return;
        remaining.current = Math.max(0, remaining.current - (Date.now() - startedAt.current));
        clearTimer();
    }
    function resumeTimer() {
        if (!timer.current)
            runTimer();
    }
    function close() {
        t.onDismiss?.(t.id);
        ToastState.dismiss(t.id);
    }
    if (t.jsx) {
        return (_jsx(motion.div, { layout: true, initial: { opacity: 0, y: isTop ? -16 : 16, scale: 0.96 }, animate: { opacity: 1, y: 0, scale: 1 }, exit: { opacity: 0, scale: 0.96, transition: { duration: 0.15 } }, transition: { type: 'spring', damping: 26, stiffness: 320 }, className: "pointer-events-auto w-full", children: t.jsx }));
    }
    return (_jsxs(motion.div, { layout: true, role: "status", onMouseEnter: pauseTimer, onMouseLeave: resumeTimer, initial: { opacity: 0, y: isTop ? -16 : 16, scale: 0.96 }, animate: { opacity: 1, y: 0, scale: 1 }, exit: { opacity: 0, scale: 0.96, transition: { duration: 0.15 } }, transition: { type: 'spring', damping: 26, stiffness: 320 }, className: cn('pointer-events-auto flex w-full items-start gap-3 rounded-lg border px-4 py-3 shadow-lg', richColors ? RICH[t.type] : 'border-border bg-elevated text-fg', t.className), children: [t.icon ?? TYPE_ICON[t.type] ? (_jsx("span", { className: cn('mt-0.5 shrink-0', richColors ? '' : ACCENT[t.type]), children: t.icon ?? TYPE_ICON[t.type] })) : null, _jsxs("div", { className: "min-w-0 flex-1 space-y-0.5", children: [t.title ? _jsx("div", { className: "text-sm font-semibold", children: t.title }) : null, t.description ? _jsx("div", { className: cn('text-sm', richColors ? 'opacity-90' : 'text-fg-muted'), children: t.description }) : null, t.action || t.cancel ? (_jsxs("div", { className: "flex items-center gap-2 pt-1.5", children: [t.action ? (_jsx("button", { type: "button", onClick: (e) => {
                                    t.action.onClick(e);
                                    close();
                                }, className: "rounded-md bg-primary px-2.5 py-1 text-xs font-medium text-primary-fg hover:bg-primary-hover", children: t.action.label })) : null, t.cancel ? (_jsx("button", { type: "button", onClick: (e) => {
                                    t.cancel.onClick?.(e);
                                    close();
                                }, className: "rounded-md px-2.5 py-1 text-xs font-medium text-fg-muted hover:bg-surface-hover", children: t.cancel.label })) : null] })) : null] }), closeButton ? (_jsx("button", { type: "button", onClick: close, "aria-label": "Dismiss", className: "-mr-1 rounded-md p-1 text-current opacity-60 transition-opacity hover:opacity-100", children: _jsx(X, { className: "size-4" }) })) : null] }));
}
//# sourceMappingURL=toast.js.map