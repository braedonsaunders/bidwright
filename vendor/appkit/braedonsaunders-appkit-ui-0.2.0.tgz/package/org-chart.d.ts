import * as React from 'react';
import { type BadgeProps } from './badge.js';
/** One record in a reporting hierarchy. `parentId` is the formal manager. */
export type OrgChartNode = {
    id: string;
    /** The record this one reports to. Null/undefined/unknown ⇒ top level. */
    parentId?: string | null;
    name: string;
    /** Job title or role, shown under the name. */
    subtitle?: string;
    /** Third line — email, extension, department. */
    meta?: string;
    avatarSrc?: string;
    /**
     * A rendered avatar to use instead of `avatarSrc` — for records whose
     * likeness is composed at render time rather than stored as one image. It
     * replaces the card's 44px avatar, so size it to match.
     */
    avatar?: React.ReactNode;
    badge?: {
        label: string;
        variant?: BadgeProps['variant'];
    };
    /** Render the card muted (inactive, offboarded, archived…). */
    muted?: boolean;
};
export type OrgChartTreeNode = OrgChartNode & {
    depth: number;
    children: OrgChartTreeNode[];
};
/**
 * Resolve a flat parent-pointer list into a forest.
 *
 * Real hierarchies arrive dirty: dangling parents, self-references, and — when
 * two records are edited concurrently — cycles. None of those may lose a
 * record or hang the renderer, so anything that cannot be reached from a
 * genuine root is promoted to a root itself, in input order. Every input node
 * appears exactly once in the output.
 */
export declare function buildOrgTree(nodes: OrgChartNode[]): OrgChartTreeNode[];
/** Every record beneath `id`, exclusive of `id` itself. */
export declare function orgChartDescendantIds(nodes: OrgChartNode[], id: string): Set<string>;
/**
 * May `childId` be moved under `parentId` without breaking the tree? Guards
 * self-reference, no-op moves, and the cycle a manager-under-own-report makes.
 * Callers must re-check server-side — this is the UI's fast path, not the rule.
 */
export declare function canReparent(nodes: OrgChartNode[], childId: string, parentId: string | null): boolean;
export type OrgChartLabels = {
    collapse?: string;
    expand?: string;
    zoomIn?: string;
    zoomOut?: string;
    resetZoom?: string;
    topLevel?: string;
    topLevelHint?: string;
    /** Suffix for the collapsed-branch count, e.g. "4 reports". */
    reports?: string;
};
export type OrgChartProps = {
    nodes: OrgChartNode[];
    selectedId?: string | null;
    onSelect?: (id: string) => void;
    /**
     * Enables drag-to-reparent. Called with the moved record and its new manager
     * (`null` = top level). Only fired for moves `canReparent` accepts; persist
     * with the same guard on the server.
     */
    onReparent?: (childId: string, parentId: string | null) => void;
    /** Extra controls rendered beside the zoom buttons. */
    toolbar?: React.ReactNode;
    /** Shown instead of the tree when `nodes` is empty. */
    empty?: React.ReactNode;
    labels?: OrgChartLabels;
    className?: string;
};
/**
 * A formal reporting hierarchy: cards connected top-down, pan by scrolling,
 * branches collapsible, and — when `onReparent` is supplied — records dragged
 * onto a new manager. Connectors are drawn with borders rather than measured
 * geometry, so the chart renders identically on the server and never needs a
 * layout pass.
 */
export declare function OrgChart({ nodes, selectedId, onSelect, onReparent, toolbar, empty, labels, className, }: OrgChartProps): React.JSX.Element;
//# sourceMappingURL=org-chart.d.ts.map