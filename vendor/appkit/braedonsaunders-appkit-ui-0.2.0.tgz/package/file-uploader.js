'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// FileUploader — generic drag-and-drop file picker that hands off the
// pre-signed-upload protocol to the consumer via two callbacks:
//   • requestUploadAction  → presigns a single or multipart upload (server action)
//   • finalizeUploadAction → creates the attachment row (server action)
//
// On success the uploader calls `onUploaded({ attachmentId, ... })` so the
// caller can attach the new attachment id to its own entity. Renders progress
// and per-file error states inline.
import { useCallback, useRef, useState } from 'react';
import { defaultMaxUploadBytes } from './upload-limits.js';
import { useUiText } from './text-context.js';
import { cn } from './utils.js';
function uploadWithXhr(args) {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open('PUT', args.url);
        if (args.contentType)
            xhr.setRequestHeader('Content-Type', args.contentType);
        xhr.upload.onprogress = (event) => args.onProgress(event.loaded);
        xhr.onload = () => {
            if (xhr.status >= 200 && xhr.status < 300)
                resolve();
            else
                reject(new Error('Upload failed.'));
        };
        xhr.onerror = () => reject(new Error('Network error during upload'));
        xhr.send(args.body);
    });
}
export async function uploadReservedFile(request, file, onProgress = () => undefined) {
    if (request.mode === 'single') {
        await uploadWithXhr({
            url: request.putUrl,
            body: file,
            contentType: file.type || 'application/octet-stream',
            onProgress: (loaded) => onProgress(Math.round((loaded / file.size) * 100)),
        });
        return { uploadId: request.uploadId };
    }
    const expectedParts = Math.ceil(file.size / request.partSizeBytes);
    if (request.partUrls.length !== expectedParts) {
        throw new Error('Storage returned an invalid multipart upload plan');
    }
    for (const [index, partUrl] of request.partUrls.entries()) {
        const start = index * request.partSizeBytes;
        const end = Math.min(start + request.partSizeBytes, file.size);
        const part = file.slice(start, end, 'application/octet-stream');
        await uploadWithXhr({
            url: partUrl,
            body: part,
            onProgress: (partLoaded) => onProgress(Math.round(((start + partLoaded) / file.size) * 100)),
        });
    }
    return {
        uploadId: request.uploadId,
        multipartUploadId: request.multipartUploadId,
    };
}
export function FileUploader({ requestUploadAction, finalizeUploadAction, onUploaded, kind = 'document', accept, multiple = false, maxSize, compact = false, className, label, hint, }) {
    const t = useUiText();
    const effectiveMaxSize = maxSize ?? defaultMaxUploadBytes(kind);
    const inputRef = useRef(null);
    const [items, setItems] = useState([]);
    const [dragOver, setDragOver] = useState(false);
    const upload = useCallback(async (file, id) => {
        const updateItem = (patch) => setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...patch } : i)));
        if (file.size > effectiveMaxSize) {
            updateItem({
                status: 'error',
                error: t('File exceeds {value0} MB limit', {
                    value0: Math.round(effectiveMaxSize / 1024 / 1024),
                }),
            });
            return;
        }
        updateItem({ status: 'uploading', progress: 0 });
        const req = await requestUploadAction({
            kind,
            filename: file.name,
            contentType: file.type || 'application/octet-stream',
            sizeBytes: file.size,
        });
        if (!req.ok) {
            updateItem({ status: 'error', error: req.error });
            return;
        }
        let finalizeInput;
        try {
            finalizeInput = await uploadReservedFile(req, file, (progress) => updateItem({ progress }));
        }
        catch (err) {
            updateItem({
                status: 'error',
                error: err instanceof Error ? t(err.message) : t('Upload failed.'),
            });
            return;
        }
        updateItem({ status: 'finalising', progress: 100 });
        const finalise = await finalizeUploadAction(finalizeInput);
        if (!finalise.ok) {
            updateItem({ status: 'error', error: finalise.error });
            return;
        }
        updateItem({ status: 'done' });
        onUploaded({
            attachmentId: finalise.attachmentId,
            filename: file.name,
            contentType: file.type || 'application/octet-stream',
            sizeBytes: file.size,
            kind,
            url: finalise.url,
        });
    }, [finalizeUploadAction, kind, effectiveMaxSize, onUploaded, requestUploadAction, t]);
    const handleFiles = useCallback((files) => {
        if (!files || files.length === 0)
            return;
        // Respect `multiple`: a single-file uploader queues only the first file
        // even when several are dropped at once.
        const list = multiple ? Array.from(files) : Array.from(files).slice(0, 1);
        const queued = list.map((file) => ({
            id: globalThis.crypto.randomUUID(),
            file,
            status: 'queued',
        }));
        setItems((prev) => [...prev, ...queued]);
        for (const q of queued)
            void upload(q.file, q.id);
    }, [multiple, upload]);
    return (_jsxs("div", { className: cn('space-y-2', className), children: [_jsxs("div", { onDragOver: (e) => {
                    e.preventDefault();
                    setDragOver(true);
                }, onDragLeave: () => setDragOver(false), onDrop: (e) => {
                    e.preventDefault();
                    setDragOver(false);
                    handleFiles(e.dataTransfer.files);
                }, onClick: () => inputRef.current?.click(), role: "button", tabIndex: 0, onKeyDown: (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        inputRef.current?.click();
                    }
                }, className: cn('flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed text-center transition-colors', compact ? 'px-3 py-3' : 'px-4 py-6', dragOver
                    ? 'border-primary bg-primary-subtle text-primary'
                    : 'border-border-strong bg-bg-subtle text-fg-muted hover:border-primary/60 hover:bg-primary-subtle/50'), children: [_jsx("span", { className: cn('font-medium', compact ? 'text-xs' : 'text-sm'), children: t(label ?? 'Drop files here or click to select') }), !compact && hint ? (_jsx("span", { className: "mt-1 text-[11px] text-fg-muted", children: t(hint) })) : null, _jsx("input", { ref: inputRef, type: "file", className: "hidden", accept: accept, multiple: multiple, onChange: (e) => {
                            handleFiles(e.currentTarget.files);
                            // Reset so re-picking the same file (e.g. retry after an error)
                            // still fires a change event.
                            e.currentTarget.value = '';
                        } })] }), items.length > 0 ? (_jsx("ul", { className: "space-y-1", children: items.map((item) => (_jsxs("li", { className: "flex items-center justify-between gap-3 rounded-md border border-border bg-surface px-3 py-1.5 text-xs ", children: [_jsxs("div", { className: "min-w-0 flex-1", children: [_jsx("div", { className: "truncate font-medium text-fg", children: item.file.name }), item.status === 'error' ? (_jsx("div", { className: "text-[11px] text-danger", children: item.error ? t(item.error) : null })) : item.status === 'done' ? (_jsx("div", { className: "text-[11px] text-success", children: t('Uploaded') })) : (_jsx("div", { className: "text-[11px] text-fg-muted", children: item.status === 'uploading'
                                        ? t('Uploading… {value0}%', { value0: item.progress ?? 0 })
                                        : item.status === 'finalising'
                                            ? t('Finalising…')
                                            : t('Queued') })), (item.status === 'uploading' || item.status === 'finalising') && (_jsx("div", { className: "mt-1 h-1 overflow-hidden rounded-full bg-border-subtle", children: _jsx("div", { className: "h-full rounded-full bg-primary transition-[width] duration-200", style: { width: `${item.progress ?? 0}%` } }) }))] }), item.status === 'error' ? (_jsx("button", { type: "button", onClick: () => setItems((prev) => prev.filter((i) => i.id !== item.id)), className: "rounded px-2 py-0.5 text-[11px] font-medium text-danger hover:bg-danger-subtle", children: t('Dismiss') })) : null] }, item.id))) })) : null] }));
}
//# sourceMappingURL=file-uploader.js.map