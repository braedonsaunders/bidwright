/**
 * Return the number of leading top-navigation groups that fit before the
 * overflow menu. All measurements are CSS pixels from the rendered controls.
 * Shared by the production top-navigation implementation.
 */
export declare function visibleTopNavGroupCount({ availableWidth, groupWidths, moreWidth, gap, }: {
    availableWidth: number;
    groupWidths: number[];
    moreWidth: number;
    gap: number;
}): number;
//# sourceMappingURL=nav-overflow.d.ts.map