/// <reference types="react/canary" />
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import * as React from 'react';
import { ViewTransition } from 'react';
import { cn } from './utils.js';
/**
 * Keeps the application shell live while the browser hands the changing page
 * canvas between routes. Requires Next.js `experimental.viewTransition`.
 */
export function PageTransition({ navigationKey, children, className, }) {
    return (_jsx(ViewTransition, { name: "appkit-page", share: "appkit-page-transition", enter: "appkit-page-transition", exit: "appkit-page-transition", default: "none", children: _jsx("div", { className: cn('appkit-page-frame flex min-h-0 flex-1 flex-col overflow-hidden', className), children: children }) }, navigationKey));
}
//# sourceMappingURL=page-transition.js.map