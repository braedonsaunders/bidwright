'use client';
import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { ArrowDown, ArrowUp } from 'lucide-react';
import { Button } from './button.js';
import { Input } from './input.js';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, } from './table.js';
import { cn } from './utils.js';
const DEFAULT_LABELS = {
    searchPlaceholder: 'Search…',
    searchLabel: 'Search',
    showing: (from, to, total) => _jsxs(_Fragment, { children: ["Showing ", _jsx("strong", { className: "font-semibold text-fg", children: from }), "\u2013", _jsx("strong", { className: "font-semibold text-fg", children: to }), " of", ' ', _jsx("strong", { className: "font-semibold text-fg", children: total })] }),
    prev: 'Prev',
    next: 'Next',
    pageOf: (page, pages) => _jsxs(_Fragment, { children: ["Page ", page, " of ", pages] }),
    noResults: (query) => _jsxs(_Fragment, { children: ["No matches for \u201C", query, "\u201D"] }),
    sortBy: (column) => `Sort by ${column}`,
};
/** Blanks order last ascending, so a sorted column leads with real values. */
function compareValues(a, b) {
    const aBlank = a == null || a === '';
    const bBlank = b == null || b === '';
    if (aBlank || bBlank)
        return aBlank && bBlank ? 0 : aBlank ? 1 : -1;
    if (a instanceof Date && b instanceof Date)
        return a.getTime() - b.getTime();
    if (typeof a === 'number' && typeof b === 'number')
        return a - b;
    return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: 'base' });
}
/**
 * Client-side searched, sorted, and paginated table for bounded data already
 * loaded into a page or drawer. The call surface matches the production
 * reference; only localized copy and semantic tokens are injected/generalized.
 */
export function PagedTable({ rows, columns, pageSize = 10, searchable = false, empty, rowKey, rowClassName, defaultSort, onRowClick, labels: labelOverrides, }) {
    const labels = { ...DEFAULT_LABELS, ...labelOverrides };
    const [query, setQuery] = React.useState('');
    const [page, setPage] = React.useState(0);
    const [sort, setSort] = React.useState(defaultSort ?? null);
    const filtered = React.useMemo(() => {
        const normalized = query.trim().toLocaleLowerCase();
        if (!normalized)
            return rows;
        return rows.filter((row) => columns.some((column) => column.search?.(row).toLocaleLowerCase().includes(normalized)));
    }, [columns, query, rows]);
    const ordered = React.useMemo(() => {
        const read = sort ? columns.find((column) => column.key === sort.key)?.sortValue : undefined;
        if (!read || !sort)
            return filtered;
        const direction = sort.dir === 'asc' ? 1 : -1;
        return [...filtered].sort((a, b) => compareValues(read(a), read(b)) * direction);
    }, [columns, filtered, sort]);
    const boundedPageSize = Math.max(1, Math.trunc(pageSize));
    const pageCount = Math.max(1, Math.ceil(ordered.length / boundedPageSize));
    const clamped = Math.min(page, pageCount - 1);
    const start = clamped * boundedPageSize;
    const visible = ordered.slice(start, start + boundedPageSize);
    const toggleSort = (key) => {
        setSort((current) => current?.key === key ? { key, dir: current.dir === 'asc' ? 'desc' : 'asc' } : { key, dir: 'asc' });
        setPage(0);
    };
    if (rows.length === 0)
        return _jsx(_Fragment, { children: empty });
    return _jsxs("div", { className: "space-y-3", children: [searchable ? _jsx(Input, { type: "search", "aria-label": labels.searchLabel, value: query, onChange: (event) => {
                    setQuery(event.target.value);
                    setPage(0);
                }, placeholder: labels.searchPlaceholder, className: "max-w-xs" }) : null, _jsxs(Table, { children: [_jsx(TableHeader, { children: _jsx(TableRow, { noAnimate: true, children: columns.map((column) => {
                                const active = sort?.key === column.key;
                                const alignRight = column.align === 'right';
                                return _jsx(TableHead, { align: alignRight ? 'right' : undefined, className: alignRight ? 'text-right' : undefined, "aria-sort": column.sortValue ? (active ? (sort.dir === 'asc' ? 'ascending' : 'descending') : 'none') : undefined, children: column.sortValue ? _jsxs("button", { type: "button", onClick: () => toggleSort(column.key), "aria-label": typeof column.header === 'string' ? labels.sortBy(column.header) : undefined, className: cn('inline-flex items-center gap-1 uppercase tracking-wide transition-colors hover:text-fg', alignRight && 'flex-row-reverse', active && 'text-fg'), children: [column.header, active ? (sort.dir === 'asc' ? _jsx(ArrowUp, { className: "size-3" }) : _jsx(ArrowDown, { className: "size-3" })) : null] }) : column.header }, column.key);
                            }) }) }), _jsx(TableBody, { children: visible.length === 0 ? _jsx(TableRow, { children: _jsx(TableCell, { colSpan: columns.length, className: "py-8 text-center text-sm text-fg-muted", children: labels.noResults(query.trim()) }) }) : visible.map((row, index) => _jsx(TableRow, { onClick: onRowClick ? () => onRowClick(row) : undefined, className: cn(onRowClick && 'cursor-pointer', rowClassName?.(row)), children: columns.map((column) => _jsx(TableCell, { className: column.align === 'right' ? 'text-right tabular-nums' : undefined, children: column.cell(row) }, column.key)) }, rowKey(row, start + index))) })] }), ordered.length > boundedPageSize ? _jsxs("div", { className: "flex items-center justify-between text-xs text-fg-muted", children: [_jsx("span", { children: labels.showing(start + 1, Math.min(start + boundedPageSize, ordered.length), ordered.length) }), _jsxs("div", { className: "flex items-center gap-1.5", children: [_jsx(Button, { variant: "outline", size: "sm", disabled: clamped === 0, onClick: () => setPage(clamped - 1), children: labels.prev }), _jsx("span", { className: "tabular-nums", children: labels.pageOf(clamped + 1, pageCount) }), _jsx(Button, { variant: "outline", size: "sm", disabled: clamped >= pageCount - 1, onClick: () => setPage(clamped + 1), children: labels.next })] })] }) : null] });
}
//# sourceMappingURL=paged-table.js.map