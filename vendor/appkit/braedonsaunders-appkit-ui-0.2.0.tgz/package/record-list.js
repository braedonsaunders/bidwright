'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import * as React from 'react';
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, Search } from 'lucide-react';
import { Badge } from './badge.js';
import { Button } from './button.js';
import { EmptyState } from './empty-state.js';
import { Input } from './input.js';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, } from './table.js';
import { cn } from './utils.js';
export function RecordList({ columns, rows, getRowId, className, tableContainerClassName, tableClassName, search, filters, toolbarActions, sort, onSortChange, pagination, empty, linkRender, onRowClick, activeRowId, }) {
    const renderLink = linkRender ??
        (({ href, children, className }) => (_jsx("a", { href: href, className: className, children: children })));
    const cell = (row, c) => {
        const v = row[c.key];
        const emptyText = _jsx("span", { className: "text-fg-subtle", children: "\u2014" });
        if (c.render && c.kind !== 'actions')
            return _jsx(TableCell, { children: c.render(row) }, c.key);
        switch (c.kind) {
            case 'reference':
                return (_jsx(TableCell, { className: "font-medium", children: c.href && v != null && v !== ''
                        ? renderLink({
                            href: c.href(row),
                            className: 'text-primary hover:underline',
                            children: String(v),
                        })
                        : emptyText }, c.key));
            case 'amount':
                return (_jsx(TableCell, { className: "text-right tabular-nums", children: v == null || v === '' ? emptyText : (c.format ? c.format(v, row) : String(v)) }, c.key));
            case 'status':
                return (_jsx(TableCell, { children: _jsx(Badge, { variant: c.statusVariant?.(String(v)) ?? 'secondary', children: String(v) }) }, c.key));
            case 'actions':
                return (_jsx(TableCell, { className: "w-px whitespace-nowrap px-2 text-right", children: c.render ? c.render(row) : null }, c.key));
            default:
                return (_jsx(TableCell, { className: cn(c.align === 'right' && 'text-right'), children: v == null || v === '' ? emptyText : c.format ? c.format(v, row) : String(v) }, c.key));
        }
    };
    const totalPages = pagination ? Math.max(1, Math.ceil(pagination.total / pagination.perPage)) : 1;
    const from = pagination ? (pagination.page - 1) * pagination.perPage + 1 : 0;
    const to = pagination ? Math.min(pagination.page * pagination.perPage, pagination.total) : 0;
    return (_jsxs("div", { className: cn('space-y-3', className), children: [(search || filters || toolbarActions) ? (_jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [search ? (_jsxs("div", { className: "relative w-full sm:w-64", children: [_jsx(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-fg-subtle" }), _jsx(Input, { value: search.value, onChange: (e) => search.onChange(e.target.value), placeholder: search.placeholder ?? 'Search…', className: "pl-9" })] })) : null, filters, _jsx("div", { className: "ml-auto flex items-center gap-2", children: toolbarActions })] })) : null, rows.length === 0 ? (_jsx(EmptyState, { icon: empty?.icon, title: empty?.title ?? 'Nothing here yet', description: empty?.description, action: empty?.action })) : (_jsxs(_Fragment, { children: [_jsxs(Table, { className: tableClassName, containerClassName: tableContainerClassName, children: [_jsx(TableHeader, { children: _jsx(TableRow, { noAnimate: true, children: columns.map((c) => {
                                        const active = sort?.key === c.key;
                                        const alignRight = c.align === 'right' || c.kind === 'amount';
                                        return (_jsx(TableHead, { style: c.width ? { width: c.width } : undefined, className: cn(alignRight && 'text-right', c.kind === 'actions' && 'text-right'), children: c.sortable && onSortChange ? (_jsxs("button", { type: "button", onClick: () => onSortChange(c.key), className: cn('inline-flex items-center gap-1 uppercase tracking-wide transition-colors hover:text-fg', alignRight && 'flex-row-reverse', active && 'text-fg'), children: [c.label, active ? (sort.dir === 'asc' ? (_jsx(ArrowUp, { className: "size-3" })) : (_jsx(ArrowDown, { className: "size-3" }))) : null] })) : (c.label) }, c.key));
                                    }) }) }), _jsx(TableBody, { children: rows.map((row) => {
                                    const rowId = getRowId(row);
                                    const active = activeRowId != null && activeRowId === rowId;
                                    return (_jsx(TableRow, { "data-state": active ? 'selected' : undefined, "aria-selected": active || undefined, onClick: onRowClick ? () => onRowClick(row) : undefined, className: onRowClick ? 'cursor-pointer' : undefined, children: columns.map((c) => cell(row, c)) }, rowId));
                                }) })] }), pagination && pagination.total > pagination.perPage ? (_jsxs("div", { className: "flex items-center justify-between text-sm text-fg-muted", children: [_jsxs("span", { children: [from, "\u2013", to, " of ", pagination.total] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsxs(Button, { variant: "outline", size: "sm", disabled: pagination.page <= 1, onClick: () => pagination.onPageChange(pagination.page - 1), children: [_jsx(ChevronLeft, { className: "size-4" }), " Prev"] }), _jsxs("span", { className: "tabular-nums", children: [pagination.page, " / ", totalPages] }), _jsxs(Button, { variant: "outline", size: "sm", disabled: pagination.page >= totalPages, onClick: () => pagination.onPageChange(pagination.page + 1), children: ["Next ", _jsx(ChevronRight, { className: "size-4" })] })] })] })) : null] }))] }));
}
//# sourceMappingURL=record-list.js.map