import * as React from 'react';
export type DrawerSize = 'sm' | 'md' | 'lg' | 'xl' | '2xl' | 'full';
export type DrawerSide = 'left' | 'right';
export type DrawerText = {
    close: string;
    fullscreen: string;
    exitFullscreen: string;
    translate?: (key: string) => string;
};
export declare function DrawerTextProvider({ value, children, }: {
    value: Partial<DrawerText>;
    children: React.ReactNode;
}): React.JSX.Element;
export type DrawerProps = {
    open: boolean;
    onClose: () => void;
    title?: React.ReactNode;
    description?: React.ReactNode;
    size?: DrawerSize;
    side?: DrawerSide;
    children: React.ReactNode;
    footer?: React.ReactNode;
    /** Primary action buttons pinned into the header, before the close button. */
    headerActions?: React.ReactNode;
    /** Record-detail navigation rendered directly below the title header. */
    subtabs?: React.ReactNode;
    /** Override the body wrapper classes (default: scroll + px-6 py-5). */
    bodyClassName?: string;
    /** Extra classes for the panel (e.g. record-type tinting). */
    panelClassName?: string;
    /** Raise above another open drawer in a deliberate nested flow. */
    stacked?: boolean;
    /** Open at full viewport width; the user can still collapse it. */
    initialFullscreen?: boolean;
    /** Hide the fullscreen expand/collapse affordance. */
    disableFullscreen?: boolean;
    /** Fires after the exit animation completes (UrlDrawer defers navigation). */
    onExitComplete?: () => void;
};
/**
 * Slide-in flyout for sub-entity create/edit and detail views. Portals to body;
 * spring slide-in; backdrop fade+blur; Esc + click-out + ref-counted scroll
 * lock; focus trap + restore; a NetSuite-style expand/collapse to full viewport
 * width (animated via max-width). Fully tokenized and reduced-motion aware.
 */
export declare function Drawer({ open, onClose, title, description, size, side, children, footer, headerActions, subtabs, bodyClassName, panelClassName, stacked, initialFullscreen, disableFullscreen, onExitComplete, }: DrawerProps): React.ReactPortal | null;
/**
 * Client-side navigate fn supplied by the host app (e.g. Next's `router.push`)
 * so `UrlDrawer` can close by changing the URL — which re-runs the server
 * component that owns the drawer's `open` state. Falls back to a hard nav.
 */
export declare const DrawerNavigateContext: React.Context<((href: string) => void) | null>;
export type UrlDrawerProps = Omit<DrawerProps, 'open' | 'onClose' | 'onExitComplete'> & {
    open: boolean;
    closeHref: string;
};
/**
 * URL-state drawer for server-rendered pages: `open` derives from a search
 * param, so closing needs a real navigation (deferred until the slide-out
 * finishes, so the exit animation always plays).
 */
export declare function UrlDrawer({ open, closeHref, children, ...rest }: UrlDrawerProps): React.JSX.Element;
//# sourceMappingURL=drawer.d.ts.map