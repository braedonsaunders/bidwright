export type SearchInputEditState = {
    value: string;
    /**
     * The user has a local edit that must win over URL updates until every
     * in-flight navigation settles. This prevents an older server response from
     * replacing text entered after that request began.
     */
    dirty: boolean;
};
export declare function createSearchInputEditState(urlValue: string): SearchInputEditState;
export declare function applySearchInputEdit(value: string, urlValue: string, navigationPending: boolean): SearchInputEditState;
export declare function reconcileSearchInputUrl(state: SearchInputEditState, urlValue: string, navigationPending: boolean): SearchInputEditState;
//# sourceMappingURL=list-search-input-state.d.ts.map