import * as React from 'react';
import { type ListSearchParams } from './list-params.js';
type SortLinkProps = {
    basePath: string;
    currentParams: ListSearchParams;
    column: string;
    active: boolean;
    dir: 'asc' | 'desc';
    align?: 'left' | 'right';
    sortParamKey?: string;
    dirParamKey?: string;
    pageParamKey?: string;
    children: React.ReactNode;
};
/** Sortable header for tables built from the <Table> primitives. */
export declare function SortableTh({ className, ...props }: SortLinkProps & {
    className?: string;
}): React.JSX.Element;
/**
 * Sortable header for raw `<table>` lists — renders a plain
 * `<th className="px-3 py-2">` and derives `active` from the current `sort`.
 */
export declare function SortTh({ sort, className, ...props }: Omit<SortLinkProps, 'active'> & {
    sort: string;
    className?: string;
}): React.JSX.Element;
export {};
//# sourceMappingURL=sortable-th.d.ts.map