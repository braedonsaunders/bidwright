'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import * as React from 'react';
import { ArrowRight, ArrowUpRight, Check } from 'lucide-react';
import { defaultLinkRender } from './link-context.js';
import { PageHeader } from './page-header.js';
import { cn } from './utils.js';
const ACCENTS = {
    teal: {
        chip: 'bg-primary-subtle text-primary ring-primary/15',
        border: 'hover:border-primary/40',
        link: 'group-hover:text-primary',
    },
    violet: {
        chip: 'bg-info-subtle text-info ring-info/15',
        border: 'hover:border-info/40',
        link: 'group-hover:text-info',
    },
    amber: {
        chip: 'bg-warning-subtle text-warning ring-warning/15',
        border: 'hover:border-warning/40',
        link: 'group-hover:text-warning',
    },
    sky: {
        chip: 'bg-success-subtle text-success ring-success/15',
        border: 'hover:border-success/40',
        link: 'group-hover:text-success',
    },
};
export function AdminHub({ title, description, actions, groups, linkRender = defaultLinkRender, }) {
    return (_jsxs("div", { className: "flex h-full min-h-0 flex-col", children: [title || description ? (_jsx("div", { className: "shrink-0 border-b border-border bg-surface px-3 py-3 sm:px-6", children: _jsx(PageHeader, { title: title ?? '', description: description, actions: actions }) })) : null, _jsx("div", { className: "app-scroll min-h-0 flex-1 overflow-y-auto bg-bg-subtle", children: _jsx("div", { className: "mx-auto w-full max-w-(--breakpoint-2xl) space-y-8 p-4 sm:p-6", children: groups.map((group, gi) => {
                        const accent = ACCENTS[group.accent ?? 'teal'];
                        return (_jsxs("section", { className: "space-y-3", children: [group.label || group.description ? (_jsxs("div", { className: "space-y-1 px-0.5", children: [group.label ? (_jsx("h2", { className: "text-xs font-semibold tracking-wider text-fg-subtle uppercase", children: group.label })) : null, group.description ? (_jsx("p", { className: "max-w-3xl text-sm text-fg-muted", children: group.description })) : null] })) : null, _jsx("div", { className: cn('grid grid-cols-1 gap-3 sm:grid-cols-2', group.layout === 'detailed' ? '2xl:grid-cols-3' : 'lg:grid-cols-3 2xl:grid-cols-4'), children: group.cards.map((card, ci) => {
                                        const detailed = group.layout === 'detailed';
                                        const content = detailed ? (_jsxs(_Fragment, { children: [_jsxs("div", { className: "flex items-start gap-3", children: [_jsx("span", { className: cn('grid size-10 shrink-0 place-items-center rounded-lg ring-1 [&_svg]:size-[18px]', accent.chip), children: card.icon }), _jsxs("div", { className: "min-w-0 flex-1 space-y-1", children: [_jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [_jsx("h3", { className: "font-mono text-sm font-semibold text-fg", children: card.title }), card.badge] }), card.description ? (_jsx("p", { className: "text-sm leading-relaxed text-fg-muted", children: card.description })) : null] })] }), card.features?.length ? (_jsx("ul", { className: "mt-4 space-y-2 border-t border-border-subtle pt-4", children: card.features.map((feature) => (_jsxs("li", { className: "flex gap-2 text-xs leading-relaxed text-fg-muted", children: [_jsx(Check, { className: "mt-0.5 size-3.5 shrink-0 text-primary", "aria-hidden": true }), _jsx("span", { children: feature })] }, feature))) })) : null, card.href && card.linkLabel ? (_jsxs("span", { className: cn('mt-auto flex items-center gap-1.5 pt-4 text-xs font-semibold text-fg-muted', accent.link), children: [card.linkLabel, _jsx(ArrowRight, { className: "size-3.5 transition-transform group-hover:translate-x-0.5", "aria-hidden": true })] })) : null] })) : (_jsxs(_Fragment, { children: [_jsx("span", { className: cn('grid size-10 shrink-0 place-items-center rounded-lg ring-1', accent.chip), children: card.icon }), _jsxs("div", { className: "min-w-0 flex-1", children: [_jsxs("div", { className: "flex min-w-0 items-center gap-2", children: [_jsx("h3", { className: "truncate text-sm font-semibold text-fg", children: card.title }), card.badge] }), card.description ? (_jsx("p", { className: "truncate text-xs text-fg-muted", children: card.description })) : null] }), card.href ? (_jsx(ArrowUpRight, { size: 15, "aria-hidden": true, className: cn('shrink-0 text-fg-subtle opacity-0 transition-all duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:opacity-100', accent.link) })) : null] }));
                                        const className = cn('group rounded-xl border border-border bg-surface shadow-sm transition-all', detailed ? 'flex h-full flex-col p-4' : 'flex items-center gap-3 p-3.5', card.href && 'hover:shadow-md', card.href && accent.border);
                                        return card.href ? (_jsx(React.Fragment, { children: linkRender({
                                                href: card.href,
                                                title: card.description,
                                                className,
                                                children: content,
                                            }) }, ci)) : (_jsx("article", { className: className, children: content }, ci));
                                    }) })] }, gi));
                    }) }) })] }));
}
export function SettingsNav({ groups, activeKey, onSelect, className, }) {
    return (_jsx("nav", { className: cn('w-full', className), children: _jsx("div", { className: "space-y-5", children: groups.map((group, gi) => (_jsxs("div", { className: "space-y-1", children: [group.label ? (_jsx("h3", { className: "px-2 text-xs font-semibold tracking-wider text-fg-subtle uppercase", children: group.label })) : null, _jsx("ul", { className: "space-y-0.5", children: group.items.map((item) => {
                            const active = item.key === activeKey;
                            return (_jsx("li", { children: _jsxs("button", { type: "button", "aria-current": active ? 'page' : undefined, onClick: () => onSelect(item.key), className: cn('flex w-full items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-sm transition-colors', active
                                        ? 'bg-primary-subtle font-medium text-primary'
                                        : 'text-fg-muted hover:bg-surface-hover hover:text-fg'), children: [_jsx("span", { className: cn('shrink-0 [&_svg]:size-[15px]', active ? 'text-primary' : 'text-fg-subtle'), children: item.icon }), _jsx("span", { className: "flex-1 truncate text-left", children: item.label }), item.badge] }) }, item.key));
                        }) })] }, gi))) }) }));
}
export function SettingsShell({ title, description, back, actions, nav, activeKey, onSelect, children, contentWidth = 'narrow', linkRender = defaultLinkRender, }) {
    const contentWidthClass = {
        narrow: 'max-w-5xl',
        wide: 'max-w-(--breakpoint-2xl)',
        full: 'max-w-none',
    }[contentWidth];
    return (_jsxs("div", { className: "flex h-full min-h-0 flex-col", children: [_jsx("div", { className: "shrink-0 border-b border-border bg-surface px-3 py-3 sm:px-6", children: _jsx(PageHeader, { title: title, description: description, actions: actions, back: back
                        ? { ...back, render: (p) => linkRender({ href: p.href, className: p.className, children: p.children }) }
                        : undefined }) }), _jsxs("div", { className: "flex min-h-0 flex-1", children: [_jsx("aside", { className: "app-scroll w-44 shrink-0 overflow-y-auto border-r border-border bg-surface p-3 sm:w-52 lg:w-60", children: _jsx(SettingsNav, { groups: nav, activeKey: activeKey, onSelect: onSelect }) }), _jsx("div", { className: "app-scroll min-h-0 flex-1 overflow-y-auto bg-bg-subtle", children: _jsx("div", { className: cn('mx-auto w-full space-y-6 p-4 sm:p-6', contentWidthClass), children: children }) })] })] }));
}
// ---------------------------------------------------------------------------
// Content helpers used inside a SettingsShell.
// ---------------------------------------------------------------------------
export function SettingsSection({ title, description, footer, children, className, }) {
    return (_jsxs("section", { className: cn('overflow-hidden rounded-xl border border-border bg-surface', className), children: [title || description ? (_jsxs("div", { className: "border-b border-border px-5 py-4", children: [title ? _jsx("h2", { className: "text-sm font-semibold text-fg", children: title }) : null, description ? _jsx("p", { className: "mt-0.5 text-sm text-fg-muted", children: description }) : null] })) : null, _jsx("div", { className: "divide-y divide-border", children: children }), footer ? (_jsx("div", { className: "flex items-center justify-end gap-2 border-t border-border bg-bg-subtle px-5 py-3", children: footer })) : null] }));
}
export function SettingsRow({ title, description, control, stacked = false, children, className, }) {
    const right = control ?? children;
    return (_jsxs("div", { className: cn(stacked ? 'space-y-2 px-5 py-4' : 'flex items-center justify-between gap-4 px-5 py-4', className), children: [_jsxs("div", { className: "min-w-0 space-y-0.5", children: [_jsx("div", { className: "text-sm font-medium text-fg", children: title }), description ? _jsx("div", { className: "text-sm text-fg-muted", children: description }) : null] }), right ? _jsx("div", { className: cn(stacked ? 'w-full' : 'shrink-0'), children: right }) : null] }));
}
//# sourceMappingURL=settings-layout.js.map