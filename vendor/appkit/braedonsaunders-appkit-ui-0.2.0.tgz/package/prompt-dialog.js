'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { Button } from './button.js';
import { Input } from './input.js';
import { Label } from './label.js';
let current = null;
let counter = 0;
const listeners = new Set();
function emit() {
    for (const listener of listeners)
        listener();
}
/** Opens the shared text-input modal and resolves to a trimmed value or null. */
export function promptDialog(options) {
    return new Promise((resolve) => {
        current?.resolve(null);
        current = { ...options, id: ++counter, resolve };
        emit();
    });
}
/** Cancels the active prompt, if one exists. */
export function cancelPromptDialog() {
    settle(null);
}
function settle(value) {
    const request = current;
    if (!request)
        return;
    current = null;
    request.resolve(value);
    emit();
}
function subscribe(listener) {
    listeners.add(listener);
    return () => listeners.delete(listener);
}
/** Mount once beside the application's toaster. */
export function PromptRoot({ defaultConfirmLabel = 'Save', defaultCancelLabel = 'Cancel', }) {
    const request = React.useSyncExternalStore(subscribe, () => current, () => null);
    const [value, setValue] = React.useState('');
    const inputRef = React.useRef(null);
    const panelRef = React.useRef(null);
    const reduceMotion = useReducedMotion();
    const titleId = React.useId();
    const inputId = React.useId();
    React.useEffect(() => {
        if (!request)
            return;
        setValue(request.initialValue ?? '');
        const frame = requestAnimationFrame(() => {
            inputRef.current?.focus();
            inputRef.current?.select();
        });
        const previousOverflow = document.body.style.overflow;
        const previouslyFocused = document.activeElement;
        document.body.style.overflow = 'hidden';
        const focusable = 'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';
        function onKeyDown(event) {
            if (event.key === 'Escape') {
                event.preventDefault();
                settle(null);
                return;
            }
            if (event.key !== 'Tab')
                return;
            const panel = panelRef.current;
            if (!panel)
                return;
            const items = Array.from(panel.querySelectorAll(focusable)).filter((element) => element.offsetParent !== null || element === document.activeElement);
            if (items.length === 0) {
                event.preventDefault();
                panel.focus();
                return;
            }
            const first = items[0];
            const last = items.at(-1);
            if (event.shiftKey && document.activeElement === first) {
                event.preventDefault();
                last.focus();
            }
            else if (!event.shiftKey && document.activeElement === last) {
                event.preventDefault();
                first.focus();
            }
        }
        document.addEventListener('keydown', onKeyDown);
        return () => {
            cancelAnimationFrame(frame);
            document.removeEventListener('keydown', onKeyDown);
            document.body.style.overflow = previousOverflow;
            if (previouslyFocused && document.contains(previouslyFocused))
                previouslyFocused.focus();
        };
    }, [request?.id]);
    if (typeof document === 'undefined')
        return null;
    function submit() {
        const trimmed = value.trim();
        settle(trimmed || null);
    }
    return createPortal(_jsx(AnimatePresence, { children: request ? (_jsxs("div", { "data-ui-overlay": "prompt", className: "fixed inset-0 z-[60] flex items-center justify-center p-4", role: "dialog", "aria-modal": "true", "aria-labelledby": titleId, children: [_jsx(motion.div, { ref: panelRef, tabIndex: -1, initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, transition: { duration: 0.15 }, className: "absolute inset-0 bg-overlay/50 backdrop-blur-[2px]", onClick: () => settle(null), "aria-hidden": "true" }), _jsx(motion.div, { initial: reduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.96, y: 8 }, animate: reduceMotion ? { opacity: 1 } : { opacity: 1, scale: 1, y: 0 }, exit: reduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.96, y: 8 }, transition: { type: 'spring', damping: 26, stiffness: 340, mass: 0.7 }, className: "relative w-full max-w-md overflow-hidden rounded-xl border border-border bg-surface shadow-lg", children: _jsxs("form", { onSubmit: (event) => {
                            event.preventDefault();
                            submit();
                        }, children: [_jsxs("div", { className: "space-y-3 p-6", children: [_jsx("h2", { id: titleId, className: "text-base font-semibold text-fg", children: request.title }), request.label ? (_jsx(Label, { htmlFor: inputId, className: "text-xs text-fg-muted", children: request.label })) : null, _jsx(Input, { id: inputId, ref: inputRef, value: value, placeholder: request.placeholder, onChange: (event) => setValue(event.target.value) })] }), _jsxs("div", { className: "flex justify-end gap-2 border-t border-border bg-bg-subtle px-6 py-4", children: [_jsx(Button, { type: "button", variant: "outline", onClick: () => settle(null), children: request.cancelLabel ?? defaultCancelLabel }), _jsx(Button, { type: "submit", disabled: !value.trim(), children: request.confirmLabel ?? defaultConfirmLabel })] })] }) })] }, request.id)) : null }), document.body);
}
//# sourceMappingURL=prompt-dialog.js.map