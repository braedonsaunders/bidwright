/**
 * Keeps the browser tab aligned with the title already rendered by a page.
 *
 * Applications can set `data-application-name` on the root `<html>` element
 * to retain their brand in the tab title. The contract remains application-
 * agnostic so existing page components can move to AppKit unchanged.
 */
export declare function DocumentTitle({ title }: {
    title: string;
}): null;
//# sourceMappingURL=document-title.d.ts.map