import * as React from 'react';
import { type LinkRender } from './link-context.js';
export type { LinkRender };
export type AdminHubAccent = 'teal' | 'violet' | 'amber' | 'sky';
export type AdminHubCard = {
    href?: string;
    title: string;
    description?: string;
    icon?: React.ReactNode;
    badge?: React.ReactNode;
    features?: string[];
    linkLabel?: string;
};
export type AdminHubGroup = {
    label?: string;
    description?: string;
    accent?: AdminHubAccent;
    layout?: 'compact' | 'detailed';
    cards: AdminHubCard[];
};
export declare function AdminHub({ title, description, actions, groups, linkRender, }: {
    title?: string;
    description?: string;
    actions?: React.ReactNode;
    groups: AdminHubGroup[];
    linkRender?: LinkRender;
}): React.JSX.Element;
export type SettingsNavItem = {
    key: string;
    label: string;
    icon?: React.ReactNode;
    badge?: React.ReactNode;
};
export type SettingsNavGroup = {
    label?: string;
    items: SettingsNavItem[];
};
export declare function SettingsNav({ groups, activeKey, onSelect, className, }: {
    groups: SettingsNavGroup[];
    activeKey: string;
    onSelect: (key: string) => void;
    className?: string;
}): React.JSX.Element;
export declare function SettingsShell({ title, description, back, actions, nav, activeKey, onSelect, children, contentWidth, linkRender, }: {
    title: string;
    description?: string;
    back?: {
        href: string;
        label: string;
    };
    actions?: React.ReactNode;
    nav: SettingsNavGroup[];
    activeKey: string;
    onSelect: (key: string) => void;
    children: React.ReactNode;
    /**
     * Bounds the active pane without changing the navigation shell.
     * Settings forms stay narrow by default; record-heavy administration
     * workspaces can opt into a wider or edge-to-edge canvas.
     */
    contentWidth?: 'narrow' | 'wide' | 'full';
    linkRender?: LinkRender;
}): React.JSX.Element;
export declare function SettingsSection({ title, description, footer, children, className, }: {
    title?: string;
    description?: string;
    footer?: React.ReactNode;
    children: React.ReactNode;
    className?: string;
}): React.JSX.Element;
export declare function SettingsRow({ title, description, control, stacked, children, className, }: {
    title: React.ReactNode;
    description?: React.ReactNode;
    control?: React.ReactNode;
    stacked?: boolean;
    children?: React.ReactNode;
    className?: string;
}): React.JSX.Element;
//# sourceMappingURL=settings-layout.d.ts.map