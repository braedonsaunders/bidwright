import * as React from 'react';
export type TooltipProps = {
    content: React.ReactNode;
    children: React.ReactNode;
    className?: string;
};
/**
 * Tooltip — hover/focus label with an inverted surface (dark-on-light,
 * light-on-dark). Fades in above the trigger; dismissed on blur/leave.
 */
export declare function Tooltip({ content, children, className }: TooltipProps): React.JSX.Element;
//# sourceMappingURL=tooltip.d.ts.map