import * as React from 'react';
export type TableProps = React.HTMLAttributes<HTMLTableElement> & {
    /**
     * Classes for the table's scrolling surface. Use this to remove the default
     * card treatment when the table already lives inside a bordered workspace.
     */
    containerClassName?: string;
};
export declare const Table: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLTableElement> & {
    /**
     * Classes for the table's scrolling surface. Use this to remove the default
     * card treatment when the table already lives inside a bordered workspace.
     */
    containerClassName?: string;
} & React.RefAttributes<HTMLTableElement>>;
export declare const TableHeader: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLTableSectionElement> & React.RefAttributes<HTMLTableSectionElement>>;
export declare const TableBody: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLTableSectionElement> & React.RefAttributes<HTMLTableSectionElement>>;
export type TableRowProps = React.HTMLAttributes<HTMLTableRowElement> & {
    /** Disable the staggered entrance (e.g. header rows). */
    noAnimate?: boolean;
};
export declare const TableRow: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLTableRowElement> & {
    /** Disable the staggered entrance (e.g. header rows). */
    noAnimate?: boolean;
} & React.RefAttributes<HTMLTableRowElement>>;
export declare const TableHead: React.ForwardRefExoticComponent<React.ThHTMLAttributes<HTMLTableCellElement> & React.RefAttributes<HTMLTableCellElement>>;
export declare const TableCell: React.ForwardRefExoticComponent<React.TdHTMLAttributes<HTMLTableCellElement> & React.RefAttributes<HTMLTableCellElement>>;
//# sourceMappingURL=table.d.ts.map