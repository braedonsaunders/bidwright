import { type AttachmentKind } from './upload-limits.js';
export type UploadRequestResult = {
    ok: true;
    uploadId: string;
    mode: 'single';
    putUrl: string;
} | {
    ok: true;
    uploadId: string;
    mode: 'multipart';
    multipartUploadId: string;
    partSizeBytes: number;
    partUrls: string[];
} | {
    ok: false;
    error: string;
};
export type FinalizeUploadInput = {
    uploadId: string;
    multipartUploadId?: string;
};
export type RequestUploadAction = (input: {
    kind: AttachmentKind;
    filename: string;
    contentType: string;
    sizeBytes: number;
}) => Promise<UploadRequestResult>;
export type FinalizeUploadAction = (input: FinalizeUploadInput) => Promise<{
    ok: true;
    attachmentId: string;
    url: string;
} | {
    ok: false;
    error: string;
}>;
export type UploadedFile = {
    attachmentId: string;
    filename: string;
    contentType: string;
    sizeBytes: number;
    kind: AttachmentKind;
    url: string;
};
export type FileUploaderProps = {
    requestUploadAction: RequestUploadAction;
    finalizeUploadAction: FinalizeUploadAction;
    /** Called once per successfully uploaded file. */
    onUploaded: (file: UploadedFile) => void;
    /** Restrict the attachment kind tag we send to the server. */
    kind?: AttachmentKind;
    /** HTML accept attribute (e.g. ".pdf,.docx,application/pdf"). */
    accept?: string;
    /** Allow more than one file at a time. */
    multiple?: boolean;
    /** Max size per file in bytes. Defaults per kind (mirrors the server caps). */
    maxSize?: number;
    /** Compact dropzone (no big help text). */
    compact?: boolean;
    className?: string;
    label?: string;
    hint?: string;
};
export declare function uploadReservedFile(request: Extract<UploadRequestResult, {
    ok: true;
}>, file: File, onProgress?: (percent: number) => void): Promise<FinalizeUploadInput>;
export declare function FileUploader({ requestUploadAction, finalizeUploadAction, onUploaded, kind, accept, multiple, maxSize, compact, className, label, hint, }: FileUploaderProps): import("react").JSX.Element;
//# sourceMappingURL=file-uploader.d.ts.map