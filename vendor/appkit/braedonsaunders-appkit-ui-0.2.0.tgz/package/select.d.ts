import * as React from 'react';
export type SelectProps = React.SelectHTMLAttributes<HTMLSelectElement> & {
    /** Greyed placeholder shown when nothing is selected (or use a leading <option value=""> ). */
    placeholder?: string;
    /** Title of the mobile bottom sheet. */
    sheetTitle?: string;
    searchPlaceholder?: string;
    /** Force the in-dropdown search box on/off. Defaults to auto (shown for long lists). */
    searchable?: boolean;
    /** Extra classes for the trigger button (the visible control). */
    triggerClassName?: string;
};
export declare const Select: React.ForwardRefExoticComponent<React.SelectHTMLAttributes<HTMLSelectElement> & {
    /** Greyed placeholder shown when nothing is selected (or use a leading <option value=""> ). */
    placeholder?: string;
    /** Title of the mobile bottom sheet. */
    sheetTitle?: string;
    searchPlaceholder?: string;
    /** Force the in-dropdown search box on/off. Defaults to auto (shown for long lists). */
    searchable?: boolean;
    /** Extra classes for the trigger button (the visible control). */
    triggerClassName?: string;
} & React.RefAttributes<HTMLSelectElement>>;
//# sourceMappingURL=select.d.ts.map