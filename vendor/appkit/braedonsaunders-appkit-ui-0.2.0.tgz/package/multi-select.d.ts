import * as React from 'react';
export type MultiSelectOption = {
    value: string;
    label: string;
    description?: string;
    disabled?: boolean;
    group?: string;
};
export type MultiSelectProps = {
    value: string[];
    onChange: (value: string[]) => void;
    options: MultiSelectOption[];
    placeholder?: string;
    searchPlaceholder?: string;
    noMatchesLabel?: string;
    clearLabel?: string;
    selectAllLabel?: string;
    disabled?: boolean;
    clearable?: boolean;
    maxVisibleValues?: number;
    id?: string;
    ariaLabel?: string;
    className?: string;
    triggerClassName?: string;
};
/**
 * Searchable multi-value picker for permissions, categories, tags, and other
 * bounded option sets. The selected value order follows the option registry so
 * apps get stable rendering even when values are supplied from persisted data.
 */
export declare function MultiSelect({ value, onChange, options, placeholder, searchPlaceholder, noMatchesLabel, clearLabel, selectAllLabel, disabled, clearable, maxVisibleValues, id, ariaLabel, className, triggerClassName, }: MultiSelectProps): React.JSX.Element;
//# sourceMappingURL=multi-select.d.ts.map