'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
const UiLinkContext = React.createContext(null);
/** Inject an app router link once so appkit primitives never force full reloads. */
export function UiLinkProvider({ link, children, }) {
    return _jsx(UiLinkContext.Provider, { value: link, children: children });
}
export function UiLink({ href, ...rest }) {
    const Link = React.useContext(UiLinkContext) ?? 'a';
    return _jsx(Link, { href: href, ...rest });
}
/**
 * The fallback every navigation primitive uses when the app passes no
 * `linkRender`. It resolves through `UiLink`, so a `UiLinkProvider` at the root
 * is enough to make the whole shell route client-side. A raw `<a>` here would
 * full-reload the document on every click, which tears down the router and
 * skips page transitions entirely.
 */
export const defaultLinkRender = ({ href, children, className, title, ariaCurrent, role, dataWalkthrough, }) => (_jsx(UiLink, { href: href, className: className, title: title, "aria-current": ariaCurrent, role: role, "data-walkthrough": dataWalkthrough, children: children }));
const UiBackLinkContext = React.createContext(null);
/** Inject an app-aware history resolver for every PageHeader back link. */
export function UiBackLinkProvider({ backLink, children, }) {
    return _jsx(UiBackLinkContext.Provider, { value: backLink, children: children });
}
export function UiBackLink({ href, label, className }) {
    const BackLink = React.useContext(UiBackLinkContext);
    if (BackLink)
        return _jsx(BackLink, { href: href, label: label, className: className });
    return (_jsxs(UiLink, { href: href, className: className, children: ["\u2190 ", label] }));
}
//# sourceMappingURL=link-context.js.map