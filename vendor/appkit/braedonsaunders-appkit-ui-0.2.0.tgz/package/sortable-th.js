'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { ArrowDown, ArrowUp, ArrowUpDown } from 'lucide-react';
import { TableHead } from './table.js';
import { mergeHref } from './list-params.js';
import { useListNavClick } from './list-nav.js';
import { cn } from './utils.js';
/**
 * The clickable header label: column name + sort caret, linking to the toggled
 * sort URL. Clicking an inactive column sorts ascending; clicking the active
 * column flips direction. Page resets to 1.
 */
function SortLink({ basePath, currentParams, column, active, dir, align = 'left', sortParamKey = 'sort', dirParamKey = 'dir', pageParamKey = 'page', children, }) {
    const nextDir = active && dir === 'asc' ? 'desc' : 'asc';
    const href = mergeHref(basePath, currentParams, {
        [sortParamKey]: column,
        [dirParamKey]: nextDir,
        [pageParamKey]: 1,
    });
    const navClick = useListNavClick(href);
    return (_jsxs("a", { href: href, onClick: navClick, className: cn('inline-flex items-center gap-1.5 hover:text-fg', align === 'right' && 'flex-row-reverse'), children: [children, active ? (dir === 'asc' ? (_jsx(ArrowUp, { size: 12, className: "text-fg" })) : (_jsx(ArrowDown, { size: 12, className: "text-fg" }))) : (_jsx(ArrowUpDown, { size: 12, className: "text-fg-subtle/60" }))] }));
}
/** Sortable header for tables built from the <Table> primitives. */
export function SortableTh({ className, ...props }) {
    return (_jsx(TableHead, { className: className, children: _jsx(SortLink, { ...props }) }));
}
/**
 * Sortable header for raw `<table>` lists — renders a plain
 * `<th className="px-3 py-2">` and derives `active` from the current `sort`.
 */
export function SortTh({ sort, className, ...props }) {
    return (_jsx("th", { className: cn('px-3 py-2', className), children: _jsx(SortLink, { ...props, active: sort === props.column }) }));
}
//# sourceMappingURL=sortable-th.js.map