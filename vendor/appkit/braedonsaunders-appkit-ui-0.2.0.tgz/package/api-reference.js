'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Check, ChevronRight, Copy, Loader2, Play } from 'lucide-react';
import { Badge } from './badge.js';
import { Button } from './button.js';
import { Input } from './input.js';
import { cn } from './utils.js';
const METHOD_COLORS = {
    GET: 'bg-success-subtle text-success',
    POST: 'bg-info-subtle text-info',
    PUT: 'bg-warning-subtle text-warning',
    PATCH: 'bg-warning-subtle text-warning',
    DELETE: 'bg-danger-subtle text-danger',
};
export function MethodBadge({ method, className }) {
    const m = method.toUpperCase();
    return (_jsx("span", { className: cn('inline-flex min-w-14 justify-center rounded-md px-2 py-0.5 text-[11px] font-bold tracking-wide', METHOD_COLORS[m] ?? 'bg-bg-subtle text-fg-muted', className), children: m }));
}
export function CodeBlock({ code, className }) {
    const [copied, setCopied] = React.useState(false);
    const copy = () => {
        navigator.clipboard?.writeText(code).then(() => {
            setCopied(true);
            setTimeout(() => setCopied(false), 1500);
        });
    };
    return (_jsxs("div", { className: cn('group relative overflow-hidden rounded-lg border border-border bg-bg-subtle', className), children: [_jsx("button", { type: "button", onClick: copy, "aria-label": "Copy", className: "absolute right-2 top-2 rounded-md p-1.5 text-fg-subtle opacity-0 transition hover:bg-surface-hover hover:text-fg group-hover:opacity-100", children: copied ? _jsx(Check, { className: "size-4 text-success" }) : _jsx(Copy, { className: "size-4" }) }), _jsx("pre", { className: "app-scroll overflow-x-auto p-3 text-xs leading-relaxed", children: _jsx("code", { className: "font-mono text-fg", children: code }) })] }));
}
const json = (v) => JSON.stringify(v, null, 2);
export function ApiEndpoint({ endpoint, baseUrl, apiKey, defaultOpen = false, }) {
    const [open, setOpen] = React.useState(defaultOpen);
    const [sending, setSending] = React.useState(false);
    const [result, setResult] = React.useState(null);
    async function send() {
        if (!baseUrl)
            return;
        setSending(true);
        setResult(null);
        try {
            const hasBody = endpoint.method !== 'GET' && endpoint.requestExample !== undefined;
            const res = await fetch(baseUrl + endpoint.path, {
                method: endpoint.method,
                headers: {
                    ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}),
                    ...(hasBody ? { 'Content-Type': 'application/json' } : {}),
                },
                body: hasBody ? JSON.stringify(endpoint.requestExample) : undefined,
            });
            const text = await res.text();
            let body = text;
            try {
                body = json(JSON.parse(text));
            }
            catch {
                // Preserve non-JSON response bodies verbatim.
            }
            setResult({ status: res.status, body });
        }
        catch (e) {
            setResult({ status: 0, body: String(e) });
        }
        finally {
            setSending(false);
        }
    }
    return (_jsxs("div", { className: "overflow-hidden rounded-xl border border-border bg-surface", children: [_jsxs("button", { type: "button", onClick: () => setOpen((o) => !o), className: "flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-surface-hover", children: [_jsx(MethodBadge, { method: endpoint.method }), _jsx("code", { className: "min-w-0 flex-1 truncate font-mono text-sm text-fg", children: endpoint.path }), endpoint.summary ? (_jsx("span", { className: "hidden min-w-0 truncate text-sm text-fg-muted md:block", children: endpoint.summary })) : null, _jsx(ChevronRight, { className: cn('size-4 shrink-0 text-fg-subtle transition-transform', open && 'rotate-90') })] }), _jsx(AnimatePresence, { initial: false, children: open ? (_jsx(motion.div, { initial: { height: 0, opacity: 0 }, animate: { height: 'auto', opacity: 1 }, exit: { height: 0, opacity: 0 }, transition: { duration: 0.2, ease: [0.22, 1, 0.36, 1] }, className: "overflow-hidden", children: _jsxs("div", { className: "space-y-4 border-t border-border px-4 py-4", children: [endpoint.description ? _jsx("p", { className: "text-sm text-fg-muted", children: endpoint.description }) : null, endpoint.permission ? (_jsxs("div", { className: "flex items-center gap-2 text-xs", children: [_jsx("span", { className: "text-fg-subtle", children: "Requires" }), _jsx(Badge, { variant: "secondary", className: "font-mono", children: endpoint.permission })] })) : null, endpoint.params?.length ? (_jsx("div", { className: "overflow-hidden rounded-lg border border-border", children: _jsxs("table", { className: "w-full text-sm", children: [_jsx("thead", { className: "bg-bg-subtle text-xs uppercase tracking-wide text-fg-muted", children: _jsxs("tr", { children: [_jsx("th", { className: "px-3 py-2 text-left font-medium", children: "Param" }), _jsx("th", { className: "px-3 py-2 text-left font-medium", children: "Type" }), _jsx("th", { className: "px-3 py-2 text-left font-medium", children: "Description" })] }) }), _jsx("tbody", { className: "divide-y divide-border", children: endpoint.params.map((p) => (_jsxs("tr", { children: [_jsxs("td", { className: "px-3 py-2 font-mono text-fg", children: [p.name, p.required ? _jsx("span", { className: "text-danger", children: " *" }) : null, _jsx("span", { className: "ml-1 text-[11px] text-fg-subtle", children: p.in ?? 'query' })] }), _jsx("td", { className: "px-3 py-2 font-mono text-fg-muted", children: p.type ?? 'string' }), _jsx("td", { className: "px-3 py-2 text-fg-muted", children: p.description })] }, p.name))) })] }) })) : null, endpoint.requestExample !== undefined ? (_jsxs("div", { className: "space-y-1.5", children: [_jsx("div", { className: "text-xs font-medium text-fg-muted", children: "Request body" }), _jsx(CodeBlock, { code: json(endpoint.requestExample) })] })) : null, endpoint.responseExample !== undefined ? (_jsxs("div", { className: "space-y-1.5", children: [_jsx("div", { className: "text-xs font-medium text-fg-muted", children: "Response" }), _jsx(CodeBlock, { code: json(endpoint.responseExample) })] })) : null, baseUrl ? (_jsxs("div", { className: "space-y-2", children: [_jsxs(Button, { size: "sm", onClick: send, disabled: sending, children: [sending ? _jsx(Loader2, { className: "size-4 animate-spin" }) : _jsx(Play, { className: "size-4" }), "Send request"] }), result ? (_jsxs("div", { className: "space-y-1.5", children: [_jsxs("div", { className: "flex items-center gap-2 text-xs", children: [_jsx("span", { className: "text-fg-subtle", children: "Response" }), _jsx(Badge, { variant: result.status >= 200 && result.status < 300 ? 'success' : 'destructive', children: result.status || 'error' })] }), _jsx(CodeBlock, { code: result.body })] })) : null] })) : null] }) })) : null })] }));
}
export function ApiReference({ endpoints, baseUrl, title, description, apiKey: initialApiKey, showBearerToken = true, className, }) {
    const [apiKey, setApiKey] = React.useState(initialApiKey ?? '');
    const groups = React.useMemo(() => {
        const map = new Map();
        for (const e of endpoints) {
            const tag = e.tag ?? 'Endpoints';
            (map.get(tag) ?? map.set(tag, []).get(tag)).push(e);
        }
        return [...map.entries()];
    }, [endpoints]);
    return (_jsxs("div", { className: cn('space-y-6', className), children: [title || description ? (_jsxs("div", { className: "space-y-1", children: [title ? _jsx("h2", { className: "text-lg font-semibold tracking-tight text-fg", children: title }) : null, description ? _jsx("p", { className: "text-sm text-fg-muted", children: description }) : null] })) : null, baseUrl ? (_jsxs("div", { className: "flex flex-col gap-2 rounded-xl border border-border bg-surface p-4 sm:flex-row sm:items-center", children: [_jsxs("div", { className: "min-w-0 flex-1", children: [_jsx("div", { className: "text-xs text-fg-subtle", children: "Base URL" }), _jsx("code", { className: "truncate font-mono text-sm text-fg", children: baseUrl })] }), showBearerToken ? (_jsx(Input, { value: apiKey, onChange: (e) => setApiKey(e.target.value), placeholder: "Bearer token (optional)", className: "sm:w-64" })) : null] })) : null, groups.map(([tag, eps]) => (_jsxs("section", { className: "space-y-2", children: [_jsx("h3", { className: "px-0.5 text-xs font-semibold uppercase tracking-wide text-fg-subtle", children: tag }), _jsx("div", { className: "space-y-2", children: eps.map((e, i) => (_jsx(ApiEndpoint, { endpoint: e, baseUrl: baseUrl, apiKey: apiKey || initialApiKey }, `${e.method}-${e.path}-${i}`))) })] }, tag)))] }));
}
//# sourceMappingURL=api-reference.js.map