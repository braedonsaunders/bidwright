import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { DocumentTitle } from './document-title.js';
import { UiBackLink } from './link-context.js';
import { cn } from './utils.js';
export function PageHeader({ title, description, actions, back, className }) {
    const backClass = 'inline-flex items-center gap-1 text-xs text-fg-muted transition-colors hover:text-primary';
    return (_jsxs("div", { className: cn('space-y-2', className), children: [_jsx(DocumentTitle, { title: title }), back ? (back.render ? (back.render({ href: back.href, className: backClass, children: _jsxs(_Fragment, { children: ["\u2190 ", back.label] }) })) : _jsx(UiBackLink, { href: back.href, label: back.label, className: backClass })) : null, _jsxs("header", { className: "flex items-center justify-between gap-3 sm:items-end sm:gap-4", children: [_jsxs("div", { className: "min-w-0 space-y-1", children: [_jsx("h1", { className: "truncate text-xl font-semibold text-fg sm:text-2xl", children: title }), description ? (_jsx("p", { className: "hidden text-sm text-fg-muted sm:block", children: description })) : null] }), actions ? (_jsx("div", { className: "flex shrink-0 flex-wrap items-center justify-end gap-2", children: actions })) : null] })] }));
}
/** Source-compatible record-detail heading. */
export function DetailHeader({ back, title, subtitle, badge, actions, className, }) {
    return (_jsxs("header", { className: cn('space-y-2', className), children: [_jsx(DocumentTitle, { title: title }), back ? (_jsx(UiBackLink, { href: back.href, label: back.label, className: "text-sm text-primary hover:underline" })) : null, _jsxs("div", { className: "flex flex-col gap-2.5 sm:flex-row sm:items-center sm:justify-between sm:gap-4", children: [_jsxs("div", { className: "flex min-w-0 flex-wrap items-center gap-x-3 gap-y-1.5", children: [_jsx("h1", { className: "text-xl font-semibold text-fg sm:truncate sm:text-2xl", children: title }), badge] }), actions ? _jsx("div", { className: "flex flex-wrap items-center gap-2", children: actions }) : null] }), subtitle ? _jsx("p", { className: "text-sm text-fg-muted", children: subtitle }) : null] }));
}
//# sourceMappingURL=page-header.js.map