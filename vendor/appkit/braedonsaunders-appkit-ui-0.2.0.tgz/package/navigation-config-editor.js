'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { ChevronDown, ChevronUp, GripVertical, LockKeyhole } from 'lucide-react';
import { Reorder, useDragControls } from 'framer-motion';
import { Button } from './button.js';
import { SettingsSection } from './settings-layout.js';
import { NavIcon } from './sidebar-nav.js';
import { Switch } from './switch.js';
import { reconcileNavigationConfig, stampKnownNavigationItems, } from './navigation-config.js';
const DEFAULT_LABELS = {
    title: 'Main navigation',
    description: 'Choose which destinations appear and drag them into the order your team uses.',
    visible: 'Visible',
    hidden: 'Hidden',
    required: 'Required',
    moveUp: (label) => `Move ${label} up`,
    moveDown: (label) => `Move ${label} down`,
    drag: (label) => `Drag to reorder ${label}`,
};
/**
 * Controlled tenant navigation editor extracted from the production sibling.
 * Persistence and authorization stay application-owned.
 */
export function NavigationConfigEditor({ registry, value, onChange, disabled = false, labels, className, }) {
    const text = { ...DEFAULT_LABELS, ...labels };
    const config = React.useMemo(() => reconcileNavigationConfig(value, registry), [registry, value]);
    const registryByKey = React.useMemo(() => new Map(registry.map((item) => [item.key, item])), [registry]);
    const emit = React.useCallback((items) => {
        onChange(stampKnownNavigationItems({ version: 1, items }, registry));
    }, [onChange, registry]);
    const move = React.useCallback((index, direction) => {
        const target = index + direction;
        if (target < 0 || target >= config.items.length)
            return;
        const items = [...config.items];
        const [item] = items.splice(index, 1);
        if (!item)
            return;
        items.splice(target, 0, item);
        emit(items);
    }, [config.items, emit]);
    return (_jsx(SettingsSection, { title: text.title, description: text.description, className: className, children: _jsx(Reorder.Group, { axis: "y", values: config.items, onReorder: emit, as: "div", className: "divide-y divide-border", children: config.items.map((item, index) => {
                const registryItem = registryByKey.get(item.key);
                if (!registryItem)
                    return null;
                return (_jsx(NavigationConfigRow, { item: item, registryItem: registryItem, first: index === 0, last: index === config.items.length - 1, disabled: disabled, labels: text, onMoveUp: () => move(index, -1), onMoveDown: () => move(index, 1), onVisibilityChange: (visible) => emit(config.items.map((candidate) => candidate.key === item.key
                        ? { key: candidate.key, ...(visible ? {} : { hidden: true }) }
                        : candidate)) }, item.key));
            }) }) }));
}
function NavigationConfigRow({ item, registryItem, first, last, disabled, labels, onMoveUp, onMoveDown, onVisibilityChange, }) {
    const dragControls = useDragControls();
    const visible = registryItem.required || !item.hidden;
    return (_jsxs(Reorder.Item, { value: item, dragListener: false, dragControls: dragControls, as: "div", className: "flex items-center gap-3 bg-surface px-4 py-3", children: [_jsx("button", { type: "button", disabled: disabled, "aria-label": labels.drag(registryItem.label), onPointerDown: (event) => dragControls.start(event), className: "cursor-grab touch-none rounded-md p-1 text-fg-subtle transition-colors hover:bg-surface-hover hover:text-fg disabled:cursor-not-allowed disabled:opacity-40 active:cursor-grabbing", children: _jsx(GripVertical, { className: "size-4", "aria-hidden": true }) }), _jsx("span", { className: "grid size-8 shrink-0 place-items-center rounded-lg bg-bg-subtle text-fg-muted", children: _jsx(NavIcon, { iconKey: registryItem.iconKey }) }), _jsxs("div", { className: "min-w-0 flex-1", children: [_jsx("div", { className: "truncate text-sm font-medium text-fg", children: registryItem.label }), registryItem.description ? (_jsx("div", { className: "truncate text-xs text-fg-muted", children: registryItem.description })) : null] }), _jsxs("div", { className: "flex shrink-0 items-center gap-1", children: [_jsx(Button, { type: "button", variant: "ghost", size: "icon", disabled: disabled || first, "aria-label": labels.moveUp(registryItem.label), onClick: onMoveUp, children: _jsx(ChevronUp, { className: "size-4", "aria-hidden": true }) }), _jsx(Button, { type: "button", variant: "ghost", size: "icon", disabled: disabled || last, "aria-label": labels.moveDown(registryItem.label), onClick: onMoveDown, children: _jsx(ChevronDown, { className: "size-4", "aria-hidden": true }) })] }), registryItem.required ? (_jsxs("span", { className: "flex min-w-20 items-center justify-end gap-1 text-xs font-medium text-fg-muted", title: labels.required, children: [_jsx(LockKeyhole, { className: "size-3.5", "aria-hidden": true }), labels.required] })) : (_jsxs("label", { className: "flex min-w-20 items-center justify-end gap-2 text-xs font-medium text-fg-muted", children: [_jsx("span", { children: visible ? labels.visible : labels.hidden }), _jsx(Switch, { checked: visible, disabled: disabled, "aria-label": `${registryItem.label}: ${visible ? labels.visible : labels.hidden}`, onChange: (event) => onVisibilityChange(event.target.checked) })] }))] }));
}
//# sourceMappingURL=navigation-config-editor.js.map