'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { motion } from 'framer-motion';
import { cn } from './utils.js';
/**
 * Tabs — a segmented control with a spring-animated active indicator that
 * slides between options (framer `layoutId`). Reduced-motion falls back to an
 * instant swap.
 */
export function Tabs({ tabs, value, onValueChange, className }) {
    const id = React.useId();
    return (_jsx("div", { role: "tablist", className: cn('inline-flex gap-1 rounded-lg border border-border bg-bg-subtle p-1', className), children: tabs.map((tab) => {
            const active = tab.value === value;
            return (_jsxs("button", { type: "button", role: "tab", "aria-selected": active, onClick: () => onValueChange(tab.value), className: cn('relative rounded-md px-3 py-1.5 text-sm font-medium transition-colors', 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50', active ? 'text-fg' : 'text-fg-muted hover:text-fg'), children: [active ? (_jsx(motion.span, { layoutId: `appkit-tab-${id}`, className: "absolute inset-0 rounded-md bg-surface shadow-sm", transition: { type: 'spring', damping: 30, stiffness: 400 } })) : null, _jsx("span", { className: "relative z-10", children: tab.label })] }, tab.value));
        }) }));
}
//# sourceMappingURL=tabs.js.map