'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { PanelLeftClose, PanelLeftOpen } from 'lucide-react';
import { SidebarNav } from './sidebar-nav.js';
import { cn } from './utils.js';
const COOKIE = 'appkit_sidebar_collapsed';
/**
 * The desktop nav rail: brand + collapse toggle (persisted to a cookie so the
 * server can render the right width next load), the grouped nav, and a footer
 * slot (theme toggle, version, etc.). Hidden below `lg` — pair with AppShell's
 * built-in mobile nav.
 */
export function AppSidebar({ groups, pathname, brand, footer, collapsedFooter, defaultCollapsed = false, collapsible = true, linkRender, expandLabel = 'Expand sidebar', collapseLabel = 'Collapse sidebar', }) {
    const [collapsed, setCollapsed] = React.useState(defaultCollapsed);
    const toggle = React.useCallback(() => {
        setCollapsed((c) => {
            const next = !c;
            try {
                document.cookie = `${COOKIE}=${next ? '1' : '0'};path=/;max-age=31536000;samesite=lax`;
            }
            catch {
                // Cookie persistence can be unavailable; local interaction still works.
            }
            return next;
        });
    }, []);
    return (_jsxs("aside", { className: cn('hidden shrink-0 flex-col border-r border-border bg-surface transition-[width] duration-200 ease-out lg:flex', collapsed ? 'w-[4.25rem]' : 'w-60'), children: [_jsxs("div", { className: cn('flex h-14 items-center border-b border-border px-3', collapsed ? 'justify-center' : 'gap-2'), children: [collapsed ? null : _jsx("div", { className: "min-w-0 flex-1 truncate", children: brand }), collapsible ? (_jsx("button", { type: "button", onClick: toggle, "aria-label": collapsed ? expandLabel : collapseLabel, title: collapsed ? expandLabel : collapseLabel, className: cn('grid size-8 place-items-center rounded-md text-fg-subtle transition-colors hover:bg-surface-hover hover:text-fg', collapsed ? '' : 'ml-auto'), children: collapsed ? _jsx(PanelLeftOpen, { size: 17 }) : _jsx(PanelLeftClose, { size: 17 }) })) : null] }), _jsx(SidebarNav, { groups: groups, pathname: pathname, collapsed: collapsed, linkRender: linkRender }), footer || collapsedFooter ? (_jsx("div", { className: "border-t border-border p-3", children: collapsed ? collapsedFooter : footer })) : null] }));
}
//# sourceMappingURL=app-sidebar.js.map