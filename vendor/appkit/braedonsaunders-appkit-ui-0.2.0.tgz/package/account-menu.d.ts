import * as React from 'react';
import { type BadgeProps } from './badge.js';
export type AccountMenuOption = {
    value: string;
    label: string;
    description?: string;
};
export type AccountMenuChoice = {
    label: string;
    summary: string;
    value: string;
    options: AccountMenuOption[];
    onChange: (value: string) => void | Promise<void>;
};
export type AccountMenuLabels = {
    menu: string;
    account: string;
    theme: string;
    back: string;
    signOut: string;
    signingOut: string;
};
export type AccountMenuProps = {
    name: string;
    email: string;
    contextLabel?: string;
    contextTone?: 'default' | 'warning';
    roleLabel?: string;
    status?: {
        label: string;
        variant?: BadgeProps['variant'];
    };
    organization?: AccountMenuChoice;
    language?: AccountMenuChoice;
    navigation?: AccountMenuChoice;
    showTheme?: boolean;
    elevatedAccess?: {
        label: string;
        href: string;
    };
    onSignOut?: () => void | Promise<void>;
    labels?: Partial<AccountMenuLabels>;
};
/**
 * Bounded account launcher generalized into controlled choices.
 * Organization, language, layout persistence and sign-out stay app-owned.
 */
export declare function AccountMenu({ name, email, contextLabel, contextTone, roleLabel, status, organization, language, navigation, showTheme, elevatedAccess, onSignOut, labels: labelOverrides, }: AccountMenuProps): React.JSX.Element;
//# sourceMappingURL=account-menu.d.ts.map