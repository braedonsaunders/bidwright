import { type ClassValue } from 'clsx';
/** Merge Tailwind class lists with correct conflict resolution. */
export declare function cn(...inputs: ClassValue[]): string;
//# sourceMappingURL=utils.d.ts.map