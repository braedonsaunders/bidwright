import * as React from 'react';
import { type NavigationRegistryItem, type TenantNavigationConfig } from './navigation-config.js';
export type NavigationConfigEditorLabels = {
    title?: string;
    description?: string;
    visible?: string;
    hidden?: string;
    required?: string;
    moveUp?: (label: string) => string;
    moveDown?: (label: string) => string;
    drag?: (label: string) => string;
};
export type NavigationConfigEditorProps = {
    registry: readonly NavigationRegistryItem[];
    value?: TenantNavigationConfig | null;
    onChange: (config: TenantNavigationConfig) => void;
    disabled?: boolean;
    labels?: NavigationConfigEditorLabels;
    className?: string;
};
/**
 * Controlled tenant navigation editor extracted from the production sibling.
 * Persistence and authorization stay application-owned.
 */
export declare function NavigationConfigEditor({ registry, value, onChange, disabled, labels, className, }: NavigationConfigEditorProps): React.JSX.Element;
//# sourceMappingURL=navigation-config-editor.d.ts.map