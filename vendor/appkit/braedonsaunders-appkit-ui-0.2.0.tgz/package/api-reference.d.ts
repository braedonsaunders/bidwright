import * as React from 'react';
export type ApiParamDoc = {
    name: string;
    in?: 'query' | 'path' | 'header';
    type?: string;
    required?: boolean;
    description?: string;
};
export type ApiEndpointDoc = {
    method: string;
    path: string;
    summary?: string;
    description?: string;
    tag?: string;
    permission?: string;
    params?: ApiParamDoc[];
    requestExample?: unknown;
    responseExample?: unknown;
};
export declare function MethodBadge({ method, className }: {
    method: string;
    className?: string;
}): React.JSX.Element;
export declare function CodeBlock({ code, className }: {
    code: string;
    className?: string;
}): React.JSX.Element;
export declare function ApiEndpoint({ endpoint, baseUrl, apiKey, defaultOpen, }: {
    endpoint: ApiEndpointDoc;
    baseUrl?: string;
    apiKey?: string;
    defaultOpen?: boolean;
}): React.JSX.Element;
export declare function ApiReference({ endpoints, baseUrl, title, description, apiKey: initialApiKey, showBearerToken, className, }: {
    endpoints: ApiEndpointDoc[];
    baseUrl?: string;
    title?: string;
    description?: string;
    apiKey?: string;
    /** Show the optional bearer-token input beside the base URL. */
    showBearerToken?: boolean;
    className?: string;
}): React.JSX.Element;
//# sourceMappingURL=api-reference.d.ts.map