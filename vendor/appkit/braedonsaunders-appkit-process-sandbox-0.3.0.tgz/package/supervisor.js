import { randomUUID } from 'node:crypto';
import { Buffer } from 'node:buffer';
import { ProcessSandboxError, spawnBubblewrappedProcess, } from './index.js';
const DEFAULT_TIMEOUT_MS = 120_000;
const DEFAULT_RETENTION_MS = 15 * 60_000;
const DEFAULT_KILL_GRACE_MS = 2_000;
const DEFAULT_MAX_OUTPUT_BYTES = 64 * 1024;
const DEFAULT_MAX_REPLAY_EVENTS = 512;
const DEFAULT_MAX_EXECUTIONS = 256;
const EXECUTION_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
/**
 * Supervise sandboxed processes independently from the request that started
 * them. Stable IDs make starts idempotent, settled results stay reattachable,
 * and a bounded event window supports reconnecting stream consumers without
 * retaining unbounded logs in the host process.
 *
 * The default launcher remains the fail-closed bubblewrap implementation. A
 * different launcher can be injected for another isolation backend, but it
 * must return a normal Node ChildProcess and owns equivalent confinement.
 */
export class ProcessSandboxSupervisor {
    #launcher;
    #idFactory;
    #now;
    #defaultTimeoutMs;
    #defaultRetentionMs;
    #killGraceMs;
    #maxOutputBytes;
    #maxReplayEvents;
    #maxExecutions;
    #executions = new Map();
    #lastStartedAt = null;
    #lastFinishedAt = null;
    #lastError = null;
    constructor(options = {}) {
        this.#launcher = options.launcher ?? spawnBubblewrappedProcess;
        this.#idFactory = options.idFactory ?? randomUUID;
        this.#now = options.now ?? Date.now;
        this.#defaultTimeoutMs = positiveInteger(options.defaultTimeoutMs ?? DEFAULT_TIMEOUT_MS, 'defaultTimeoutMs');
        this.#defaultRetentionMs = positiveInteger(options.defaultRetentionMs ?? DEFAULT_RETENTION_MS, 'defaultRetentionMs');
        this.#killGraceMs = nonNegativeInteger(options.killGraceMs ?? DEFAULT_KILL_GRACE_MS, 'killGraceMs');
        this.#maxOutputBytes = positiveInteger(options.maxOutputBytes ?? DEFAULT_MAX_OUTPUT_BYTES, 'maxOutputBytes');
        this.#maxReplayEvents = positiveInteger(options.maxReplayEvents ?? DEFAULT_MAX_REPLAY_EVENTS, 'maxReplayEvents');
        this.#maxExecutions = positiveInteger(options.maxExecutions ?? DEFAULT_MAX_EXECUTIONS, 'maxExecutions');
    }
    /** Start once. Reusing a retained execution ID returns its existing snapshot. */
    start(options) {
        this.sweep();
        const id = cleanExecutionId(options.executionId ?? this.#idFactory());
        const existing = this.#executions.get(id);
        if (existing)
            return snapshotOf(existing, 0);
        this.#makeCapacity();
        const timeoutMs = positiveInteger(options.timeoutMs ?? this.#defaultTimeoutMs, 'timeoutMs');
        const retentionMs = positiveInteger(options.retentionMs ?? this.#defaultRetentionMs, 'retentionMs');
        const maxOutputBytes = positiveInteger(options.maxOutputBytes ?? this.#maxOutputBytes, 'maxOutputBytes');
        const maxReplayEvents = positiveInteger(options.maxReplayEvents ?? this.#maxReplayEvents, 'maxReplayEvents');
        let child;
        try {
            child = this.#launcher(options.process);
        }
        catch (error) {
            this.#lastError = errorMessage(error);
            throw error;
        }
        let resolveResult;
        const resultPromise = new Promise((resolvePromise) => {
            resolveResult = resolvePromise;
        });
        const startedAt = new Date(this.#now()).toISOString();
        const execution = {
            id,
            child,
            status: 'running',
            startedAt,
            finishedAt: null,
            events: [],
            nextSequence: 1,
            replayTruncated: false,
            outputParts: [],
            outputBytes: 0,
            outputTruncated: false,
            result: null,
            resultPromise,
            resolveResult,
            timeout: null,
            forceKill: null,
            requestedFinalStatus: null,
            retentionMs,
            maxOutputBytes,
            maxReplayEvents,
            expiresAt: null,
            waiters: new Set(),
        };
        this.#executions.set(id, execution);
        this.#lastStartedAt = startedAt;
        this.#appendEvent(execution, { type: 'started' });
        child.stdout?.on('data', (chunk) => {
            this.#appendOutput(execution, 'stdout', chunk);
        });
        child.stderr?.on('data', (chunk) => {
            this.#appendOutput(execution, 'stderr', chunk);
        });
        child.once('error', (error) => {
            this.#lastError = error.message;
            this.#finish(execution, 'failed', null, null);
        });
        child.once('exit', (code, signal) => {
            const status = execution.requestedFinalStatus
                ?? (code === 0 ? 'completed' : 'failed');
            this.#finish(execution, status, code, signal);
        });
        execution.timeout = setTimeout(() => {
            this.#requestStop(execution, 'timed_out');
        }, timeoutMs);
        execution.timeout.unref();
        return snapshotOf(execution, 0);
    }
    snapshot(executionId, afterSequence = 0) {
        this.sweep();
        const execution = this.#executions.get(cleanExecutionId(executionId));
        return execution ? snapshotOf(execution, cleanSequence(afterSequence)) : null;
    }
    /**
     * Wait until an event newer than `afterSequence` exists, the execution
     * settles, or the wait expires. This is suitable for HTTP long-polling: a
     * reconnect asks again with the last observed sequence and replays safely.
     */
    async waitForUpdate(executionId, afterSequence = 0, options = {}) {
        this.sweep();
        const id = cleanExecutionId(executionId);
        const sequence = cleanSequence(afterSequence);
        const execution = this.#executions.get(id);
        if (!execution)
            return null;
        const immediate = snapshotOf(execution, sequence);
        if (immediate.events.length > 0 || immediate.status !== 'running')
            return immediate;
        const timeoutMs = positiveInteger(options.timeoutMs ?? 25_000, 'timeoutMs');
        await new Promise((resolvePromise) => {
            let settled = false;
            const finish = () => {
                if (settled)
                    return;
                settled = true;
                clearTimeout(timeout);
                execution.waiters.delete(finish);
                options.signal?.removeEventListener('abort', finish);
                resolvePromise();
            };
            const timeout = setTimeout(finish, timeoutMs);
            timeout.unref();
            execution.waiters.add(finish);
            options.signal?.addEventListener('abort', finish, { once: true });
            // Close the event-registration race without delaying normal callers.
            if (execution.nextSequence - 1 > sequence || execution.status !== 'running')
                finish();
        });
        return this.snapshot(id, sequence);
    }
    result(executionId) {
        this.sweep();
        const execution = this.#executions.get(cleanExecutionId(executionId));
        if (!execution) {
            return Promise.reject(new ProcessSandboxError(`Unknown or expired execution: ${executionId}`));
        }
        return execution.resultPromise;
    }
    cancel(executionId) {
        this.sweep();
        const execution = this.#executions.get(cleanExecutionId(executionId));
        if (!execution || execution.status !== 'running')
            return false;
        this.#requestStop(execution, 'cancelled');
        return true;
    }
    /** Cancel if necessary, await termination, then forget all retained evidence. */
    async dispose(executionId) {
        const id = cleanExecutionId(executionId);
        const execution = this.#executions.get(id);
        if (!execution)
            return false;
        if (execution.status === 'running')
            this.#requestStop(execution, 'cancelled');
        await execution.resultPromise;
        this.#executions.delete(id);
        return true;
    }
    sweep() {
        const now = this.#now();
        let removed = 0;
        for (const [id, execution] of this.#executions) {
            if (execution.expiresAt !== null && execution.expiresAt <= now) {
                this.#executions.delete(id);
                removed += 1;
            }
        }
        return removed;
    }
    stats() {
        this.sweep();
        let active = 0;
        for (const execution of this.#executions.values()) {
            if (execution.status === 'running')
                active += 1;
        }
        return {
            active,
            retained: this.#executions.size - active,
            maxExecutions: this.#maxExecutions,
            lastStartedAt: this.#lastStartedAt,
            lastFinishedAt: this.#lastFinishedAt,
            lastError: this.#lastError,
        };
    }
    #appendOutput(execution, type, value) {
        if (execution.status !== 'running')
            return;
        const chunk = Buffer.isBuffer(value) ? value : Buffer.from(String(value));
        const remaining = execution.maxOutputBytes - execution.outputBytes;
        if (remaining <= 0) {
            execution.outputTruncated = true;
            return;
        }
        const kept = chunk.subarray(0, remaining);
        const data = kept.toString('utf8');
        if (data) {
            execution.outputParts.push(data);
            execution.outputBytes += kept.byteLength;
            this.#appendEvent(execution, { type, data });
        }
        if (kept.byteLength < chunk.byteLength)
            execution.outputTruncated = true;
    }
    #appendEvent(execution, event) {
        execution.events.push({
            ...event,
            sequence: execution.nextSequence,
            executionId: execution.id,
            timestamp: new Date(this.#now()).toISOString(),
        });
        execution.nextSequence += 1;
        while (execution.events.length > execution.maxReplayEvents) {
            execution.events.shift();
            execution.replayTruncated = true;
        }
        for (const waiter of [...execution.waiters])
            waiter();
    }
    #requestStop(execution, status) {
        if (execution.status !== 'running' || execution.requestedFinalStatus)
            return;
        execution.requestedFinalStatus = status;
        execution.child.kill('SIGTERM');
        execution.forceKill = setTimeout(() => {
            if (execution.status === 'running')
                execution.child.kill('SIGKILL');
        }, this.#killGraceMs);
        execution.forceKill.unref();
    }
    #finish(execution, status, exitCode, signal) {
        if (execution.status !== 'running')
            return;
        if (execution.timeout)
            clearTimeout(execution.timeout);
        if (execution.forceKill)
            clearTimeout(execution.forceKill);
        execution.status = status;
        execution.finishedAt = new Date(this.#now()).toISOString();
        execution.expiresAt = this.#now() + execution.retentionMs;
        this.#lastFinishedAt = execution.finishedAt;
        this.#appendEvent(execution, { type: 'finished', status, exitCode, signal });
        const output = execution.outputParts.join('')
            + (execution.outputTruncated ? '\n[output truncated]' : '');
        execution.result = {
            executionId: execution.id,
            status,
            exitCode,
            signal,
            startedAt: execution.startedAt,
            finishedAt: execution.finishedAt,
            output,
            outputTruncated: execution.outputTruncated,
        };
        execution.resolveResult(execution.result);
    }
    #makeCapacity() {
        if (this.#executions.size < this.#maxExecutions)
            return;
        const settled = [...this.#executions.values()]
            .filter((execution) => execution.status !== 'running')
            .sort((left, right) => (left.finishedAt ?? '').localeCompare(right.finishedAt ?? ''));
        while (this.#executions.size >= this.#maxExecutions && settled.length > 0) {
            const execution = settled.shift();
            if (execution)
                this.#executions.delete(execution.id);
        }
        if (this.#executions.size >= this.#maxExecutions) {
            throw new ProcessSandboxError(`Process supervisor is at its ${this.#maxExecutions}-execution capacity.`);
        }
    }
}
function snapshotOf(execution, afterSequence) {
    return {
        executionId: execution.id,
        status: execution.status,
        startedAt: execution.startedAt,
        finishedAt: execution.finishedAt,
        events: execution.events.filter((event) => event.sequence > afterSequence),
        latestSequence: execution.nextSequence - 1,
        replayTruncated: execution.replayTruncated
            && (execution.events[0]?.sequence ?? execution.nextSequence) > afterSequence + 1,
        result: execution.result,
    };
}
function cleanExecutionId(value) {
    if (!EXECUTION_ID_PATTERN.test(value)) {
        throw new ProcessSandboxError('executionId must be 1–128 URL-safe letters, numbers, dots, underscores, colons, or hyphens.');
    }
    return value;
}
function cleanSequence(value) {
    return nonNegativeInteger(value, 'afterSequence');
}
function positiveInteger(value, field) {
    if (!Number.isInteger(value) || value < 1) {
        throw new ProcessSandboxError(`${field} must be a positive integer.`);
    }
    return value;
}
function nonNegativeInteger(value, field) {
    if (!Number.isInteger(value) || value < 0) {
        throw new ProcessSandboxError(`${field} must be a non-negative integer.`);
    }
    return value;
}
function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
//# sourceMappingURL=supervisor.js.map