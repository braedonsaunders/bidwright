import type { ChildProcess } from 'node:child_process';
import { type ProcessSandboxOptions } from './index.js';
export type ProcessSandboxExecutionStatus = 'running' | 'completed' | 'failed' | 'cancelled' | 'timed_out';
export type ProcessSandboxExecutionEvent = {
    sequence: number;
    executionId: string;
    timestamp: string;
} & ({
    type: 'started';
} | {
    type: 'stdout' | 'stderr';
    data: string;
} | {
    type: 'finished';
    status: Exclude<ProcessSandboxExecutionStatus, 'running'>;
    exitCode: number | null;
    signal: NodeJS.Signals | null;
});
export interface ProcessSandboxExecutionResult {
    executionId: string;
    status: Exclude<ProcessSandboxExecutionStatus, 'running'>;
    exitCode: number | null;
    signal: NodeJS.Signals | null;
    startedAt: string;
    finishedAt: string;
    output: string;
    outputTruncated: boolean;
}
export interface ProcessSandboxExecutionSnapshot {
    executionId: string;
    status: ProcessSandboxExecutionStatus;
    startedAt: string;
    finishedAt: string | null;
    /** Events strictly newer than the sequence supplied to `snapshot()` or `waitForUpdate()`. */
    events: ProcessSandboxExecutionEvent[];
    /** Latest sequence produced, even when there are no new events in this snapshot. */
    latestSequence: number;
    /** True when older stream events fell out of the bounded replay window. */
    replayTruncated: boolean;
    result: ProcessSandboxExecutionResult | null;
}
export interface ProcessSandboxExecutionOptions {
    /** A caller-supplied idempotency and reattachment key. Generated when omitted. */
    executionId?: string;
    process: ProcessSandboxOptions;
    timeoutMs?: number;
    /** How long the settled result remains reattachable in this supervisor. */
    retentionMs?: number;
    /** Per-execution retained output ceiling; defaults to the supervisor policy. */
    maxOutputBytes?: number;
    /** Per-execution replay event ceiling; defaults to the supervisor policy. */
    maxReplayEvents?: number;
}
export interface ProcessSandboxSupervisorOptions {
    launcher?: (options: ProcessSandboxOptions) => ChildProcess;
    idFactory?: () => string;
    now?: () => number;
    defaultTimeoutMs?: number;
    defaultRetentionMs?: number;
    killGraceMs?: number;
    maxOutputBytes?: number;
    maxReplayEvents?: number;
    maxExecutions?: number;
}
export interface ProcessSandboxSupervisorStats {
    active: number;
    retained: number;
    maxExecutions: number;
    lastStartedAt: string | null;
    lastFinishedAt: string | null;
    lastError: string | null;
}
/**
 * Supervise sandboxed processes independently from the request that started
 * them. Stable IDs make starts idempotent, settled results stay reattachable,
 * and a bounded event window supports reconnecting stream consumers without
 * retaining unbounded logs in the host process.
 *
 * The default launcher remains the fail-closed bubblewrap implementation. A
 * different launcher can be injected for another isolation backend, but it
 * must return a normal Node ChildProcess and owns equivalent confinement.
 */
export declare class ProcessSandboxSupervisor {
    #private;
    constructor(options?: ProcessSandboxSupervisorOptions);
    /** Start once. Reusing a retained execution ID returns its existing snapshot. */
    start(options: ProcessSandboxExecutionOptions): ProcessSandboxExecutionSnapshot;
    snapshot(executionId: string, afterSequence?: number): ProcessSandboxExecutionSnapshot | null;
    /**
     * Wait until an event newer than `afterSequence` exists, the execution
     * settles, or the wait expires. This is suitable for HTTP long-polling: a
     * reconnect asks again with the last observed sequence and replays safely.
     */
    waitForUpdate(executionId: string, afterSequence?: number, options?: {
        timeoutMs?: number;
        signal?: AbortSignal;
    }): Promise<ProcessSandboxExecutionSnapshot | null>;
    result(executionId: string): Promise<ProcessSandboxExecutionResult>;
    cancel(executionId: string): boolean;
    /** Cancel if necessary, await termination, then forget all retained evidence. */
    dispose(executionId: string): Promise<boolean>;
    sweep(): number;
    stats(): ProcessSandboxSupervisorStats;
}
//# sourceMappingURL=supervisor.d.ts.map