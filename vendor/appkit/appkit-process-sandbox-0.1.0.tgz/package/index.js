import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { dirname, isAbsolute, relative, resolve, sep } from 'node:path';
export const DEFAULT_BUBBLEWRAP_PATH = '/usr/bin/bwrap';
export const DEFAULT_PROCESS_PATH = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin';
export const DEFAULT_READ_ONLY_PATHS = ['/usr', '/etc', '/opt', '/app'];
export const DEFAULT_MASKED_PATHS = ['/data', '/home', '/root', '/var'];
export class ProcessSandboxError extends Error {
    name = 'ProcessSandboxError';
}
/** Whether this host can run the Linux bubblewrap implementation. */
export function isProcessSandboxSupported(options = {}) {
    const platform = options.platform ?? process.platform;
    const pathExists = options.pathExists ?? existsSync;
    return platform === 'linux' && pathExists(options.bubblewrapPath ?? DEFAULT_BUBBLEWRAP_PATH);
}
/**
 * Build the deterministic bubblewrap invocation without spawning it. This is
 * useful for audit logs, deployment readiness checks, tests, and admin UIs.
 */
export function buildBubblewrapPlan(options, dependencies = {}) {
    const pathExists = dependencies.pathExists ?? existsSync;
    const cwd = absolutePath(options.cwd, 'cwd');
    const writablePaths = uniquePaths(options.writablePaths, 'writablePaths');
    if (!writablePaths.some((path) => containsPath(path, cwd))) {
        throw new ProcessSandboxError('Sandbox cwd must be contained by a writable path.');
    }
    const readOnlyPaths = uniquePaths(options.readOnlyPaths ?? DEFAULT_READ_ONLY_PATHS, 'readOnlyPaths').filter(pathExists);
    const maskedPaths = uniquePaths(options.maskedPaths ?? DEFAULT_MASKED_PATHS, 'maskedPaths');
    const bubblewrapPath = absolutePath(options.bubblewrapPath ?? DEFAULT_BUBBLEWRAP_PATH, 'bubblewrapPath');
    const environment = cleanEnvironment(options.environment);
    if (!('PATH' in environment))
        environment.PATH = DEFAULT_PROCESS_PATH;
    const args = [
        '--unshare-user',
        '--uid', '0',
        '--gid', '0',
        '--unshare-pid',
        '--unshare-ipc',
        '--unshare-uts',
        '--unshare-cgroup-try',
        '--cap-drop', 'ALL',
        '--new-session',
        '--die-with-parent',
        ...readOnlyPaths.flatMap((path) => ['--ro-bind', path, path]),
    ];
    if (isAbsolute(options.command)) {
        const commandDirectory = dirname(resolve(options.command));
        if (pathExists(commandDirectory)
            && !readOnlyPaths.some((path) => containsPath(path, commandDirectory))
            && !writablePaths.some((path) => containsPath(path, commandDirectory))) {
            args.push('--ro-bind', commandDirectory, commandDirectory);
        }
    }
    args.push('--symlink', 'usr/bin', '/bin', '--symlink', 'usr/sbin', '/sbin', '--symlink', 'usr/lib', '/lib');
    if (pathExists('/usr/lib64'))
        args.push('--symlink', 'usr/lib64', '/lib64');
    args.push(...maskedPaths.flatMap((path) => ['--tmpfs', path]), '--tmpfs', '/tmp', '--tmpfs', '/run', '--proc', '/proc', '--dev', '/dev', ...writablePaths.flatMap((path) => ['--bind', path, path]), '--chdir', cwd);
    args.push('--', options.command, ...(options.args ?? []));
    return {
        command: bubblewrapPath,
        args,
        environment,
        cwd,
        writablePaths,
        readOnlyPaths,
        maskedPaths,
    };
}
/**
 * Spawn a process under the shared Linux isolation policy. This function is
 * deliberately fail-closed: unsupported platforms, missing binaries, and
 * missing bind sources throw instead of silently running the command directly.
 */
export function spawnBubblewrappedProcess(options) {
    if (process.platform !== 'linux') {
        throw new ProcessSandboxError(`The AppKit process sandbox requires Linux; received ${process.platform}.`);
    }
    const plan = buildBubblewrapPlan(options);
    if (!existsSync(plan.command)) {
        throw new ProcessSandboxError(`Bubblewrap was not found at ${plan.command}. Install bubblewrap or configure bubblewrapPath.`);
    }
    for (const path of plan.writablePaths) {
        if (!existsSync(path)) {
            throw new ProcessSandboxError(`Writable sandbox path does not exist: ${path}`);
        }
    }
    return spawn(plan.command, plan.args, {
        // Supplying an explicit environment prevents host inheritance without
        // serializing secret values into bwrap argv via `--setenv`.
        env: plan.environment,
        stdio: options.stdio ?? ['ignore', 'pipe', 'pipe'],
    });
}
function absolutePath(value, field) {
    if (!value || !isAbsolute(value)) {
        throw new ProcessSandboxError(`${field} must be an absolute path.`);
    }
    return resolve(value);
}
function uniquePaths(values, field) {
    return [...new Set(values.map((value) => absolutePath(value, field)))];
}
function containsPath(parent, child) {
    const path = relative(parent, child);
    return path === '' || (path !== '..' && !path.startsWith(`..${sep}`) && !isAbsolute(path));
}
function cleanEnvironment(environment) {
    const clean = {};
    for (const [key, value] of Object.entries(environment ?? {})) {
        if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) {
            throw new ProcessSandboxError(`Invalid environment variable name: ${key}`);
        }
        if (typeof value === 'string')
            clean[key] = value;
    }
    return clean;
}
//# sourceMappingURL=index.js.map