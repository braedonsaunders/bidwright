import * as React from 'react';
import type { PermissionGroup } from './types.js';
export type PermissionMatrixProps = {
    groups: PermissionGroup[];
    value: string[];
    onChange?: (permissions: string[]) => void;
    name?: string;
    readOnly?: boolean;
    labels?: Partial<{
        selected: (selected: number, total: number) => React.ReactNode;
        selectAll: string;
        clearAll: string;
        partial: string;
    }>;
};
/** Faithful grouped permission picker with global and per-group bulk controls. */
export declare function PermissionMatrix({ groups, value, onChange, name, readOnly, labels, }: PermissionMatrixProps): React.JSX.Element;
//# sourceMappingURL=permission-matrix.d.ts.map