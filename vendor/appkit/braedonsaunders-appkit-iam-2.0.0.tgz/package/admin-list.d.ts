import type { ListResult } from './types.js';
export declare function SortButton({ label, active, direction, onClick, }: {
    label: string;
    active: boolean;
    direction: 'asc' | 'desc';
    onClick: () => void;
}): import("react").JSX.Element;
export declare function ServicePagination({ page, perPage, total, onPage, }: {
    page: number;
    perPage: number;
    total: number;
    onPage: (page: number) => void;
}): import("react").JSX.Element;
/** Load a bounded service catalogue across every page for pickers and bulk tools. */
export declare function collectAll<T>(load: (page: number, perPage: number) => Promise<ListResult<T>>): Promise<T[]>;
//# sourceMappingURL=admin-list.d.ts.map