'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Checkbox, cn } from '@braedonsaunders/appkit-ui';
/** Faithful grouped permission picker with global and per-group bulk controls. */
export function PermissionMatrix({ groups, value, onChange, name, readOnly = false, labels, }) {
    const selected = React.useMemo(() => new Set(value), [value]);
    const allKeys = React.useMemo(() => groups.flatMap((group) => group.permissions.map((permission) => permission.key)), [groups]);
    const allOn = allKeys.length > 0 && allKeys.every((key) => selected.has(key));
    function setMany(keys, enabled) {
        if (readOnly || !onChange)
            return;
        const next = new Set(selected);
        for (const key of keys)
            enabled ? next.add(key) : next.delete(key);
        onChange(allKeys.filter((key) => next.has(key)));
    }
    return (_jsxs("div", { className: "space-y-4", children: [_jsxs("div", { className: "flex items-center justify-between gap-4", children: [_jsx("span", { className: "text-sm text-fg-muted", children: labels?.selected?.(selected.size, allKeys.length) ?? `${selected.size} of ${allKeys.length} selected` }), _jsx("button", { type: "button", onClick: () => setMany(allKeys, !allOn), disabled: readOnly || !onChange, className: "text-xs font-medium text-primary hover:underline disabled:cursor-not-allowed disabled:text-fg-subtle disabled:no-underline", children: allOn ? (labels?.clearAll ?? 'Clear all') : (labels?.selectAll ?? 'Select all') })] }), groups.map((group) => {
                const keys = group.permissions.map((permission) => permission.key);
                const groupOn = keys.length > 0 && keys.every((key) => selected.has(key));
                const groupSome = !groupOn && keys.some((key) => selected.has(key));
                return (_jsxs("section", { className: "overflow-hidden rounded-lg border border-border", children: [_jsxs("div", { className: "flex items-center justify-between gap-4 border-b border-border bg-bg-subtle px-3 py-2", children: [_jsxs("div", { className: "min-w-0", children: [_jsxs("h3", { className: "text-sm font-semibold text-fg", children: [group.label, groupSome ? _jsx("span", { className: "ml-1.5 text-xs font-normal text-fg-subtle", children: labels?.partial ?? 'Partial' }) : null] }), group.description ? _jsx("p", { className: "mt-0.5 text-xs text-fg-muted", children: group.description }) : null] }), _jsx("button", { type: "button", onClick: () => setMany(keys, !groupOn), disabled: readOnly || !onChange, className: "shrink-0 text-xs font-medium text-primary hover:underline disabled:cursor-not-allowed disabled:text-fg-subtle disabled:no-underline", children: groupOn ? (labels?.clearAll ?? 'Clear all') : (labels?.selectAll ?? 'Select all') })] }), _jsx("ul", { className: "grid gap-x-4 gap-y-1 p-3 sm:grid-cols-2", children: group.permissions.map((permission) => {
                                const checked = selected.has(permission.key);
                                return (_jsx("li", { children: _jsxs("label", { className: cn('flex items-start gap-2 rounded-md px-2 py-1.5 text-sm transition-colors', readOnly || !onChange ? 'cursor-default' : 'cursor-pointer hover:bg-surface-hover', checked ? 'text-fg' : 'text-fg-muted'), children: [_jsx(Checkbox, { name: name, value: permission.key, checked: checked, onChange: () => setMany([permission.key], !checked), disabled: readOnly || !onChange, className: "mt-0.5 shrink-0" }), _jsxs("span", { className: "min-w-0", children: [_jsx("span", { className: "block", children: permission.label }), permission.description ? _jsx("span", { className: "mt-0.5 block text-xs text-fg-subtle", children: permission.description }) : null] })] }) }, permission.key));
                            }) })] }, group.key));
            })] }));
}
//# sourceMappingURL=permission-matrix.js.map