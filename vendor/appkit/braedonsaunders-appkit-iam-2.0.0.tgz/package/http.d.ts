import type { IamAdminService } from './types.js';
declare const METHODS: readonly ["listRoles", "getRole", "createRole", "updateRole", "duplicateRole", "deleteRole", "bulkUpdateRoleAssignments", "listMembers", "getMember", "inviteMember", "updateMember", "removeMember", "resendInvite", "assignRole", "updateAssignmentScope", "removeAssignment", "setPermissionOverride", "removePermissionOverride", "listAuditEvents", "getAuditEvent"];
type Method = (typeof METHODS)[number];
export declare class IamHttpAuthorizationError extends Error {
    readonly status: 401 | 403;
    constructor(message?: string, status?: 401 | 403);
}
export type IamHttpHandlerOptions = {
    /** Resolve an already tenant-bound service for this authenticated request. */
    resolveService: (request: Request) => Promise<IamAdminService>;
    /** Required authorization gate, evaluated before the service is resolved. */
    authorize: (request: Request, method: Method) => Promise<void>;
    maxBodyBytes?: number;
};
/** Framework-neutral authenticated RPC transport for the full IAM contract. */
export declare function createIamHttpHandler(options: IamHttpHandlerOptions): (request: Request) => Promise<Response>;
export type IamHttpClientOptions = {
    endpoint: string;
    fetch?: typeof globalThis.fetch;
    headers?: HeadersInit | (() => HeadersInit | Promise<HeadersInit>);
};
/** Browser/server client implementing the same contract as memory and Drizzle. */
export declare function createHttpIamService(options: IamHttpClientOptions): IamAdminService;
export {};
//# sourceMappingURL=http.d.ts.map