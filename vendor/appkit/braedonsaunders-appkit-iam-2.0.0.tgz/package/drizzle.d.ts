import type { PgDatabase } from 'drizzle-orm/pg-core';
import type { PgQueryResultHKT } from 'drizzle-orm/pg-core/session';
import type { IamAdminService, MemberCapabilities, MemberRecord, RoleCapabilities, RoleRecord } from './types.js';
/** Database-neutral contract shared by Drizzle's node-postgres and postgres-js drivers. */
export type IamDatabase<TQueryResult extends PgQueryResultHKT = PgQueryResultHKT, TSchema extends Record<string, unknown> = Record<string, never>> = PgDatabase<TQueryResult, TSchema>;
export type DrizzleIamOptions<TQueryResult extends PgQueryResultHKT = PgQueryResultHKT, TSchema extends Record<string, unknown> = Record<string, never>> = {
    db: IamDatabase<TQueryResult, TSchema>;
    tenantId: string;
    actor: {
        userId: string;
        name?: string;
        isSuperAdmin?: boolean;
    };
    currentMembershipId?: string;
    /** Enqueue or deliver an initial or rotated identity-provider invitation. */
    afterInvitePersisted?: (member: MemberRecord, reason: 'initial' | 'resend') => Promise<void>;
    permissionCatalogue?: readonly string[];
    roleCapabilities?: (role: RoleRecord) => RoleCapabilities;
    memberCapabilities?: (member: MemberRecord) => MemberCapabilities;
    maxBulkMembers?: number;
    hooks?: DrizzleIamHooks<TQueryResult, TSchema>;
};
export type DrizzleIamHooks<TQueryResult extends PgQueryResultHKT = PgQueryResultHKT, TSchema extends Record<string, unknown> = Record<string, never>> = {
    /** Application-owned referential guards run inside the delete transaction. */
    beforeDeleteRole?: (tx: IamDatabase<TQueryResult, TSchema>, role: RoleRecord) => Promise<void>;
    /** Reconcile dashboards, policies, or other role-owned projections atomically. */
    afterRoleChanged?: (tx: IamDatabase<TQueryResult, TSchema>, input: {
        before: RoleRecord | null;
        after: RoleRecord;
        reason: 'create' | 'update' | 'duplicate';
        source?: RoleRecord;
    }) => Promise<void>;
    /** Reconcile application-owned access projections atomically with IAM writes. */
    afterMembershipAccessChanged?: (tx: IamDatabase<TQueryResult, TSchema>, input: {
        membershipIds: string[];
        reason: 'invite' | 'status' | 'remove' | 'assign' | 'scope' | 'unassign' | 'bulk' | 'override';
    }) => Promise<void>;
};
/** Postgres/RLS implementation of the complete IAM administration contract. */
export declare function createDrizzleIamService<TQueryResult extends PgQueryResultHKT, TSchema extends Record<string, unknown>>(options: DrizzleIamOptions<TQueryResult, TSchema>): IamAdminService;
//# sourceMappingURL=drizzle.d.ts.map