'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import * as React from 'react';
import { Badge, Drawer, EmptyState, Input, SearchSelect, Table, TableBody, TableCell, TableHead, TableHeader, TableRow, cn, } from '@braedonsaunders/appkit-ui';
import { Braces, ChevronRight, Clock3, Database, Fingerprint, History, Search, ScrollText, UserRound } from 'lucide-react';
import { ServicePagination, SortButton } from './admin-list.js';
const ACTION_VARIANT = {
    insert: 'success', create: 'success', update: 'secondary', delete: 'destructive',
    post: 'success', void: 'warning', approve: 'success', reject: 'destructive',
};
export function AuditAdmin({ service, title = 'Audit log', description = 'Search activity and inspect field-level changes, snapshots, and request context.', onError, actions: actionOptions, recordTypes: recordTypeOptions, }) {
    const [events, setEvents] = React.useState([]);
    const [query, setQuery] = React.useState('');
    const deferredQuery = React.useDeferredValue(query);
    const [action, setAction] = React.useState('');
    const [recordType, setRecordType] = React.useState('');
    const [selectedId, setSelectedId] = React.useState(null);
    const [sort, setSort] = React.useState('at');
    const [direction, setDirection] = React.useState('desc');
    const [page, setPage] = React.useState(1);
    const [total, setTotal] = React.useState(0);
    const [facets, setFacets] = React.useState({ actions: [], recordTypes: [] });
    const [loading, setLoading] = React.useState(true);
    const [error, setError] = React.useState(null);
    const load = React.useCallback(async () => {
        setLoading(true);
        try {
            const result = await service.listAuditEvents({ q: deferredQuery || undefined, action: action || undefined, recordType: recordType || undefined, page, perPage: 25, sort, direction });
            setEvents(result.rows);
            setTotal(result.total);
            setFacets(result.facets);
            setError(null);
        }
        catch (cause) {
            setError(cause instanceof Error ? cause.message : 'Unable to load audit events.');
            onError?.(cause);
        }
        finally {
            setLoading(false);
        }
    }, [action, deferredQuery, direction, onError, page, recordType, service, sort]);
    React.useEffect(() => { void load(); }, [load]);
    const actions = actionOptions ?? facets.actions;
    const recordTypes = recordTypeOptions ?? facets.recordTypes;
    const selected = events.find((event) => event.id === selectedId) ?? null;
    React.useEffect(() => { setPage(1); }, [action, deferredQuery, recordType]);
    function changeSort(next) {
        if (sort === next)
            setDirection((value) => value === 'asc' ? 'desc' : 'asc');
        else {
            setSort(next);
            setDirection(next === 'at' ? 'desc' : 'asc');
        }
        setPage(1);
    }
    return _jsxs("div", { className: "flex min-h-0 flex-1 flex-col gap-5", children: [_jsxs("div", { children: [_jsx("h1", { className: "text-2xl font-semibold tracking-tight text-fg", children: title }), _jsx("p", { className: "mt-1 max-w-3xl text-sm text-fg-muted", children: description })] }), _jsxs("div", { className: "flex flex-wrap gap-2", children: [_jsxs("div", { className: "relative min-w-64 flex-1 sm:max-w-md", children: [_jsx(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-fg-subtle" }), _jsx(Input, { value: query, onChange: (event) => setQuery(event.target.value), placeholder: "Search actor, action, record, or reference\u2026", className: "pl-9" })] }), _jsx("div", { className: "w-40", children: _jsx(SearchSelect, { value: action, onChange: setAction, options: [{ value: '', label: 'All actions' }, ...actions.map((value) => ({ value, label: humanize(value) }))] }) }), _jsx("div", { className: "w-48", children: _jsx(SearchSelect, { value: recordType, onChange: setRecordType, options: [{ value: '', label: 'All record types' }, ...recordTypes.map((value) => ({ value, label: humanize(value) }))] }) })] }), error ? _jsx("div", { role: "alert", className: "rounded-lg border border-danger/30 bg-danger-subtle px-4 py-3 text-sm text-danger", children: error }) : null, _jsx("div", { className: "overflow-x-auto rounded-xl border border-border bg-surface", children: _jsxs(Table, { children: [_jsx(TableHeader, { children: _jsxs(TableRow, { noAnimate: true, children: [_jsx(TableHead, { children: _jsx(SortButton, { label: "When", active: sort === 'at', direction: direction, onClick: () => changeSort('at') }) }), _jsx(TableHead, { children: _jsx(SortButton, { label: "Actor", active: sort === 'actor', direction: direction, onClick: () => changeSort('actor') }) }), _jsx(TableHead, { children: _jsx(SortButton, { label: "Action", active: sort === 'action', direction: direction, onClick: () => changeSort('action') }) }), _jsx(TableHead, { children: _jsx(SortButton, { label: "Record", active: sort === 'record', direction: direction, onClick: () => changeSort('record') }) }), _jsx(TableHead, { children: "Reference" }), _jsx(TableHead, { children: "Changes" })] }) }), _jsxs(TableBody, { children: [events.map((event) => { const count = collectDiffs(event.before, event.after).length; return _jsxs(TableRow, { role: "button", tabIndex: 0, className: "group cursor-pointer", onClick: () => setSelectedId(event.id), onKeyDown: (keyEvent) => { if (keyEvent.key === 'Enter' || keyEvent.key === ' ') {
                                        keyEvent.preventDefault();
                                        setSelectedId(event.id);
                                    } }, children: [_jsx(TableCell, { className: "whitespace-nowrap", children: event.at.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) }), _jsx(TableCell, { children: event.actorName ?? _jsx("span", { className: "text-fg-subtle", children: "System" }) }), _jsx(TableCell, { children: _jsx(Badge, { variant: ACTION_VARIANT[event.action] ?? 'secondary', children: humanize(event.action) }) }), _jsx(TableCell, { className: "font-medium text-fg", children: humanize(event.recordType) }), _jsx(TableCell, { className: "font-mono text-xs text-fg-muted", children: event.recordId ? `${event.recordId.slice(0, 8)}…` : '—' }), _jsx(TableCell, { children: _jsxs("span", { className: "flex items-center justify-between gap-3 text-sm text-fg-muted", children: [_jsx("span", { children: event.summary ?? `${count} ${count === 1 ? 'field' : 'fields'}` }), _jsx(ChevronRight, { size: 16, className: "shrink-0 text-fg-subtle transition-transform group-hover:translate-x-0.5 group-hover:text-primary" })] }) })] }, event.id); }), !loading && events.length === 0 ? _jsx(TableRow, { noAnimate: true, children: _jsx(TableCell, { colSpan: 6, children: _jsx(EmptyState, { icon: _jsx(ScrollText, {}), title: "No audit events found", description: "Try a different search or filter.", className: "border-0 bg-transparent py-10 shadow-none" }) }) }) : null] })] }) }), _jsx(ServicePagination, { page: page, perPage: 25, total: total, onPage: setPage }), selected ? _jsx(AuditEventDrawer, { event: selected, onClose: () => setSelectedId(null) }) : null] });
}
export function AuditEventDrawer({ event, onClose }) {
    const hasBefore = event.before !== null && event.before !== undefined;
    const hasAfter = event.after !== null && event.after !== undefined;
    const tabs = ['changes', ...(hasBefore ? ['before'] : []), ...(hasAfter ? ['after'] : [])];
    const [activeTab, setActiveTab] = React.useState('changes');
    const diffs = React.useMemo(() => collectDiffs(event.before, event.after), [event.after, event.before]);
    return _jsx(Drawer, { open: true, onClose: onClose, size: "2xl", title: _jsxs("span", { className: "flex flex-wrap items-center gap-2.5", children: [_jsx("span", { children: humanize(event.recordType) }), _jsx(Badge, { variant: ACTION_VARIANT[event.action] ?? 'secondary', children: humanize(event.action) })] }), description: `${event.actorName ?? 'System'} · ${event.at.toLocaleString(undefined, { dateStyle: 'long', timeStyle: 'medium' })}`, subtabs: _jsx("nav", { className: "-mb-px flex gap-1 overflow-x-auto", "aria-label": "Audit event sections", children: tabs.map((tab) => _jsx("button", { type: "button", onClick: () => setActiveTab(tab), className: cn('shrink-0 border-b-2 px-3 py-3 text-sm font-medium transition-colors', activeTab === tab ? 'border-primary text-primary' : 'border-transparent text-fg-muted hover:border-border-strong hover:text-fg'), children: humanize(tab) }, tab)) }), children: _jsxs("div", { className: "space-y-6 pb-2", children: [_jsxs("div", { className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-4", children: [_jsx(MetadataCard, { icon: _jsx(Clock3, { size: 14 }), label: "When", children: event.at.toLocaleString() }), _jsx(MetadataCard, { icon: _jsx(UserRound, { size: 14 }), label: "Actor", children: event.actorName ?? 'System' }), _jsx(MetadataCard, { icon: _jsx(Database, { size: 14 }), label: "Record type", children: humanize(event.recordType) }), _jsx(MetadataCard, { icon: _jsx(Fingerprint, { size: 14 }), label: "Reference", children: _jsx("span", { className: "font-mono text-xs", children: event.recordId ?? '—' }) })] }), activeTab === 'changes' ? _jsxs(_Fragment, { children: [_jsxs("section", { className: "space-y-3", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(History, { size: 17, className: "text-primary" }), _jsx("h3", { className: "text-sm font-semibold text-fg", children: "Changed fields" })] }), _jsx(DiffList, { rows: diffs })] }), Object.keys(event.metadata).length > 0 ? _jsxs("section", { className: "space-y-3", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Braces, { size: 17, className: "text-primary" }), _jsx("h3", { className: "text-sm font-semibold text-fg", children: "Event context" })] }), _jsx(JsonValue, { value: event.metadata })] }) : null, _jsxs("section", { className: "space-y-3", children: [_jsx("h3", { className: "text-sm font-semibold text-fg", children: "Technical details" }), _jsx(JsonValue, { value: { eventId: event.id, requestId: event.requestId, actorUserId: event.actorUserId } })] })] }) : null, activeTab === 'before' ? _jsxs("section", { className: "space-y-3", children: [_jsx("h3", { className: "text-sm font-semibold text-fg", children: "Before snapshot" }), _jsx(JsonValue, { value: event.before })] }) : null, activeTab === 'after' ? _jsxs("section", { className: "space-y-3", children: [_jsx("h3", { className: "text-sm font-semibold text-fg", children: "After snapshot" }), _jsx(JsonValue, { value: event.after })] }) : null] }) });
}
function DiffList({ rows }) {
    if (!rows.length)
        return _jsx("div", { className: "rounded-lg border border-dashed border-border px-4 py-8 text-center text-sm text-fg-muted", children: "No field-level differences were recorded." });
    const grouped = new Map();
    for (const row of rows) {
        const group = row.path.split('.')[0] || 'event';
        const values = grouped.get(group) ?? [];
        values.push(row);
        grouped.set(group, values);
    }
    return _jsx("div", { className: "space-y-3", children: [...grouped.entries()].map(([group, values]) => _jsxs("details", { open: true, className: "overflow-hidden rounded-xl border border-border bg-surface shadow-sm", children: [_jsxs("summary", { className: "flex cursor-pointer list-none items-center justify-between gap-3 bg-bg-subtle px-4 py-3 marker:hidden", children: [_jsx("span", { className: "font-medium text-fg", children: humanize(group) }), _jsx(Badge, { variant: "secondary", children: values.length })] }), _jsxs("div", { className: "border-t border-border", children: [_jsxs("div", { className: "hidden grid-cols-[minmax(10rem,0.6fr)_minmax(0,1fr)_minmax(0,1fr)] gap-4 bg-bg-subtle px-4 py-2 text-[11px] font-medium uppercase tracking-wide text-fg-muted sm:grid", children: [_jsx("span", { children: "Field" }), _jsx("span", { children: "Before" }), _jsx("span", { children: "After" })] }), values.map((row, index) => _jsxs("div", { className: cn('grid gap-2 px-4 py-3 text-sm sm:grid-cols-[minmax(10rem,0.6fr)_minmax(0,1fr)_minmax(0,1fr)] sm:gap-4', index > 0 && 'border-t border-border'), children: [_jsx("div", { className: "font-medium text-fg", children: formatPath(row.path) }), _jsxs("div", { className: "min-w-0 rounded-md bg-danger-subtle px-2.5 py-1.5 text-fg", children: [_jsx("span", { className: "mb-1 block text-[10px] font-medium uppercase tracking-wide text-danger sm:hidden", children: "Before" }), _jsx(CompactValue, { value: row.before })] }), _jsxs("div", { className: "min-w-0 rounded-md bg-success-subtle px-2.5 py-1.5 text-fg", children: [_jsx("span", { className: "mb-1 block text-[10px] font-medium uppercase tracking-wide text-success sm:hidden", children: "After" }), _jsx(CompactValue, { value: row.after })] })] }, row.path))] })] }, group)) });
}
function JsonValue({ value }) {
    if (!Array.isArray(value) && !isObject(value))
        return _jsx(CompactValue, { value: value });
    if (Array.isArray(value))
        return value.length ? _jsx("div", { className: "space-y-2", children: value.map((item, index) => _jsxs("details", { className: "overflow-hidden rounded-lg border border-border bg-surface", children: [_jsxs("summary", { className: "cursor-pointer px-3 py-2.5 text-sm font-medium text-fg hover:bg-surface-hover", children: ["Item ", index + 1] }), _jsx("div", { className: "border-t border-border p-3", children: _jsx(JsonValue, { value: item }) })] }, index)) }) : _jsx("span", { className: "text-fg-subtle", children: "Empty collection" });
    const entries = Object.entries(value);
    return entries.length ? _jsx("dl", { className: "overflow-hidden rounded-lg border border-border bg-surface", children: entries.map(([key, entry], index) => _jsxs("div", { className: cn('grid gap-1.5 px-3 py-2.5 sm:grid-cols-[minmax(9rem,0.32fr)_minmax(0,1fr)] sm:gap-4', index > 0 && 'border-t border-border'), children: [_jsx("dt", { className: "text-xs font-medium tracking-wide text-fg-muted", children: humanize(key) }), _jsx("dd", { className: "min-w-0 text-sm text-fg", children: _jsx(JsonValue, { value: entry }) })] }, key)) }) : _jsx("span", { className: "text-fg-subtle", children: "Empty collection" });
}
function CompactValue({ value }) { if (value === null || value === undefined)
    return _jsx("span", { className: "text-fg-subtle", children: "Not set" }); if (Array.isArray(value))
    return _jsxs("span", { className: "text-fg-muted", children: [value.length, " items"] }); if (isObject(value))
    return _jsxs("span", { className: "text-fg-muted", children: [Object.keys(value).length, " properties"] }); if (typeof value === 'boolean')
    return _jsx(Badge, { variant: value ? 'success' : 'outline', children: value ? 'Yes' : 'No' }); if (typeof value === 'number')
    return _jsx("span", { className: "tabular-nums", children: value.toLocaleString() }); const text = String(value); return _jsx("span", { className: cn('break-words', isUuid(text) && 'font-mono text-xs text-fg-muted'), children: text }); }
function MetadataCard({ icon, label, children }) { return _jsxs("div", { className: "min-w-0 rounded-xl border border-border bg-surface p-3.5 shadow-sm", children: [_jsxs("div", { className: "mb-2 flex items-center gap-2 text-xs font-medium text-fg-muted", children: [icon, label] }), _jsx("div", { className: "truncate text-sm font-medium text-fg", children: children })] }); }
function collectDiffs(before, after, path = '') { if (JSON.stringify(before) === JSON.stringify(after))
    return []; if (Array.isArray(before) || Array.isArray(after))
    return [{ path, before, after }]; if (isObject(before) || isObject(after)) {
    const left = isObject(before) ? before : {};
    const right = isObject(after) ? after : {};
    return [...new Set([...Object.keys(left), ...Object.keys(right)])].sort().flatMap((key) => collectDiffs(left[key], right[key], path ? `${path}.${key}` : key));
} return [{ path, before, after }]; }
function isObject(value) { return typeof value === 'object' && value !== null && !Array.isArray(value); }
function isUuid(value) { return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value); }
function humanize(value) { return value.replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/[_.-]+/g, ' ').split(' ').map((word) => word ? word.charAt(0).toUpperCase() + word.slice(1) : word).join(' '); }
function formatPath(path) { return path.split('.').map(humanize).join(' › '); }
//# sourceMappingURL=audit-admin.js.map