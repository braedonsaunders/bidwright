import * as React from 'react';
import type { AuditEventRecord, IamAdminService } from './types.js';
export declare function AuditAdmin({ service, title, description, onError, actions: actionOptions, recordTypes: recordTypeOptions, }: {
    service: IamAdminService;
    title?: string;
    description?: string;
    onError?: (error: unknown) => void;
    actions?: string[];
    recordTypes?: string[];
}): React.JSX.Element;
export declare function AuditEventDrawer({ event, onClose }: {
    event: AuditEventRecord;
    onClose: () => void;
}): React.JSX.Element;
//# sourceMappingURL=audit-admin.d.ts.map