'use client';
import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Menu } from 'lucide-react';
import { findActiveNavHref, NavIcon, selectMobileTabs, } from './sidebar-nav.js';
import { cn } from './utils.js';
const defaultLink = ({ href, children, className, ariaCurrent }) => (_jsx("a", { href: href, className: className, "aria-current": ariaCurrent, children: children }));
const tabClass = (active) => cn('flex min-w-0 flex-1 flex-col items-center gap-1 px-1 pt-2 pb-1.5 text-[10px] font-medium transition-colors', active ? 'text-primary' : 'text-fg-muted hover:text-fg');
/** Native-style mobile bottom bar driven by the shared navigation registry. */
export function MobileTabBar({ groups, pathname, onOpenMenu, linkRender = defaultLink, tabCount = 4, menuLabel = 'Menu', ariaLabel = 'Primary navigation', }) {
    const tabs = selectMobileTabs(groups, tabCount);
    const activeHref = findActiveNavHref(pathname, [{ label: '', items: tabs }]);
    if (tabs.length === 0)
        return null;
    return (_jsxs("nav", { "aria-label": ariaLabel, className: "flex shrink-0 border-t border-border bg-surface pb-[env(safe-area-inset-bottom)] lg:hidden", children: [tabs.map((tab) => {
                const active = activeHref === tab.href;
                return (_jsx(React.Fragment, { children: linkRender({
                        href: tab.href,
                        ariaCurrent: active ? 'page' : undefined,
                        className: tabClass(active),
                        children: (_jsxs(_Fragment, { children: [_jsx(NavIcon, { iconKey: tab.iconKey, icon: tab.icon, size: 20 }), _jsx("span", { className: "w-full truncate text-center", children: tab.label })] })),
                    }) }, tab.href));
            }), _jsxs("button", { type: "button", onClick: onOpenMenu, className: tabClass(false), children: [_jsx(Menu, { size: 20 }), _jsx("span", { className: "w-full truncate text-center", children: menuLabel })] })] }));
}
//# sourceMappingURL=mobile-tab-bar.js.map