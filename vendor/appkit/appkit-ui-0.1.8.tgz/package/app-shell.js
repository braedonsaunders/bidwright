'use client';
import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Menu } from 'lucide-react';
import { AppSidebar } from './app-sidebar.js';
import { Drawer } from './drawer.js';
import { MobileTabBar } from './mobile-tab-bar.js';
import { SidebarNav } from './sidebar-nav.js';
import { TopNav } from './top-nav.js';
import { cn } from './utils.js';
/**
 * Generalized application shell. One serialized navigation registry drives the
 * dropdown topbar, shared collapsible rail,
 * the mobile drawer, and the native-style mobile tab bar.
 */
export function AppShell({ groups, pathname, brand, sidebarFooter, sidebarCollapsedFooter, mobileFooter, headerMiddle, header, banner, defaultCollapsed = false, navigationMode = 'topbar', linkRender, moreLabel = 'More', openNavigationLabel = 'Open navigation', menuLabel = 'Menu', primaryNavigationLabel = 'Primary navigation', mobileTabCount = 4, showMobileTabs = true, children, }) {
    const [mobileOpen, setMobileOpen] = React.useState(false);
    const topbar = navigationMode === 'topbar';
    return (_jsxs("div", { className: "flex h-screen overflow-hidden", children: [topbar ? null : (_jsx(AppSidebar, { groups: groups, pathname: pathname, brand: brand, footer: sidebarFooter, collapsedFooter: sidebarCollapsedFooter, defaultCollapsed: defaultCollapsed, linkRender: linkRender })), _jsxs("div", { className: "flex min-w-0 flex-1 flex-col overflow-hidden [padding-top:env(safe-area-inset-top)]", children: [banner, _jsxs("header", { className: "flex h-14 shrink-0 items-center gap-2 border-b border-border bg-surface px-3 sm:gap-3 sm:px-4", children: [_jsx("button", { type: "button", onClick: () => setMobileOpen(true), "aria-label": openNavigationLabel, className: "grid size-9 shrink-0 place-items-center rounded-md border border-border text-fg-muted transition-colors hover:bg-surface-hover hover:text-fg lg:hidden", children: _jsx(Menu, { size: 18 }) }), topbar ? (_jsxs(_Fragment, { children: [brand ? _jsx("div", { className: "hidden shrink-0 lg:block", children: brand }) : null, _jsx(TopNav, { groups: groups, pathname: pathname, linkRender: linkRender, moreLabel: moreLabel, ariaLabel: primaryNavigationLabel }), _jsx("div", { className: "flex-1 lg:hidden" }), headerMiddle] })) : (_jsx("div", { className: cn('min-w-0 flex-1', !headerMiddle && 'hidden lg:block'), children: headerMiddle })), header ? _jsx("div", { className: "flex shrink-0 items-center gap-1", children: header }) : null] }), _jsx("main", { className: "flex min-h-0 flex-1 flex-col overflow-hidden bg-bg-subtle", children: children }), showMobileTabs ? (_jsx(MobileTabBar, { groups: groups, pathname: pathname, onOpenMenu: () => setMobileOpen(true), linkRender: linkRender, tabCount: mobileTabCount, menuLabel: menuLabel, ariaLabel: primaryNavigationLabel })) : null] }), _jsx(Drawer, { open: mobileOpen, onClose: () => setMobileOpen(false), side: "left", size: "sm", title: brand ?? menuLabel, disableFullscreen: true, bodyClassName: "min-h-0 flex-1 overflow-hidden p-0", footer: mobileFooter ?? sidebarFooter, children: _jsx("div", { onClick: () => setMobileOpen(false), className: "flex h-full flex-col", children: _jsx(SidebarNav, { groups: groups, pathname: pathname, linkRender: linkRender }) }) })] }));
}
//# sourceMappingURL=app-shell.js.map