'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// NetSuite-style top menu bar generalized around a serialized navigation tree.
// The same registry drives the sidebar, mobile drawer, and mobile tabs.
import * as React from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';
import { visibleTopNavGroupCount } from './nav-overflow.js';
import { Popover } from './popover.js';
import { findActiveNavHref, groupContainsActiveHref, NavIcon, toBlocks, } from './sidebar-nav.js';
import { cn } from './utils.js';
const MORE_MENU_INDEX = -1;
const defaultLink = ({ href, children, className, title, ariaCurrent, role, dataWalkthrough, }) => (_jsx("a", { href: href, className: className, title: title, "aria-current": ariaCurrent, role: role, "data-walkthrough": dataWalkthrough, children: children }));
export function TopNav({ groups, pathname, linkRender = defaultLink, moreLabel = 'More', ariaLabel = 'Primary navigation', className, }) {
    const activeHref = findActiveNavHref(pathname, groups);
    const [openIndex, setOpenIndex] = React.useState(null);
    const [visibleCount, setVisibleCount] = React.useState(groups.length);
    const navRef = React.useRef(null);
    const measurementRef = React.useRef(null);
    const closeTimer = React.useRef(null);
    React.useLayoutEffect(() => {
        const nav = navRef.current;
        const measurement = measurementRef.current;
        if (!nav || !measurement)
            return;
        let active = true;
        function measure() {
            if (!active)
                return;
            const groupWidths = Array.from(measurement.querySelectorAll('[data-top-nav-measure="group"]'), (element) => element.getBoundingClientRect().width);
            const moreWidth = measurement
                .querySelector('[data-top-nav-measure="more"]')
                ?.getBoundingClientRect().width ?? 0;
            const gap = Number.parseFloat(window.getComputedStyle(measurement).columnGap) || 0;
            const next = visibleTopNavGroupCount({
                availableWidth: nav.clientWidth,
                groupWidths,
                moreWidth,
                gap,
            });
            setVisibleCount((current) => (current === next ? current : next));
        }
        measure();
        const frame = window.requestAnimationFrame(measure);
        const timer = window.setTimeout(measure, 0);
        const observer = new ResizeObserver(measure);
        observer.observe(nav);
        observer.observe(measurement);
        window.addEventListener('resize', measure);
        void document.fonts?.ready.then(measure);
        return () => {
            active = false;
            window.cancelAnimationFrame(frame);
            window.clearTimeout(timer);
            window.removeEventListener('resize', measure);
            observer.disconnect();
        };
    }, [groups, moreLabel]);
    React.useEffect(() => {
        if (openIndex !== null &&
            ((openIndex === MORE_MENU_INDEX && visibleCount === groups.length) || openIndex >= visibleCount)) {
            setOpenIndex(null);
        }
    }, [groups.length, openIndex, visibleCount]);
    React.useEffect(() => () => {
        if (closeTimer.current)
            window.clearTimeout(closeTimer.current);
    }, []);
    function enterMenu(index) {
        if (closeTimer.current) {
            window.clearTimeout(closeTimer.current);
            closeTimer.current = null;
        }
        setOpenIndex(index);
    }
    function scheduleClose() {
        if (closeTimer.current)
            window.clearTimeout(closeTimer.current);
        closeTimer.current = window.setTimeout(() => setOpenIndex(null), 150);
    }
    const visibleGroups = groups.slice(0, visibleCount);
    const overflowGroups = groups.slice(visibleCount);
    const moreOpen = openIndex === MORE_MENU_INDEX;
    const moreActive = overflowGroups.some((group) => groupContainsActiveHref(group, activeHref));
    return (_jsxs("nav", { ref: navRef, "aria-label": ariaLabel, className: cn('relative hidden min-w-0 flex-1 items-center gap-0.5 overflow-hidden lg:flex', className), children: [_jsxs("div", { ref: measurementRef, "aria-hidden": true, className: "pointer-events-none invisible absolute flex w-max items-center gap-0.5", children: [groups.map((group, index) => (_jsxs("span", { "data-top-nav-measure": "group", className: "flex h-14 shrink-0 items-center gap-1 whitespace-nowrap px-2 text-sm font-medium", children: [group.items.length === 1 ? group.items[0].label : group.label, group.items.length === 1 ? null : _jsx(ChevronDown, { size: 12, className: "opacity-50" })] }, `${group.label}-${index}`))), _jsxs("span", { "data-top-nav-measure": "more", className: "flex h-14 shrink-0 items-center gap-1 whitespace-nowrap px-2 text-sm font-medium", children: [moreLabel, _jsx(ChevronDown, { size: 12, className: "opacity-50" })] })] }), visibleGroups.map((group, index) => {
                const open = openIndex === index;
                const groupActive = groupContainsActiveHref(group, activeHref);
                const only = group.items.length === 1 ? group.items[0] : undefined;
                if (only) {
                    return (_jsx(React.Fragment, { children: linkRender({
                            href: only.href,
                            className: cn('flex h-14 shrink-0 items-center whitespace-nowrap px-2 text-sm font-medium transition-colors', activeHref === only.href ? 'text-primary' : 'text-fg-muted hover:text-fg'),
                            children: only.label,
                        }) }, group.id ?? `${group.label}-${index}`));
                }
                return (_jsx(Popover, { open: open, onOpenChange: (next) => (next ? enterMenu(index) : setOpenIndex(null)), align: "start", className: "min-w-[15rem] py-1.5", trigger: _jsxs("button", { type: "button", "aria-haspopup": "menu", "aria-expanded": open, "aria-current": groupActive ? 'true' : undefined, onMouseEnter: () => enterMenu(index), onMouseLeave: scheduleClose, onClick: () => enterMenu(index), className: cn('flex h-14 shrink-0 items-center gap-1 whitespace-nowrap px-2 text-sm font-medium transition-colors', groupActive ? 'text-primary' : 'text-fg-muted hover:text-fg'), children: [group.label, _jsx(ChevronDown, { size: 12, className: "opacity-50" })] }), children: _jsx(GroupMenu, { items: group.items, activeHref: activeHref, linkRender: linkRender, onEnter: () => enterMenu(index), onLeave: scheduleClose, onSelect: () => setOpenIndex(null) }) }, group.id ?? `${group.label}-${index}`));
            }), overflowGroups.length > 0 ? (_jsx(Popover, { open: moreOpen, onOpenChange: (open) => (open ? enterMenu(MORE_MENU_INDEX) : setOpenIndex(null)), align: "start", className: "min-w-[15rem] py-1.5", trigger: _jsxs("button", { type: "button", "aria-haspopup": "menu", "aria-expanded": moreOpen, "aria-current": moreActive ? 'true' : undefined, onMouseEnter: () => enterMenu(MORE_MENU_INDEX), onMouseLeave: scheduleClose, onClick: () => enterMenu(MORE_MENU_INDEX), className: cn('flex h-14 shrink-0 items-center gap-1 whitespace-nowrap px-2 text-sm font-medium transition-colors', moreActive ? 'text-primary' : 'text-fg-muted hover:text-fg'), children: [moreLabel, _jsx(ChevronDown, { size: 12, className: "opacity-50" })] }), children: _jsx("div", { role: "menu", onMouseEnter: () => enterMenu(MORE_MENU_INDEX), onMouseLeave: scheduleClose, onClick: () => setOpenIndex(null), children: overflowGroups.map((group, index) => group.items.length === 1 ? (_jsx(MenuItemLink, { item: group.items[0], active: activeHref === group.items[0].href, linkRender: linkRender }, group.id ?? `${group.label}-${visibleCount + index}`)) : (_jsx(OverflowGroupRow, { group: group, activeHref: activeHref, linkRender: linkRender }, group.id ?? `${group.label}-${visibleCount + index}`))) }) })) : null] }));
}
function GroupMenu({ items, activeHref, linkRender, onEnter, onLeave, onSelect, }) {
    const blocks = toBlocks(items);
    const sectioned = blocks.some((block) => block.kind === 'subgroup');
    return (_jsx("div", { role: "menu", onMouseEnter: onEnter, onMouseLeave: onLeave, onClick: onSelect, className: cn('app-scroll max-h-[min(36rem,calc(100vh-5rem))] overflow-y-auto', sectioned && 'grid w-[32rem] grid-cols-2 gap-x-2 gap-y-1 p-1'), children: blocks.map((block, blockIndex) => block.kind === 'item' ? (_jsx(MenuItemLink, { item: block.item, active: activeHref === block.item.href, linkRender: linkRender }, block.item.href)) : (_jsx(MenuSection, { label: block.label, href: block.href, iconKey: block.iconKey, items: block.items, activeHref: activeHref, linkRender: linkRender }, `sub-${block.label}-${blockIndex}`))) }));
}
function OverflowGroupRow({ group, activeHref, linkRender, }) {
    const [open, setOpen] = React.useState(false);
    const [flip, setFlip] = React.useState(false);
    const rowRef = React.useRef(null);
    const closeTimer = React.useRef(null);
    const active = groupContainsActiveHref(group, activeHref);
    React.useEffect(() => () => {
        if (closeTimer.current)
            window.clearTimeout(closeTimer.current);
    }, []);
    function openMenu() {
        if (closeTimer.current) {
            window.clearTimeout(closeTimer.current);
            closeTimer.current = null;
        }
        const rect = rowRef.current?.getBoundingClientRect();
        const panelWidth = group.items.some((item) => item.subgroup) ? 528 : 248;
        setFlip(rect ? rect.right + panelWidth > window.innerWidth : false);
        setOpen(true);
    }
    function scheduleClose() {
        if (closeTimer.current)
            window.clearTimeout(closeTimer.current);
        closeTimer.current = window.setTimeout(() => setOpen(false), 150);
    }
    return (_jsxs("div", { ref: rowRef, className: "relative", onMouseEnter: openMenu, onMouseLeave: scheduleClose, children: [_jsxs("button", { type: "button", role: "menuitem", "aria-haspopup": "menu", "aria-expanded": open, onClick: (event) => {
                    event.stopPropagation();
                    setOpen((current) => !current);
                }, className: cn('flex w-full items-center gap-2.5 px-3 py-1.5 text-sm transition-colors', active ? 'text-primary' : 'text-fg-muted hover:bg-surface-hover hover:text-fg'), children: [_jsx(NavIcon, { iconKey: group.iconKey, icon: group.icon, size: 14, className: "shrink-0 text-fg-subtle" }), _jsx("span", { className: "flex-1 truncate text-left", children: group.label }), _jsx(ChevronRight, { size: 12, className: cn('shrink-0 opacity-50', flip && open && 'rotate-180') })] }), open ? (_jsx("div", { role: "menu", className: cn('absolute top-0 z-10 min-w-[15rem] rounded-md border border-border bg-elevated py-1.5 shadow-lg', flip ? 'right-full -mr-1' : 'left-full -ml-1'), children: _jsx(GroupMenu, { items: group.items, activeHref: activeHref, linkRender: linkRender }) })) : null] }));
}
function MenuItemLink({ item, active, linkRender, }) {
    return (_jsx(React.Fragment, { children: linkRender({
            href: item.href,
            role: 'menuitem',
            ariaCurrent: active ? 'page' : undefined,
            dataWalkthrough: `nav:${item.href}`,
            className: cn('group flex items-center gap-2.5 px-3 py-1.5 text-sm transition-colors', active ? 'bg-primary-subtle text-fg' : 'text-fg-muted hover:bg-surface-hover hover:text-fg'),
            children: (_jsxs(_Fragment, { children: [_jsx(NavIcon, { iconKey: item.iconKey, icon: item.icon, size: 15, className: cn('shrink-0 transition-colors', active ? 'text-primary' : 'text-fg-subtle group-hover:text-fg') }), _jsx("span", { className: "truncate", children: item.label })] })),
        }) }));
}
function MenuSection({ label, href, iconKey, items, activeHref, linkRender, }) {
    const selfActive = href != null && activeHref === href;
    return (_jsxs("div", { role: "group", "aria-label": label, className: "min-w-0 rounded-md py-1", children: [href ? (_jsx(React.Fragment, { children: linkRender({
                    href,
                    role: 'menuitem',
                    ariaCurrent: selfActive ? 'page' : undefined,
                    dataWalkthrough: `nav:${href}`,
                    className: cn('flex items-center gap-1.5 px-3 pb-1.5 text-[11px] font-semibold tracking-wide uppercase transition-colors', selfActive ? 'text-primary' : 'text-fg-subtle hover:text-fg'),
                    children: (_jsxs(_Fragment, { children: [iconKey ? _jsx(NavIcon, { iconKey: iconKey, size: 13 }) : null, label] })),
                }) })) : (_jsx("div", { className: "px-3 pb-1.5 text-[11px] font-semibold tracking-wide text-fg-subtle uppercase", children: label })), items.map((item) => (_jsx(MenuItemLink, { item: item, active: activeHref === item.href, linkRender: linkRender }, item.href)))] }));
}
//# sourceMappingURL=top-nav.js.map