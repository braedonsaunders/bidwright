# @appkit/ui

Tokenized, animated UI primitives — the feel of the ecosystem.

## Install

```bash
pnpm add @appkit/ui
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
