import { type ChildProcess, type StdioOptions } from 'node:child_process';
export declare const DEFAULT_BUBBLEWRAP_PATH = "/usr/bin/bwrap";
export declare const DEFAULT_PROCESS_PATH = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin";
export declare const DEFAULT_READ_ONLY_PATHS: readonly ["/usr", "/etc", "/opt", "/app"];
export declare const DEFAULT_MASKED_PATHS: readonly ["/data", "/home", "/root", "/var"];
export interface ProcessSandboxLauncherIdentity {
    /** Host/container UID used to invoke the setuid bubblewrap executable. */
    uid: number;
    /** Host/container GID used to invoke the setuid bubblewrap executable. */
    gid: number;
}
export interface ProcessSandboxOptions {
    command: string;
    args?: readonly string[];
    /** Absolute working directory inside the sandbox. It must be covered by an exposed bind. */
    cwd: string;
    /** Absolute host paths mounted read/write at the same path inside the sandbox. */
    writablePaths: readonly string[];
    /** Read-only system/application roots exposed to the child. */
    readOnlyPaths?: readonly string[];
    /** Host roots replaced with empty tmpfs mounts before writable binds are layered on top. */
    maskedPaths?: readonly string[];
    /** The complete child environment. Host process variables are never inherited implicitly. */
    environment?: Readonly<Record<string, string | undefined>>;
    bubblewrapPath?: string;
    /**
     * Optional unprivileged identity used only to invoke bubblewrap. This lets a
     * root application process use Debian's setuid bubblewrap safely without
     * granting CAP_SYS_ADMIN to the application container.
     */
    launcherIdentity?: ProcessSandboxLauncherIdentity;
    stdio?: StdioOptions;
}
export interface BubblewrapPlan {
    command: string;
    args: string[];
    /** Complete sanitized wrapper/child environment; never serialized into argv. */
    environment: Record<string, string>;
    cwd: string;
    writablePaths: string[];
    readOnlyPaths: string[];
    maskedPaths: string[];
    launcherIdentity?: ProcessSandboxLauncherIdentity;
}
export interface ProcessSandboxVerification {
    supported: true;
    bubblewrapPath: string;
}
export declare class ProcessSandboxError extends Error {
    readonly name = "ProcessSandboxError";
}
/** Whether this host can run the Linux bubblewrap implementation. */
export declare function isProcessSandboxSupported(options?: {
    platform?: NodeJS.Platform;
    bubblewrapPath?: string;
    pathExists?: (path: string) => boolean;
}): boolean;
/**
 * Build the deterministic bubblewrap invocation without spawning it. This is
 * useful for audit logs, deployment readiness checks, tests, and admin UIs.
 */
export declare function buildBubblewrapPlan(options: ProcessSandboxOptions, dependencies?: {
    pathExists?: (path: string) => boolean;
}): BubblewrapPlan;
/**
 * Spawn a process under the shared Linux isolation policy. This function is
 * deliberately fail-closed: unsupported platforms, missing binaries, and
 * missing bind sources throw instead of silently running the command directly.
 */
export declare function spawnBubblewrappedProcess(options: ProcessSandboxOptions): ChildProcess;
/**
 * Execute a minimal child in the real sandbox. Use this during service startup
 * to catch deployment failures that an existence check cannot detect, such as
 * blocked namespace/mount syscalls or an unusable setuid bubblewrap install.
 */
export declare function verifyProcessSandbox(options?: {
    bubblewrapPath?: string;
    launcherIdentity?: ProcessSandboxLauncherIdentity;
    timeoutMs?: number;
}): Promise<ProcessSandboxVerification>;
//# sourceMappingURL=index.d.ts.map