import type { DateBin } from './types.js';
import type { RichSemanticType } from './semantic.js';
export type ResultDataType = 'string' | 'number' | 'date' | 'timestamp' | 'boolean';
export type AnalyticResultColumn = {
    key: string;
    label: string;
    role: 'dimension' | 'measure';
    semanticType: RichSemanticType;
    dataType: ResultDataType;
    bin?: DateBin;
};
export type FlatAnalyticResult = {
    shape: 'flat';
    columns: AnalyticResultColumn[];
    rows: Record<string, unknown>[];
    rowCount: number;
    truncated: boolean;
    durationMs?: number;
};
export type PivotAxisKey = {
    values: unknown[];
    labels: string[];
};
export type PivotCell = Record<string, unknown>;
export type PivotAnalyticResult = {
    shape: 'pivot';
    rowDimensions: AnalyticResultColumn[];
    columnDimensions: AnalyticResultColumn[];
    valueMeasures: AnalyticResultColumn[];
    rowKeys: PivotAxisKey[];
    columnKeys: PivotAxisKey[];
    cells: (PivotCell | null)[][];
    rowCount: number;
    truncated: boolean;
    durationMs?: number;
};
export type AnalyticResult = FlatAnalyticResult | PivotAnalyticResult;
export type ResultShape = 'scalar' | 'rows' | 'pivot';
export declare function resultShapeOf(result: AnalyticResult): ResultShape;
export declare function pivotResult(result: FlatAnalyticResult, options: {
    rows: string[];
    columns: string[];
    values: string[];
}): PivotAnalyticResult;
//# sourceMappingURL=result.d.ts.map