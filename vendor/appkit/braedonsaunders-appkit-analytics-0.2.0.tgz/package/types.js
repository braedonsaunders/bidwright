export const FILTER_OPERATORS = [
    'eq', 'neq', 'in', 'not_in', 'gt', 'gte', 'lt', 'lte', 'contains',
    'is_null', 'is_not_null', 'last_n_days', 'this_month', 'this_quarter', 'this_year', 'ytd',
];
//# sourceMappingURL=types.js.map