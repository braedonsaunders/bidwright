import type { FlatAnalyticResult } from './result.js';
import type { VisualizationKey, VisualizationSettings } from './types.js';
export type ChartSeries = {
    name: string;
    data: (number | null)[];
    type?: 'bar' | 'line';
    yAxisIndex?: 0 | 1;
    area?: boolean;
    pointColors?: (string | null)[];
};
export type ChartSpec = {
    kind: 'cartesian' | 'pie' | 'scatter' | 'funnel' | 'gauge';
    cartesianType?: 'bar' | 'line' | 'area';
    orientation?: 'vertical' | 'horizontal';
    stacked?: boolean;
    labels: string[];
    series: ChartSeries[];
    secondaryAxis?: boolean;
    showValues?: boolean;
    gauge?: {
        value: number;
        min: number;
        max: number;
    };
};
export declare function buildChartSpec(result: FlatAnalyticResult, visualization: VisualizationKey, settings?: VisualizationSettings): ChartSpec | null;
//# sourceMappingURL=chart-spec.d.ts.map