import type { AnalyticsCatalog, CompiledQuery, InsightQuery } from './types.js';
export type QueryErrorCode = 'unknown_source' | 'unknown_field' | 'invalid_measure' | 'invalid_dimension' | 'invalid_filter' | 'invalid_formula' | 'empty_query';
export declare class QueryCompileError extends Error {
    readonly code: QueryErrorCode;
    readonly subject?: string | undefined;
    readonly name = "QueryCompileError";
    constructor(code: QueryErrorCode, message: string, subject?: string | undefined);
}
export declare function compileQuery(query: InsightQuery, tenantId: string, catalog: AnalyticsCatalog): CompiledQuery;
export declare const QUERY_MAX_ROWS = 10000;
//# sourceMappingURL=compile.d.ts.map