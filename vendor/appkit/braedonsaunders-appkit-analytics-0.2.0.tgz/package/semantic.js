export function deriveSemanticType(column) {
    if (column.kind === 'uuid') {
        if (column.key === 'id')
            return 'pk';
        if (column.key.endsWith('_id'))
            return 'fk';
        return 'uuid';
    }
    if (column.kind === 'date' || column.kind === 'timestamp')
        return 'temporal';
    if (column.kind === 'number')
        return 'measure';
    if (column.kind === 'enum')
        return 'category';
    if (column.kind === 'text' && /(^|_)(name|title|first_name|last_name)($|_)/.test(column.key)) {
        return 'entity-name';
    }
    return 'dimension';
}
export function decorateSemanticColumn(column, overlay = {}) {
    const semanticType = overlay.semanticType ?? deriveSemanticType(column);
    const numeric = column.kind === 'number';
    const temporal = column.kind === 'date' || column.kind === 'timestamp';
    return {
        ...column,
        ...overlay,
        semanticType,
        canDimension: semanticType !== 'pk' && !overlay.arrayUnnest,
        canMeasure: numeric,
        canBinTemporal: temporal,
        canBinNumeric: numeric && semanticType !== 'percentage',
    };
}
export function buildSemanticEntities(entities, overlays = {}, relations = {}) {
    return entities.map((entity) => ({
        ...entity,
        columns: entity.columns.map((column) => decorateSemanticColumn(column, overlays[entity.key]?.[column.key])),
        relations: relations[entity.key],
    }));
}
export function semanticEntity(entities, key) {
    return entities.find((entity) => entity.key === key) ?? null;
}
export function semanticColumn(entity, key) {
    return entity.columns.find((column) => column.key === key) ?? null;
}
//# sourceMappingURL=semantic.js.map