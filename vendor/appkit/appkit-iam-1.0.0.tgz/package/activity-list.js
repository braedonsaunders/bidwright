'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Badge, EmptyState } from '@appkit/ui';
import { History } from 'lucide-react';
export function ActivityList({ events }) {
    if (events.length === 0) {
        return _jsx(EmptyState, { icon: _jsx(History, {}), title: "No activity yet", description: "IAM changes to this record will appear here." });
    }
    return (_jsx("ol", { className: "divide-y divide-border rounded-lg border border-border", children: events.map((event) => (_jsxs("li", { className: "grid gap-2 px-4 py-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-start", children: [_jsxs("div", { className: "min-w-0", children: [_jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [_jsx(Badge, { variant: event.action === 'delete' ? 'destructive' : event.action === 'invite' ? 'warning' : event.action === 'insert' || event.action === 'create' ? 'success' : 'secondary', children: humanize(event.action) }), _jsx("span", { className: "text-sm font-medium text-fg", children: event.summary ?? humanize(event.recordType) })] }), _jsxs("p", { className: "mt-1 text-xs text-fg-muted", children: [event.actorName ?? 'System', event.requestId ? ` · Request ${event.requestId}` : ''] })] }), _jsx("time", { className: "whitespace-nowrap text-xs text-fg-subtle", dateTime: event.at.toISOString(), children: event.at.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) })] }, event.id))) }));
}
function humanize(value) {
    return value.replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/[_.-]+/g, ' ').split(' ').map((word) => word ? word.charAt(0).toUpperCase() + word.slice(1) : word).join(' ');
}
//# sourceMappingURL=activity-list.js.map