import * as React from 'react';
import { type ConfirmDialogOptions } from '@appkit/ui';
import type { IamAdminService, MemberRecord, PermissionGroup, ScopeOptions } from './types.js';
export type MemberAdminAction = {
    key: string;
    label: string;
    variant?: 'default' | 'secondary' | 'outline' | 'ghost' | 'destructive';
    available?: (member: MemberRecord) => boolean;
    confirm?: string | ((member: MemberRecord) => ConfirmDialogOptions);
    run: (context: {
        member: MemberRecord;
        service: IamAdminService;
        refresh: () => Promise<void>;
    }) => Promise<void>;
};
export type MemberAdminExtension = {
    key: string;
    label: string;
    render: (context: {
        member: MemberRecord;
        service: IamAdminService;
        refresh: () => Promise<void>;
    }) => React.ReactNode;
};
export type UsersAdminProps = {
    service: IamAdminService;
    permissionGroups: PermissionGroup[];
    scopeOptions?: ScopeOptions;
    locales?: Array<{
        value: string;
        label: string;
    }>;
    canManage?: boolean;
    memberActions?: MemberAdminAction[];
    detailTabs?: MemberAdminExtension[];
    title?: string;
    description?: string;
    onError?: (error: unknown) => void;
};
/** Complete tenant-member administration with invitations, lifecycle, roles, scopes, and overrides. */
export declare function UsersAdmin({ service, permissionGroups, scopeOptions, locales, canManage, memberActions, detailTabs, title, description, onError, }: UsersAdminProps): React.JSX.Element;
//# sourceMappingURL=users-admin.d.ts.map