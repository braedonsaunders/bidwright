export { applyPermissionOverrides, permissionSetCovers } from '@appkit/tenant';
export function validatePermissionGroups(groups) {
    const errors = [];
    const groupKeys = new Set();
    const permissionKeys = new Set();
    for (const group of groups) {
        if (!group.key.trim())
            errors.push('Permission groups require a non-empty key.');
        if (groupKeys.has(group.key))
            errors.push(`Duplicate permission group: ${group.key}`);
        groupKeys.add(group.key);
        for (const permission of group.permissions) {
            if (!permission.key.trim())
                errors.push(`Permission in ${group.key} requires a non-empty key.`);
            if (permissionKeys.has(permission.key))
                errors.push(`Duplicate permission: ${permission.key}`);
            permissionKeys.add(permission.key);
        }
    }
    return errors;
}
export function permissionCatalogue(groups) {
    const errors = validatePermissionGroups(groups);
    if (errors.length > 0)
        throw new Error(errors.join('\n'));
    return groups.flatMap((group) => group.permissions.map((permission) => permission.key));
}
//# sourceMappingURL=permissions.js.map