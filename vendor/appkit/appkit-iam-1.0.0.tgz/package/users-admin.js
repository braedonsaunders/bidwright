'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Avatar, Badge, Button, Drawer, EmptyState, Input, Label, SearchSelect, Table, TableBody, TableCell, TableHead, TableHeader, TableRow, cn, confirmDialog, } from '@appkit/ui';
import { Plus, Search, Shield, Trash2, UserPlus, Users, X } from 'lucide-react';
import { ScopePicker } from './scope-picker.js';
import { ActivityList } from './activity-list.js';
import { collectAll, ServicePagination, SortButton } from './admin-list.js';
/** Complete tenant-member administration with invitations, lifecycle, roles, scopes, and overrides. */
export function UsersAdmin({ service, permissionGroups, scopeOptions = {}, locales = [{ value: 'en', label: 'English' }], canManage = true, memberActions = [], detailTabs = [], title = 'Users', description = 'Invite members, assign scoped roles, and manage individual permission exceptions.', onError, }) {
    assertUniqueExtensions(detailTabs, ['profile', 'roles', 'permissions', 'activity'], 'member');
    assertUniqueActionKeys(memberActions);
    const [members, setMembers] = React.useState([]);
    const [roles, setRoles] = React.useState([]);
    const [query, setQuery] = React.useState('');
    const deferredQuery = React.useDeferredValue(query);
    const [status, setStatus] = React.useState('');
    const [roleId, setRoleId] = React.useState('');
    const [sort, setSort] = React.useState('name');
    const [direction, setDirection] = React.useState('asc');
    const [page, setPage] = React.useState(1);
    const [total, setTotal] = React.useState(0);
    const [statusCounts, setStatusCounts] = React.useState({ active: 0, invited: 0, suspended: 0 });
    const [selectedId, setSelectedId] = React.useState(null);
    const [inviting, setInviting] = React.useState(false);
    const [loading, setLoading] = React.useState(true);
    const [error, setError] = React.useState(null);
    const load = React.useCallback(async () => {
        setLoading(true);
        try {
            const [memberResult, roleResult] = await Promise.all([
                service.listMembers({ q: deferredQuery || undefined, status: status || undefined, roleId: roleId || undefined, page, perPage: 25, sort, direction }),
                collectAll((nextPage, perPage) => service.listRoles({ page: nextPage, perPage, sort: 'name' })),
            ]);
            setMembers(memberResult.rows);
            setTotal(memberResult.total);
            setStatusCounts(memberResult.facets.statusCounts);
            setRoles(roleResult);
            setError(null);
        }
        catch (cause) {
            setError(errorMessage(cause));
            onError?.(cause);
        }
        finally {
            setLoading(false);
        }
    }, [deferredQuery, direction, onError, page, roleId, service, sort, status]);
    React.useEffect(() => { void load(); }, [load]);
    async function mutate(operation) {
        try {
            setError(null);
            await operation();
            await load();
            return true;
        }
        catch (cause) {
            setError(errorMessage(cause));
            onError?.(cause);
            return false;
        }
    }
    const selected = members.find((member) => member.id === selectedId) ?? null;
    React.useEffect(() => { setPage(1); }, [deferredQuery, roleId, status]);
    function changeSort(next) {
        if (sort === next)
            setDirection((value) => value === 'asc' ? 'desc' : 'asc');
        else {
            setSort(next);
            setDirection('asc');
        }
        setPage(1);
    }
    return (_jsxs("div", { className: "flex min-h-0 flex-1 flex-col gap-5", children: [_jsxs("div", { className: "flex flex-wrap items-start justify-between gap-4", children: [_jsxs("div", { children: [_jsx("h1", { className: "text-2xl font-semibold tracking-tight text-fg", children: title }), _jsx("p", { className: "mt-1 max-w-3xl text-sm text-fg-muted", children: description })] }), canManage ? _jsxs(Button, { onClick: () => setInviting(true), children: [_jsx(UserPlus, { size: 16 }), "Invite member"] }) : null] }), _jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [_jsxs("div", { className: "relative min-w-64 flex-1 sm:max-w-md", children: [_jsx(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-fg-subtle" }), _jsx(Input, { value: query, onChange: (event) => setQuery(event.target.value), placeholder: "Search name or email\u2026", className: "pl-9" })] }), _jsx("div", { className: "w-48", children: _jsx(SearchSelect, { value: roleId, onChange: setRoleId, options: [{ value: '', label: 'All roles' }, ...roles.map((role) => ({ value: role.id, label: role.name }))] }) }), _jsx(StatusFilters, { value: status, counts: statusCounts, onChange: setStatus })] }), error ? _jsx("div", { role: "alert", className: "rounded-lg border border-danger/30 bg-danger-subtle px-4 py-3 text-sm text-danger", children: error }) : null, _jsxs("div", { className: "space-y-2 sm:hidden", children: [members.map((member) => _jsx(MemberListCard, { member: member, onClick: () => setSelectedId(member.id) }, member.id)), !loading && members.length === 0 ? _jsx(EmptyState, { icon: _jsx(Users, {}), title: "No members found", description: "Try a different search or filter." }) : null] }), _jsx("div", { className: "hidden overflow-x-auto rounded-xl border border-border bg-surface sm:block", children: _jsxs(Table, { children: [_jsx(TableHeader, { children: _jsxs(TableRow, { noAnimate: true, children: [_jsx(TableHead, { children: _jsx(SortButton, { label: "Name", active: sort === 'name', direction: direction, onClick: () => changeSort('name') }) }), _jsx(TableHead, { children: _jsx(SortButton, { label: "Email", active: sort === 'email', direction: direction, onClick: () => changeSort('email') }) }), _jsx(TableHead, { children: _jsx(SortButton, { label: "Status", active: sort === 'status', direction: direction, onClick: () => changeSort('status') }) }), _jsx(TableHead, { children: "Roles" }), _jsx(TableHead, { children: _jsx(SortButton, { label: "Joined", active: sort === 'joined', direction: direction, onClick: () => changeSort('joined') }) })] }) }), _jsxs(TableBody, { children: [members.map((member) => (_jsxs(TableRow, { role: "button", tabIndex: 0, className: "cursor-pointer", onClick: () => setSelectedId(member.id), onKeyDown: (event) => { if (event.key === 'Enter' || event.key === ' ') {
                                        event.preventDefault();
                                        setSelectedId(member.id);
                                    } }, children: [_jsx(TableCell, { children: _jsxs("div", { className: "flex items-center gap-3", children: [_jsx(Avatar, { name: member.name, src: member.image ?? undefined, size: 32 }), _jsxs("div", { className: "flex min-w-0 items-center gap-1.5", children: [_jsx("span", { className: "truncate font-medium text-fg", children: member.name }), member.isCurrentUser ? _jsx(Badge, { variant: "outline", children: "You" }) : null, member.isSuperAdmin ? _jsx(Badge, { variant: "warning", children: "Super-admin" }) : null] })] }) }), _jsx(TableCell, { className: "text-fg-muted", children: member.email }), _jsx(TableCell, { children: _jsx(StatusBadge, { status: member.status }) }), _jsx(TableCell, { children: _jsxs("div", { className: "flex flex-wrap gap-1", children: [member.assignments.map((assignment) => _jsx(Badge, { variant: "secondary", children: assignment.roleName }, assignment.id)), member.assignments.length === 0 ? _jsx("span", { className: "text-fg-subtle", children: "\u2014" }) : null] }) }), _jsx(TableCell, { className: "whitespace-nowrap text-fg-muted", children: formatDate(member.joinedAt ?? member.invitedAt ?? member.createdAt) })] }, member.id))), !loading && members.length === 0 ? _jsx(TableRow, { noAnimate: true, children: _jsx(TableCell, { colSpan: 5, children: _jsx(EmptyState, { icon: _jsx(Users, {}), title: "No members found", description: "Try a different search or filter.", className: "border-0 bg-transparent py-10 shadow-none" }) }) }) : null] })] }) }), _jsx(ServicePagination, { page: page, perPage: 25, total: total, onPage: setPage }), selected ? (_jsx(MemberDrawer, { member: selected, roles: roles, permissionGroups: permissionGroups, scopeOptions: scopeOptions, locales: locales, canManage: canManage, service: service, memberActions: memberActions, extensions: detailTabs, refresh: load, onAction: (action) => mutate(() => runMemberAction(action, selected, service, load)), onClose: () => setSelectedId(null), onUpdate: (input) => mutate(() => service.updateMember(selected.id, input)), onRemove: async () => {
                    if (!(await confirmDialog({ message: `Remove ${selected.name} from this workspace?`, confirmLabel: 'Remove member', tone: 'danger' })))
                        return;
                    await mutate(async () => { await service.removeMember(selected.id); setSelectedId(null); });
                }, onResendInvite: () => mutate(() => service.resendInvite(selected.id)), onAssign: (nextRoleId, scope) => mutate(() => service.assignRole(selected.id, nextRoleId, scope)), onUpdateScope: (assignmentId, scope) => mutate(() => service.updateAssignmentScope(assignmentId, scope)), onRemoveAssignment: (assignmentId) => mutate(() => service.removeAssignment(assignmentId)), onSetOverride: (permission, effect) => mutate(() => service.setPermissionOverride(selected.id, { permission, effect })), onRemoveOverride: (permission) => mutate(() => service.removePermissionOverride(selected.id, permission)) })) : null, inviting ? _jsx(InviteMemberDrawer, { roles: roles, scopeOptions: scopeOptions, locales: locales, onClose: () => setInviting(false), onInvite: async (input) => { if (await mutate(() => service.inviteMember(input)))
                    setInviting(false); } }) : null] }));
}
function MemberDrawer({ member, service, roles, permissionGroups, scopeOptions, locales, canManage, memberActions, extensions, refresh, onAction, onClose, onUpdate, onRemove, onResendInvite, onAssign, onUpdateScope, onRemoveAssignment, onSetOverride, onRemoveOverride, }) {
    const [tab, setTab] = React.useState('profile');
    const [activity, setActivity] = React.useState([]);
    React.useEffect(() => {
        if (tab !== 'activity')
            return;
        void service.listAuditEvents({ recordType: 'membership', recordId: member.id, perPage: 25, sort: 'at', direction: 'desc' }).then((result) => setActivity(result.rows));
    }, [member.id, service, tab]);
    return (_jsxs(Drawer, { open: true, onClose: onClose, size: "xl", title: _jsxs("span", { className: "flex items-center gap-2", children: [member.name, _jsx(StatusBadge, { status: member.status }), member.isSuperAdmin ? _jsx(Badge, { variant: "warning", children: "Super-admin" }) : null] }), description: member.email, subtabs: _jsx(MemberTabs, { value: tab, onChange: setTab, extensions: extensions }), children: [tab === 'profile' ? _jsx(MemberProfile, { member: member, locales: locales, canManage: canManage, actions: memberActions, onAction: onAction, onUpdate: onUpdate, onRemove: onRemove, onResendInvite: onResendInvite }) : null, tab === 'roles' ? _jsx(MemberRoles, { member: member, roles: roles, options: scopeOptions, canManage: canManage && memberCan(member, 'manageRoles'), onAssign: onAssign, onUpdateScope: onUpdateScope, onRemoveAssignment: onRemoveAssignment }) : null, tab === 'permissions' ? _jsx(PermissionOverrides, { member: member, roles: roles, groups: permissionGroups, canManage: canManage && memberCan(member, 'manageOverrides'), onSet: onSetOverride, onRemove: onRemoveOverride }) : null, tab === 'activity' ? _jsx(ActivityList, { events: activity }) : null, extensions.map((extension) => tab === extension.key ? _jsx(React.Fragment, { children: extension.render({ member, service, refresh }) }, extension.key) : null)] }));
}
function MemberProfile({ member, locales, canManage, actions, onAction, onUpdate, onRemove, onResendInvite }) {
    const [name, setName] = React.useState(member.name);
    const [locale, setLocale] = React.useState(member.localeOverride ?? '');
    return _jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "iam-member-name", children: "Display name" }), _jsx(Input, { id: "iam-member-name", value: name, onChange: (event) => setName(event.target.value), disabled: !canManage || !memberCan(member, 'updateProfile') })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { children: "Language" }), _jsx(SearchSelect, { value: locale, onChange: setLocale, options: [{ value: '', label: 'Workspace default' }, ...locales], disabled: !canManage || !memberCan(member, 'updateProfile') })] })] }), _jsxs("dl", { className: "grid gap-4 rounded-xl border border-border bg-bg-subtle p-4 sm:grid-cols-2", children: [_jsx(Metric, { label: "Email", value: member.email }), _jsx(Metric, { label: "Member since", value: formatDate(member.joinedAt ?? member.createdAt) }), _jsx(Metric, { label: "Identity ID", value: member.userId, mono: true }), _jsx(Metric, { label: "Membership ID", value: member.id, mono: true })] }), canManage ? _jsxs("div", { className: "flex flex-wrap gap-2", children: [memberCan(member, 'updateProfile') ? _jsx(Button, { onClick: () => void onUpdate({ name, localeOverride: locale || null }), children: "Save profile" }) : null, member.status === 'active' ? _jsx(Button, { variant: "outline", disabled: !memberCan(member, 'changeStatus'), onClick: () => void suspendMember(member, onUpdate), children: "Suspend" }) : member.status === 'suspended' ? _jsx(Button, { variant: "outline", disabled: !memberCan(member, 'changeStatus'), onClick: () => void onUpdate({ status: 'active' }), children: "Reactivate" }) : memberCan(member, 'resendInvite') ? _jsx(Button, { variant: "outline", onClick: () => void onResendInvite(), children: "Resend invitation" }) : null, actions.filter((action) => action.available?.(member) ?? true).map((action) => _jsx(Button, { variant: action.variant ?? 'outline', onClick: () => void onAction(action), children: action.label }, action.key))] }) : null, canManage ? _jsxs("section", { className: "rounded-xl border border-danger/30 bg-danger-subtle p-4", children: [_jsx("h3", { className: "text-sm font-semibold text-danger", children: "Remove member" }), _jsx("p", { className: "mt-1 text-sm text-fg-muted", children: "Removes the membership, role assignments, and permission overrides from this workspace." }), _jsxs(Button, { variant: "destructive", size: "sm", className: "mt-3", disabled: !memberCan(member, 'remove'), onClick: () => void onRemove(), children: [_jsx(Trash2, { size: 14 }), "Remove member"] }), member.capabilities?.reason && !memberCan(member, 'remove') ? _jsx("p", { className: "mt-2 text-xs text-fg-muted", children: member.capabilities.reason }) : null] }) : null] });
}
function MemberRoles({ member, roles, options, canManage, onAssign, onUpdateScope, onRemoveAssignment }) {
    const [roleId, setRoleId] = React.useState('');
    const [scope, setScope] = React.useState({ type: 'tenant' });
    const [editing, setEditing] = React.useState(null);
    const availableRoles = roles.filter((role) => !member.assignments.some((assignment) => assignment.roleId === role.id));
    return _jsxs("div", { className: "space-y-5", children: [canManage && availableRoles.length > 0 ? _jsxs("section", { className: "space-y-4 rounded-lg border border-border bg-bg-subtle p-4", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { children: "Add role" }), _jsx(SearchSelect, { value: roleId, onChange: setRoleId, options: availableRoles.map((role) => ({ value: role.id, label: role.name, hint: role.description ?? undefined })), placeholder: "Choose a role\u2026" })] }), _jsx(ScopePicker, { value: scope, onChange: setScope, options: options }), _jsx("div", { className: "flex justify-end", children: _jsxs(Button, { disabled: !roleId, onClick: () => void onAssign(roleId, scope).then((saved) => { if (saved)
                                setRoleId(''); }), children: [_jsx(Plus, { size: 14 }), "Assign role"] }) })] }) : null, member.assignments.length > 0 ? _jsx("ul", { className: "divide-y divide-border rounded-lg border border-border", children: member.assignments.map((assignment) => _jsxs("li", { className: "p-3", children: [_jsxs("div", { className: "flex items-start justify-between gap-3", children: [_jsxs("div", { children: [_jsx("div", { className: "text-sm font-medium text-fg", children: assignment.roleName }), _jsx("div", { className: "text-xs text-fg-muted", children: scopeLabel(assignment.scope) })] }), canManage ? _jsxs("div", { className: "flex gap-1", children: [_jsx(Button, { variant: "ghost", size: "sm", onClick: () => setEditing(editing === assignment.id ? null : assignment.id), children: editing === assignment.id ? 'Cancel' : 'Change scope' }), _jsx(Button, { variant: "ghost", size: "sm", className: "text-danger", onClick: () => void confirmDialog({ message: `Remove ${assignment.roleName} from ${member.name}?`, confirmLabel: 'Remove assignment', tone: 'danger' }).then((confirmed) => confirmed ? onRemoveAssignment(assignment.id) : false), children: "Remove" })] }) : null] }), editing === assignment.id ? _jsx(AssignmentEditor, { initial: assignment.scope, options: options, onSave: async (next) => { if (await onUpdateScope(assignment.id, next))
                                setEditing(null); } }) : null] }, assignment.id)) }) : _jsx(EmptyState, { icon: _jsx(Shield, {}), title: "No roles assigned", description: "Assign a role before this member can access workspace features." })] });
}
function PermissionOverrides({ member, roles, groups, canManage, onSet, onRemove }) {
    const rolePermissions = new Set(member.assignments.flatMap((assignment) => roles.find((role) => role.id === assignment.roleId)?.permissions ?? []));
    return _jsxs("div", { className: "space-y-4", children: [_jsxs("div", { className: "rounded-lg border border-border bg-bg-subtle p-4", children: [_jsx("h3", { className: "text-sm font-semibold text-fg", children: "Individual exceptions" }), _jsx("p", { className: "mt-1 text-sm text-fg-muted", children: "Grant adds a capability beyond assigned roles. Deny removes it even when a role or wildcard grants it." })] }), groups.map((group) => _jsxs("section", { className: "overflow-hidden rounded-lg border border-border", children: [_jsx("div", { className: "border-b border-border bg-bg-subtle px-4 py-3", children: _jsx("h3", { className: "text-sm font-semibold text-fg", children: group.label }) }), _jsx("div", { className: "divide-y divide-border", children: group.permissions.map((permission) => { const override = member.overrides.find((value) => value.permission === permission.key); const inherited = rolePermissions.has(permission.key) || [...rolePermissions].some((value) => value === '*' || (value.endsWith('.*') && permission.key.startsWith(value.slice(0, -1)))); return _jsxs("div", { className: "grid gap-3 px-4 py-3 sm:grid-cols-[minmax(0,1fr)_12rem] sm:items-center", children: [_jsxs("div", { children: [_jsxs("div", { className: "flex items-center gap-2 text-sm font-medium text-fg", children: [permission.label, inherited ? _jsx(Badge, { variant: "outline", children: "From role" }) : null] }), _jsx("div", { className: "font-mono text-xs text-fg-subtle", children: permission.key })] }), _jsx(SearchSelect, { value: override?.effect ?? '', onChange: (value) => { if (!value)
                                        void onRemove(permission.key);
                                    else
                                        void onSet(permission.key, value); }, options: [{ value: '', label: 'From roles' }, { value: 'grant', label: 'Grant' }, { value: 'deny', label: 'Deny' }], disabled: !canManage })] }, permission.key); }) })] }, group.key))] });
}
function InviteMemberDrawer({ roles, scopeOptions, locales, onClose, onInvite }) {
    const [name, setName] = React.useState('');
    const [email, setEmail] = React.useState('');
    const [locale, setLocale] = React.useState('');
    const [roleId, setRoleId] = React.useState('');
    const [scope, setScope] = React.useState({ type: 'tenant' });
    const [assignments, setAssignments] = React.useState([]);
    const available = roles.filter((role) => !assignments.some((assignment) => assignment.roleId === role.id));
    const valid = name.trim() && email.includes('@') && assignments.length > 0;
    return _jsx(Drawer, { open: true, onClose: onClose, size: "lg", title: "Invite member", description: "Create a pending membership and send it through your configured identity provider.", footer: _jsxs("div", { className: "flex justify-end gap-2", children: [_jsx(Button, { variant: "outline", onClick: onClose, children: "Cancel" }), _jsx(Button, { disabled: !valid, onClick: () => void onInvite({ email, name, localeOverride: locale || null, assignments }), children: "Send invitation" })] }), children: _jsxs("div", { className: "space-y-5", children: [_jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "iam-invite-name", children: "Name" }), _jsx(Input, { id: "iam-invite-name", value: name, onChange: (event) => setName(event.target.value) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "iam-invite-email", children: "Email" }), _jsx(Input, { id: "iam-invite-email", type: "email", value: email, onChange: (event) => setEmail(event.target.value) })] })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { children: "Language" }), _jsx(SearchSelect, { value: locale, onChange: setLocale, options: [{ value: '', label: 'Workspace default' }, ...locales] })] }), _jsxs("section", { className: "space-y-4 rounded-lg border border-border bg-bg-subtle p-4", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { children: "Role" }), _jsx(SearchSelect, { value: roleId, onChange: setRoleId, options: available.map((role) => ({ value: role.id, label: role.name })), placeholder: "Choose a role\u2026" })] }), _jsx(ScopePicker, { value: scope, onChange: setScope, options: scopeOptions }), _jsx("div", { className: "flex justify-end", children: _jsxs(Button, { size: "sm", variant: "outline", disabled: !roleId, onClick: () => { setAssignments((current) => [...current, { roleId, scope }]); setRoleId(''); setScope({ type: 'tenant' }); }, children: [_jsx(Plus, { size: 14 }), "Add role"] }) })] }), assignments.length > 0 ? _jsx("ul", { className: "divide-y divide-border rounded-lg border border-border", children: assignments.map((assignment) => { const role = roles.find((candidate) => candidate.id === assignment.roleId); return _jsxs("li", { className: "flex items-center justify-between gap-3 px-3 py-2", children: [_jsxs("div", { children: [_jsx("div", { className: "text-sm font-medium text-fg", children: role?.name ?? assignment.roleId }), _jsx("div", { className: "text-xs text-fg-muted", children: scopeLabel(assignment.scope) })] }), _jsx(Button, { size: "icon", variant: "ghost", "aria-label": `Remove ${role?.name ?? 'role'}`, onClick: () => setAssignments((current) => current.filter((value) => value.roleId !== assignment.roleId)), children: _jsx(X, { size: 16 }) })] }, assignment.roleId); }) }) : _jsx("p", { className: "text-sm text-fg-muted", children: "At least one role is required." })] }) });
}
function AssignmentEditor({ initial, options, onSave }) { const [scope, setScope] = React.useState(initial); return _jsxs("div", { className: "mt-3 space-y-3 rounded-lg border border-border bg-bg-subtle p-3", children: [_jsx(ScopePicker, { value: scope, onChange: setScope, options: options }), _jsx("div", { className: "flex justify-end", children: _jsx(Button, { size: "sm", onClick: () => void onSave(scope), children: "Save scope" }) })] }); }
function MemberTabs({ value, onChange, extensions }) { const items = [{ value: 'profile', label: 'Profile' }, { value: 'roles', label: 'Roles & scope' }, { value: 'permissions', label: 'Permission overrides' }, { value: 'activity', label: 'Activity' }, ...extensions.map((extension) => ({ value: extension.key, label: extension.label }))]; return _jsx("nav", { className: "-mb-px flex gap-1 overflow-x-auto", "aria-label": "Member sections", children: items.map((item) => _jsx("button", { type: "button", onClick: () => onChange(item.value), className: cn('shrink-0 border-b-2 px-3 py-3 text-sm font-medium transition-colors', value === item.value ? 'border-primary text-primary' : 'border-transparent text-fg-muted hover:border-border-strong hover:text-fg'), children: item.label }, item.value)) }); }
function StatusBadge({ status }) { return _jsx(Badge, { variant: status === 'active' ? 'success' : status === 'invited' ? 'warning' : 'secondary', children: status.charAt(0).toUpperCase() + status.slice(1) }); }
function StatusFilters({ value, counts, onChange }) { const filters = [{ value: '', label: 'All', count: counts.active + counts.invited + counts.suspended }, { value: 'active', label: 'Active', count: counts.active }, { value: 'invited', label: 'Invited', count: counts.invited }, { value: 'suspended', label: 'Suspended', count: counts.suspended }]; return _jsx("div", { className: "flex max-w-full overflow-x-auto rounded-lg border border-border bg-surface p-1", "aria-label": "Filter members by status", children: filters.map((filter) => _jsxs("button", { type: "button", "aria-pressed": value === filter.value, onClick: () => onChange(filter.value), className: cn('flex shrink-0 items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors', value === filter.value ? 'bg-primary-subtle text-primary' : 'text-fg-muted hover:bg-surface-hover hover:text-fg'), children: [_jsx("span", { children: filter.label }), _jsx("span", { className: "tabular-nums text-fg-subtle", children: filter.count })] }, filter.value || 'all')) }); }
function MemberListCard({ member, onClick }) { return _jsxs("button", { type: "button", onClick: onClick, className: "w-full rounded-xl border border-border bg-surface p-4 text-left shadow-sm transition-colors hover:bg-surface-hover", children: [_jsxs("div", { className: "flex items-start justify-between gap-3", children: [_jsxs("div", { className: "flex min-w-0 items-center gap-3", children: [_jsx(Avatar, { name: member.name, src: member.image ?? undefined, size: 36 }), _jsxs("div", { className: "min-w-0", children: [_jsxs("div", { className: "flex flex-wrap items-center gap-1.5", children: [_jsx("span", { className: "truncate font-medium text-fg", children: member.name }), member.isCurrentUser ? _jsx(Badge, { variant: "outline", children: "You" }) : null, member.isSuperAdmin ? _jsx(Badge, { variant: "warning", children: "Super-admin" }) : null] }), _jsx("div", { className: "truncate text-xs text-fg-muted", children: member.email })] })] }), _jsx(StatusBadge, { status: member.status })] }), _jsxs("div", { className: "mt-3 flex flex-wrap items-center gap-1", children: [member.assignments.length ? member.assignments.map((assignment) => _jsx(Badge, { variant: "secondary", children: assignment.roleName }, assignment.id)) : _jsx("span", { className: "text-xs text-fg-subtle", children: "No roles" }), _jsx("span", { className: "ml-auto text-xs text-fg-muted", children: formatDate(member.joinedAt ?? member.invitedAt ?? member.createdAt) })] })] }); }
function Metric({ label, value, mono = false }) { return _jsxs("div", { children: [_jsx("dt", { className: "text-xs font-medium uppercase tracking-wide text-fg-subtle", children: label }), _jsx("dd", { className: cn('mt-1 truncate text-sm font-semibold text-fg', mono && 'font-mono text-xs'), children: value })] }); }
function formatDate(value) { return value.toLocaleDateString(undefined, { dateStyle: 'medium' }); }
function scopeLabel(scope) { if (scope.type === 'tenant')
    return 'All records'; if (scope.type === 'self')
    return 'Own records'; if (scope.type === 'sites')
    return `${scope.siteIds.length} selected sites`; if (scope.type === 'people')
    return `${scope.personIds.length} selected people`; if (scope.type === 'crews')
    return `${scope.crewIds.length} selected crews`; return `${scope.departmentIds.length} departments, ${scope.groupIds.length} groups`; }
function errorMessage(error) { return error instanceof Error ? error.message : 'The IAM operation failed.'; }
function memberCan(member, capability) { if (member.capabilities)
    return Boolean(member.capabilities[capability]); if (capability === 'updateProfile' || capability === 'resendInvite')
    return !member.isSuperAdmin; return !member.isCurrentUser && !member.isSuperAdmin; }
async function suspendMember(member, update) { if (await confirmDialog({ message: `Suspend ${member.name}? They will lose access until reactivated.`, confirmLabel: 'Suspend member', tone: 'danger' }))
    await update({ status: 'suspended' }); }
async function runMemberAction(action, member, service, refresh) { const confirmation = typeof action.confirm === 'function' ? action.confirm(member) : action.confirm; if (confirmation && !(await confirmDialog(confirmation)))
    return; await action.run({ member, service, refresh }); }
function assertUniqueExtensions(extensions, reserved, surface) { const keys = new Set(reserved); for (const extension of extensions) {
    if (!extension.key.trim() || keys.has(extension.key))
        throw new Error(`Duplicate or reserved ${surface} detail tab key: ${extension.key || '(empty)'}`);
    keys.add(extension.key);
} }
function assertUniqueActionKeys(actions) { const keys = new Set(); for (const action of actions) {
    if (!action.key.trim() || keys.has(action.key))
        throw new Error(`Duplicate member action key: ${action.key || '(empty)'}`);
    keys.add(action.key);
} }
//# sourceMappingURL=users-admin.js.map