'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Checkbox, Label, SearchSelect, cn } from '@appkit/ui';
const SCOPE_LABELS = [
    { value: 'tenant', label: 'All records', description: 'Everything in this workspace.' },
    { value: 'sites', label: 'Selected sites', description: 'Records associated with selected sites.' },
    { value: 'team', label: 'Teams', description: 'Own records plus selected departments and groups.' },
    { value: 'people', label: 'Selected people', description: 'Own records plus selected people.' },
    { value: 'crews', label: 'Selected crews', description: 'Records associated with selected crews.' },
    { value: 'self', label: 'Own records', description: 'Only records owned or submitted by this member.' },
];
export function ScopePicker({ value, onChange, options = {}, name, disabled = false, }) {
    const type = value.type;
    function setType(next) {
        if (!onChange)
            return;
        onChange(emptyScope(next));
    }
    return (_jsxs("fieldset", { disabled: disabled, className: "space-y-3", children: [_jsx("legend", { className: "mb-2 text-sm font-medium text-fg", children: "Data scope" }), name ? _jsx("input", { type: "hidden", name: `${name}.type`, value: type }) : null, _jsx("div", { className: "grid gap-2 sm:grid-cols-2", children: SCOPE_LABELS.map((option) => (_jsxs("label", { className: cn('flex cursor-pointer items-start gap-2 rounded-lg border px-3 py-2.5 transition-colors', type === option.value ? 'border-primary bg-primary-subtle' : 'border-border hover:bg-surface-hover', disabled && 'cursor-not-allowed opacity-60'), children: [_jsx("input", { type: "radio", name: name ? `${name}.kind` : undefined, value: option.value, checked: type === option.value, onChange: () => setType(option.value), className: "mt-0.5 accent-primary" }), _jsxs("span", { children: [_jsx("span", { className: "block text-sm font-medium text-fg", children: option.label }), _jsx("span", { className: "mt-0.5 block text-xs text-fg-muted", children: option.description })] })] }, option.value))) }), _jsx(ScopeValues, { scope: value, onChange: onChange, options: options, name: name, disabled: disabled })] }));
}
function ScopeValues({ scope, onChange, options, name, disabled, }) {
    if (scope.type === 'tenant' || scope.type === 'self')
        return null;
    if (scope.type === 'sites') {
        return _jsx(MultiPicker, { label: "Sites", values: scope.siteIds, options: options.sites ?? [], name: name ? `${name}.siteIds` : undefined, disabled: disabled, onChange: (siteIds) => onChange?.({ type: 'sites', siteIds }) });
    }
    if (scope.type === 'people') {
        return _jsx(MultiPicker, { label: "People", values: scope.personIds, options: options.people ?? [], name: name ? `${name}.personIds` : undefined, disabled: disabled, onChange: (personIds) => onChange?.({ type: 'people', personIds }) });
    }
    if (scope.type === 'crews') {
        return _jsx(MultiPicker, { label: "Crews", values: scope.crewIds, options: options.crews ?? [], name: name ? `${name}.crewIds` : undefined, disabled: disabled, onChange: (crewIds) => onChange?.({ type: 'crews', crewIds }) });
    }
    return (_jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [_jsx(MultiPicker, { label: "Departments", values: scope.departmentIds, options: options.departments ?? [], name: name ? `${name}.departmentIds` : undefined, disabled: disabled, onChange: (departmentIds) => onChange?.({ ...scope, departmentIds }) }), _jsx(MultiPicker, { label: "Groups", values: scope.groupIds, options: options.groups ?? [], name: name ? `${name}.groupIds` : undefined, disabled: disabled, onChange: (groupIds) => onChange?.({ ...scope, groupIds }) })] }));
}
function MultiPicker({ label, values, options, onChange, name, disabled, }) {
    const available = options.filter((option) => !values.includes(option.value));
    return (_jsxs("div", { className: "space-y-2 rounded-lg border border-border bg-bg-subtle p-3", children: [_jsx(Label, { children: label }), values.map((value) => _jsx("input", { type: "hidden", name: name, value: value }, value)), _jsx(SearchSelect, { value: "", onChange: (value) => value && onChange([...values, value]), options: available, placeholder: available.length > 0 ? `Add ${label.toLocaleLowerCase()}…` : `No more ${label.toLocaleLowerCase()}`, disabled: disabled || available.length === 0 }), values.length > 0 ? (_jsx("div", { className: "space-y-1", children: values.map((value) => {
                    const option = options.find((candidate) => candidate.value === value);
                    return (_jsxs("label", { className: "flex items-center gap-2 text-sm text-fg", children: [_jsx(Checkbox, { checked: true, onChange: () => onChange(values.filter((candidate) => candidate !== value)), disabled: disabled }), option?.label ?? value] }, value));
                }) })) : _jsx("p", { className: "text-xs text-fg-subtle", children: "No selection yet." })] }));
}
function emptyScope(type) {
    if (type === 'tenant' || type === 'self')
        return { type };
    if (type === 'sites')
        return { type, siteIds: [] };
    if (type === 'people')
        return { type, personIds: [] };
    if (type === 'crews')
        return { type, crewIds: [] };
    return { type, departmentIds: [], groupIds: [] };
}
//# sourceMappingURL=scope-picker.js.map