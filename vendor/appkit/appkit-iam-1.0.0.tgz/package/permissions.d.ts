import type { PermissionGroup } from './types.js';
export { applyPermissionOverrides, permissionSetCovers } from '@appkit/tenant';
export declare function validatePermissionGroups(groups: readonly PermissionGroup[]): string[];
export declare function permissionCatalogue(groups: readonly PermissionGroup[]): string[];
//# sourceMappingURL=permissions.d.ts.map