'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import * as React from 'react';
import { Badge, Button, Checkbox, Drawer, EmptyState, Input, Label, SearchSelect, Table, TableBody, TableCell, TableHead, TableHeader, TableRow, Textarea, cn, confirmDialog, } from '@appkit/ui';
import { Copy, Plus, Search, Shield, Trash2, UserPlus, UsersRound, X } from 'lucide-react';
import { PermissionMatrix } from './permission-matrix.js';
import { ScopePicker } from './scope-picker.js';
import { collectAll, ServicePagination, SortButton } from './admin-list.js';
import { ActivityList } from './activity-list.js';
/**
 * Production role administration: searchable list, full editor, permission
 * matrix, duplicate/delete protections, member assignment, and scoped access.
 */
export function RolesAdmin({ service, permissionGroups, scopeOptions = {}, title = 'Roles', description = 'Create roles, grant permissions, and control record visibility.', canManage = true, detailTabs = [], onError, }) {
    assertUniqueExtensions(detailTabs, ['details', 'permissions', 'members', 'activity'], 'role');
    const [roles, setRoles] = React.useState([]);
    const [roleOptions, setRoleOptions] = React.useState([]);
    const [members, setMembers] = React.useState([]);
    const [query, setQuery] = React.useState('');
    const deferredQuery = React.useDeferredValue(query);
    const [roleType, setRoleType] = React.useState('');
    const [sort, setSort] = React.useState('name');
    const [direction, setDirection] = React.useState('asc');
    const [page, setPage] = React.useState(1);
    const [total, setTotal] = React.useState(0);
    const [typeCounts, setTypeCounts] = React.useState({ built_in: 0, custom: 0 });
    const [selectedId, setSelectedId] = React.useState(null);
    const [creating, setCreating] = React.useState(false);
    const [editing, setEditing] = React.useState(false);
    const [bulkEditing, setBulkEditing] = React.useState(false);
    const [loading, setLoading] = React.useState(true);
    const [error, setError] = React.useState(null);
    const load = React.useCallback(async () => {
        setLoading(true);
        try {
            const [roleResult, memberResult, allRoles] = await Promise.all([
                service.listRoles({ q: deferredQuery || undefined, type: roleType || undefined, page, perPage: 25, sort, direction }),
                collectMembers(service),
                collectRoles(service),
            ]);
            setRoles(roleResult.rows);
            setRoleOptions(allRoles);
            setTotal(roleResult.total);
            setTypeCounts(roleResult.facets.typeCounts);
            setMembers(memberResult.rows);
            setError(null);
        }
        catch (cause) {
            setError(errorMessage(cause));
            onError?.(cause);
        }
        finally {
            setLoading(false);
        }
    }, [deferredQuery, direction, onError, page, roleType, service, sort]);
    React.useEffect(() => { void load(); }, [load]);
    const selected = roles.find((role) => role.id === selectedId) ?? null;
    React.useEffect(() => { setPage(1); }, [deferredQuery, roleType]);
    function changeSort(next) {
        if (sort === next)
            setDirection((value) => value === 'asc' ? 'desc' : 'asc');
        else {
            setSort(next);
            setDirection('asc');
        }
        setPage(1);
    }
    async function mutate(operation) {
        try {
            setError(null);
            await operation();
            await load();
            return true;
        }
        catch (cause) {
            setError(errorMessage(cause));
            onError?.(cause);
            return false;
        }
    }
    return (_jsxs("div", { className: "flex min-h-0 flex-1 flex-col gap-5", children: [_jsxs("div", { className: "flex flex-wrap items-start justify-between gap-4", children: [_jsxs("div", { children: [_jsx("h1", { className: "text-2xl font-semibold tracking-tight text-fg", children: title }), _jsx("p", { className: "mt-1 max-w-3xl text-sm text-fg-muted", children: description })] }), canManage ? _jsxs("div", { className: "flex flex-wrap gap-2", children: [_jsxs(Button, { variant: "outline", onClick: () => setBulkEditing(true), children: [_jsx(UsersRound, { size: 16 }), "Manage members"] }), _jsxs(Button, { onClick: () => setCreating(true), children: [_jsx(Plus, { size: 16 }), "New role"] })] }) : null] }), _jsxs("div", { className: "flex flex-wrap gap-2", children: [_jsxs("div", { className: "relative min-w-64 flex-1 sm:max-w-md", children: [_jsx(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-fg-subtle" }), _jsx(Input, { value: query, onChange: (event) => setQuery(event.target.value), placeholder: "Search roles\u2026", className: "pl-9" })] }), _jsx(RoleTypeFilters, { value: roleType, counts: typeCounts, onChange: setRoleType })] }), error ? _jsx("div", { role: "alert", className: "rounded-lg border border-danger/30 bg-danger-subtle px-4 py-3 text-sm text-danger", children: error }) : null, _jsx("div", { className: "overflow-x-auto rounded-xl border border-border bg-surface", children: _jsxs(Table, { children: [_jsx(TableHeader, { children: _jsxs(TableRow, { noAnimate: true, children: [_jsx(TableHead, { children: _jsx(SortButton, { label: "Role", active: sort === 'name', direction: direction, onClick: () => changeSort('name') }) }), _jsx(TableHead, { children: "Key" }), _jsx(TableHead, { children: "Description" }), _jsx(TableHead, { children: _jsx(SortButton, { label: "Permissions", active: sort === 'permissions', direction: direction, onClick: () => changeSort('permissions') }) }), _jsx(TableHead, { children: _jsx(SortButton, { label: "Members", active: sort === 'members', direction: direction, onClick: () => changeSort('members') }) }), _jsx(TableHead, { children: "Type" }), _jsx(TableHead, { className: "text-right", children: "Actions" })] }) }), _jsxs(TableBody, { children: [roles.map((role) => (_jsxs(TableRow, { role: "button", tabIndex: 0, className: "cursor-pointer", onClick: () => setSelectedId(role.id), onKeyDown: (event) => {
                                        if (event.key === 'Enter' || event.key === ' ') {
                                            event.preventDefault();
                                            setSelectedId(role.id);
                                        }
                                    }, children: [_jsx(TableCell, { children: _jsx("div", { className: "font-medium text-fg", children: role.name }) }), _jsx(TableCell, { className: "font-mono text-xs text-fg-muted", children: role.key }), _jsx(TableCell, { className: "max-w-md text-fg-muted", children: _jsx("span", { className: "line-clamp-1", children: role.description ?? '—' }) }), _jsx(TableCell, { className: "tabular-nums text-fg-muted", children: role.permissions.length }), _jsx(TableCell, { className: "tabular-nums text-fg-muted", children: role.memberCount }), _jsx(TableCell, { children: _jsx(Badge, { variant: role.isBuiltIn ? 'secondary' : 'outline', children: role.isBuiltIn ? 'Built-in' : 'Custom' }) }), _jsx(TableCell, { className: "text-right", children: _jsx(Button, { size: "sm", variant: "outline", onClick: (event) => { event.stopPropagation(); setSelectedId(role.id); }, children: roleCan(role, 'updateDetails') || roleCan(role, 'updatePermissions') ? 'Edit' : 'View' }) })] }, role.id))), !loading && roles.length === 0 ? (_jsx(TableRow, { noAnimate: true, children: _jsx(TableCell, { colSpan: 7, children: _jsx(EmptyState, { icon: _jsx(Shield, {}), title: "No roles found", description: "Try a different search or create a role.", className: "border-0 bg-transparent py-10 shadow-none" }) }) })) : null] })] }) }), _jsx(ServicePagination, { page: page, perPage: 25, total: total, onPage: setPage }), selected ? (_jsx(RoleDetailDrawer, { role: selected, service: service, members: members, permissionGroups: permissionGroups, scopeOptions: scopeOptions, canManage: canManage, extensions: detailTabs, refresh: load, onClose: () => setSelectedId(null), onEdit: () => setEditing(true), onDuplicate: () => mutate(async () => { const duplicate = await service.duplicateRole(selected.id); setSelectedId(duplicate.id); }), onDelete: async () => {
                    if (!(await confirmDialog({ message: `Delete ${selected.name}? This cannot be undone.`, confirmLabel: 'Delete role', tone: 'danger' })))
                        return;
                    await mutate(async () => { await service.deleteRole(selected.id); setSelectedId(null); });
                }, onAssign: (membershipId, scope) => mutate(() => service.assignRole(membershipId, selected.id, scope)), onUpdateScope: (assignmentId, scope) => mutate(() => service.updateAssignmentScope(assignmentId, scope)), onRemoveAssignment: (assignmentId) => mutate(() => service.removeAssignment(assignmentId)) })) : null, creating || (editing && selected) ? (_jsx(RoleEditorDrawer, { role: editing ? selected : null, permissionGroups: permissionGroups, onClose: () => { setCreating(false); setEditing(false); }, onSave: async (input) => {
                    const saved = await mutate(async () => {
                        const saved = editing && selected
                            ? await service.updateRole(selected.id, input)
                            : await service.createRole(input);
                        setSelectedId(saved.id);
                    });
                    if (!saved)
                        return;
                    setCreating(false);
                    setEditing(false);
                } })) : null, bulkEditing ? _jsx(BulkRoleAssignmentDrawer, { roles: roleOptions, members: members, scopeOptions: scopeOptions, onClose: () => setBulkEditing(false), onSubmit: (input) => mutate(() => service.bulkUpdateRoleAssignments(input)) }) : null] }));
}
function RoleDetailDrawer({ role, service, members, permissionGroups, scopeOptions, canManage, extensions, refresh, onClose, onEdit, onDuplicate, onDelete, onAssign, onUpdateScope, onRemoveAssignment, }) {
    const [tab, setTab] = React.useState('details');
    const [activity, setActivity] = React.useState([]);
    const roleMembers = members.flatMap((member) => {
        const assignment = member.assignments.find((candidate) => candidate.roleId === role.id);
        return assignment ? [{ member, assignment }] : [];
    });
    React.useEffect(() => {
        if (tab !== 'activity')
            return;
        void service.listAuditEvents({ recordType: 'role', recordId: role.id, perPage: 25, sort: 'at', direction: 'desc' }).then((result) => setActivity(result.rows));
    }, [role.id, service, tab]);
    return (_jsxs(Drawer, { open: true, onClose: onClose, size: "xl", title: _jsxs("span", { className: "flex items-center gap-2", children: [role.name, _jsx(Badge, { variant: role.isBuiltIn ? 'secondary' : 'outline', children: role.isBuiltIn ? 'Built-in' : 'Custom' })] }), description: role.description ?? `Role key: ${role.key}`, headerActions: canManage ? _jsxs(_Fragment, { children: [roleCan(role, 'updateDetails') || roleCan(role, 'updatePermissions') ? _jsx(Button, { size: "sm", variant: "outline", onClick: onEdit, children: "Edit" }) : null, roleCan(role, 'duplicate') ? _jsxs(Button, { size: "sm", variant: "outline", onClick: () => void onDuplicate(), children: [_jsx(Copy, { size: 14 }), "Duplicate"] }) : null] }) : undefined, subtabs: _jsx(RoleTabs, { value: tab, onChange: setTab, extensions: extensions }), children: [tab === 'details' ? (_jsxs("div", { className: "space-y-6", children: [_jsxs("dl", { className: "grid gap-4 rounded-xl border border-border bg-bg-subtle p-4 sm:grid-cols-3", children: [_jsx(Metric, { label: "Role key", value: role.key, mono: true }), _jsx(Metric, { label: "Permissions", value: String(role.permissions.length) }), _jsx(Metric, { label: "Members", value: String(role.memberCount) })] }), _jsxs("section", { children: [_jsx("h3", { className: "text-sm font-semibold text-fg", children: "Description" }), _jsx("p", { className: "mt-2 text-sm leading-6 text-fg-muted", children: role.description ?? 'No description provided.' })] }), canManage && roleCan(role, 'delete') ? (_jsxs("section", { className: "rounded-xl border border-danger/30 bg-danger-subtle p-4", children: [_jsx("h3", { className: "text-sm font-semibold text-danger", children: "Delete role" }), _jsx("p", { className: "mt-1 text-sm text-fg-muted", children: "The role can be deleted after all member assignments have been removed." }), _jsxs(Button, { variant: "destructive", size: "sm", className: "mt-3", onClick: () => void onDelete(), children: [_jsx(Trash2, { size: 14 }), "Delete role"] })] })) : null] })) : null, tab === 'permissions' ? _jsx(PermissionMatrix, { groups: permissionGroups, value: role.permissions, readOnly: true }) : null, tab === 'members' ? (_jsx(RoleMembersManager, { role: role, members: roleMembers, candidates: members.filter((member) => memberCan(member, 'manageRoles') && !member.assignments.some((assignment) => assignment.roleId === role.id) && member.status === 'active'), scopeOptions: scopeOptions, canManage: canManage, onAssign: onAssign, onUpdateScope: onUpdateScope, onRemove: onRemoveAssignment })) : null, tab === 'activity' ? _jsx(ActivityList, { events: activity }) : null, extensions.map((extension) => tab === extension.key ? _jsx(React.Fragment, { children: extension.render({ role, service, refresh }) }, extension.key) : null)] }));
}
function RoleEditorDrawer({ role, permissionGroups, onClose, onSave, }) {
    const [name, setName] = React.useState(role?.name ?? '');
    const [key, setKey] = React.useState(role?.key ?? '');
    const [description, setDescription] = React.useState(role?.description ?? '');
    const [permissions, setPermissions] = React.useState(role?.permissions ?? []);
    const [saving, setSaving] = React.useState(false);
    const canSave = !role || roleCan(role, 'updateDetails') || roleCan(role, 'updatePermissions');
    async function submit(event) {
        event.preventDefault();
        setSaving(true);
        try {
            await onSave({ key: key || undefined, name, description: description || null, permissions });
        }
        finally {
            setSaving(false);
        }
    }
    return (_jsx(Drawer, { open: true, stacked: Boolean(role), onClose: onClose, size: "xl", title: role ? `Edit ${role.name}` : 'New role', description: "Name the role and choose the capabilities it grants.", footer: _jsxs("div", { className: "flex justify-end gap-2", children: [_jsx(Button, { variant: "outline", onClick: onClose, children: canSave ? 'Cancel' : 'Close' }), canSave ? _jsx(Button, { type: "submit", form: "appkit-role-editor", disabled: saving || !name.trim(), children: saving ? 'Saving…' : 'Save role' }) : null] }), children: _jsxs("form", { id: "appkit-role-editor", onSubmit: (event) => void submit(event), className: "space-y-6", children: [_jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "iam-role-name", children: "Name" }), _jsx(Input, { id: "iam-role-name", value: name, onChange: (event) => setName(event.target.value), required: true, disabled: Boolean(role && !roleCan(role, 'updateDetails')) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "iam-role-key", children: "Stable key" }), _jsx(Input, { id: "iam-role-key", value: key, onChange: (event) => setKey(event.target.value), placeholder: "Generated from name", disabled: Boolean(role && !roleCan(role, 'updateKey')) })] })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "iam-role-description", children: "Description" }), _jsx(Textarea, { id: "iam-role-description", value: description, onChange: (event) => setDescription(event.target.value), rows: 3, disabled: Boolean(role && !roleCan(role, 'updateDetails')) })] }), _jsx(PermissionMatrix, { groups: permissionGroups, value: permissions, onChange: setPermissions, readOnly: Boolean(role && !roleCan(role, 'updatePermissions')) })] }) }));
}
const BULK_OPERATIONS = [
    { value: 'add', label: 'Add or update', description: 'Keep existing roles and update this role’s access scope.' },
    { value: 'replace', label: 'Replace roles', description: 'Remove existing roles and assign only this role.' },
    { value: 'remove', label: 'Remove role', description: 'Remove this role from the selected members.' },
];
function BulkRoleAssignmentDrawer({ roles, members, scopeOptions, onClose, onSubmit, }) {
    const [operation, setOperation] = React.useState('add');
    const [roleId, setRoleId] = React.useState(roles[0]?.id ?? '');
    const [scope, setScope] = React.useState({ type: 'self' });
    const [query, setQuery] = React.useState('');
    const [selected, setSelected] = React.useState(() => new Set());
    const [confirming, setConfirming] = React.useState(false);
    const [saving, setSaving] = React.useState(false);
    const normalized = query.trim().toLocaleLowerCase();
    const filtered = members.filter((member) => !normalized || `${member.name} ${member.email} ${member.assignments.map((assignment) => assignment.roleName).join(' ')}`.toLocaleLowerCase().includes(normalized));
    const eligible = filtered.filter((member) => memberCan(member, 'manageRoles'));
    const allVisibleSelected = eligible.length > 0 && eligible.every((member) => selected.has(member.id));
    const overLimit = selected.size > 250;
    const selectedRole = roles.find((role) => role.id === roleId);
    function toggleVisible() {
        setSelected((current) => {
            const next = new Set(current);
            for (const member of eligible) {
                if (allVisibleSelected)
                    next.delete(member.id);
                else
                    next.add(member.id);
            }
            return next;
        });
    }
    async function apply() {
        if (!roleId || selected.size === 0 || overLimit)
            return;
        if (operation !== 'add' && !confirming) {
            setConfirming(true);
            return;
        }
        setSaving(true);
        try {
            if (await onSubmit({ operation, roleId, membershipIds: [...selected], scope }))
                onClose();
        }
        finally {
            setSaving(false);
        }
    }
    return (_jsx(Drawer, { open: true, onClose: onClose, size: "2xl", title: "Manage member roles", description: "Apply one role operation to up to 250 members with the same access scope.", footer: _jsxs("div", { className: "flex w-full items-center justify-between gap-3", children: [_jsxs("span", { className: "text-sm text-fg-muted", children: [selected.size, " selected"] }), _jsxs("div", { className: "flex gap-2", children: [_jsx(Button, { variant: "outline", onClick: onClose, children: "Cancel" }), _jsxs(Button, { disabled: !roleId || selected.size === 0 || overLimit || saving, onClick: () => void apply(), children: [_jsx(UsersRound, { size: 14 }), saving ? 'Applying…' : confirming ? 'Confirm change' : 'Apply roles'] })] })] }), children: _jsxs("div", { className: "grid gap-5 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]", children: [_jsxs("div", { className: "space-y-5", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { children: "Role" }), _jsx(SearchSelect, { value: roleId, onChange: (value) => { setRoleId(value); setConfirming(false); }, options: roles.map((role) => ({ value: role.id, label: role.name, hint: role.isBuiltIn ? 'Built-in' : undefined })), placeholder: "Choose a role\u2026" })] }), _jsxs("fieldset", { className: "space-y-2", children: [_jsx("legend", { className: "mb-2 text-sm font-medium text-fg", children: "Operation" }), BULK_OPERATIONS.map((item) => _jsxs("label", { className: cn('flex cursor-pointer gap-3 rounded-lg border px-3 py-2.5 transition-colors', operation === item.value ? 'border-primary bg-primary-subtle' : 'border-border hover:bg-surface-hover'), children: [_jsx("input", { type: "radio", name: "bulk-operation", value: item.value, checked: operation === item.value, onChange: () => { setOperation(item.value); setConfirming(false); }, className: "mt-0.5 accent-primary" }), _jsxs("span", { children: [_jsx("span", { className: "block text-sm font-medium text-fg", children: item.label }), _jsx("span", { className: "mt-0.5 block text-xs text-fg-muted", children: item.description })] })] }, item.value))] }), operation !== 'remove' ? _jsx(ScopePicker, { value: scope, onChange: setScope, options: scopeOptions }) : null, confirming ? _jsxs("div", { role: "alert", className: "rounded-lg border border-warning/30 bg-warning-subtle p-3 text-sm text-fg", children: [_jsx("strong", { className: "block text-warning", children: "Confirm bulk access change" }), _jsxs("span", { className: "mt-1 block text-fg-muted", children: [operation === 'replace' ? 'Replace every existing role' : 'Remove this role', " for ", selected.size, " ", selected.size === 1 ? 'member' : 'members', selectedRole ? ` using “${selectedRole.name}”` : '', "."] })] }) : null] }), _jsxs("div", { className: "min-h-0 space-y-3", children: [_jsxs("div", { className: "relative", children: [_jsx(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-fg-subtle" }), _jsx(Input, { value: query, onChange: (event) => setQuery(event.target.value), placeholder: "Search members or roles\u2026", className: "pl-9" })] }), _jsxs("div", { className: "flex items-center justify-between gap-3 text-xs text-fg-muted", children: [_jsx("button", { type: "button", onClick: toggleVisible, className: "font-medium text-primary hover:underline", children: allVisibleSelected ? 'Clear visible' : 'Select visible' }), _jsxs("span", { children: [filtered.length, " shown"] })] }), _jsx("div", { className: "max-h-[32rem] divide-y divide-border overflow-y-auto rounded-lg border border-border", children: filtered.map((member) => { const allowed = memberCan(member, 'manageRoles'); return _jsxs("label", { className: cn('flex items-start gap-3 px-3 py-2.5', allowed ? 'cursor-pointer hover:bg-surface-hover' : 'cursor-not-allowed bg-bg-subtle opacity-70'), children: [_jsx(Checkbox, { checked: selected.has(member.id), disabled: !allowed, onChange: (event) => setSelected((current) => { const next = new Set(current); if (event.target.checked)
                                            next.add(member.id);
                                        else
                                            next.delete(member.id); return next; }), className: "mt-0.5" }), _jsxs("span", { className: "min-w-0 flex-1", children: [_jsxs("span", { className: "flex items-center gap-1.5 text-sm font-medium text-fg", children: [member.name, member.isCurrentUser ? _jsx(Badge, { variant: "outline", children: "You" }) : null, member.isSuperAdmin ? _jsx(Badge, { variant: "warning", children: "Super-admin" }) : null] }), _jsx("span", { className: "block truncate text-xs text-fg-muted", children: member.email }), _jsx("span", { className: "mt-1 flex flex-wrap gap-1", children: member.assignments.map((assignment) => _jsx(Badge, { variant: "secondary", children: assignment.roleName }, assignment.id)) })] })] }, member.id); }) }), overLimit ? _jsx("p", { role: "alert", className: "text-sm text-danger", children: "Select 250 or fewer members at a time." }) : null] })] }) }));
}
function RoleMembersManager({ role, members, candidates, scopeOptions, canManage, onAssign, onUpdateScope, onRemove, }) {
    const [adding, setAdding] = React.useState(false);
    const [picked, setPicked] = React.useState([]);
    const [scope, setScope] = React.useState({ type: 'tenant' });
    const [editing, setEditing] = React.useState(null);
    const available = candidates.filter((member) => !picked.includes(member.id));
    return (_jsxs("div", { className: "space-y-5", children: [_jsxs("div", { className: "flex items-center justify-between gap-3", children: [_jsxs("p", { className: "text-sm text-fg-muted", children: [members.length, " ", members.length === 1 ? 'member' : 'members', " assigned"] }), canManage && !adding ? _jsxs(Button, { variant: "outline", size: "sm", onClick: () => setAdding(true), children: [_jsx(UserPlus, { size: 14 }), "Add members"] }) : null] }), adding ? (_jsxs("div", { className: "space-y-4 rounded-lg border border-border bg-bg-subtle p-4", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { children: "Members" }), _jsx(SearchSelect, { value: "", onChange: (value) => value && setPicked((current) => [...current, value]), options: available.map((member) => ({ value: member.id, label: member.name, hint: member.email })), placeholder: available.length ? 'Select members…' : 'No available members', disabled: !available.length }), _jsx("div", { className: "flex flex-wrap gap-1.5", children: picked.map((id) => {
                                    const member = candidates.find((candidate) => candidate.id === id);
                                    return member ? _jsxs("span", { className: "inline-flex items-center gap-1 rounded-full bg-primary-subtle py-1 pl-2.5 pr-1 text-xs font-medium text-primary", children: [member.name, _jsx("button", { type: "button", "aria-label": `Remove ${member.name}`, onClick: () => setPicked((current) => current.filter((value) => value !== id)), className: "rounded-full p-0.5 hover:bg-surface-hover", children: _jsx(X, { size: 12 }) })] }, id) : null;
                                }) })] }), _jsx(ScopePicker, { value: scope, onChange: setScope, options: scopeOptions }), _jsxs("div", { className: "flex justify-end gap-2", children: [_jsx(Button, { variant: "ghost", onClick: () => { setAdding(false); setPicked([]); }, children: "Cancel" }), _jsxs(Button, { disabled: !picked.length, onClick: () => void Promise.all(picked.map((id) => onAssign(id, scope))).then((results) => { if (results.every(Boolean)) {
                                    setAdding(false);
                                    setPicked([]);
                                } }), children: [_jsx(Plus, { size: 14 }), "Add ", picked.length || ''] })] })] })) : null, members.length > 0 ? (_jsx("ul", { className: "divide-y divide-border rounded-lg border border-border", children: members.map(({ member, assignment }) => {
                    const locked = !memberCan(member, 'manageRoles');
                    return (_jsxs("li", { className: "px-3 py-3", children: [_jsxs("div", { className: "flex items-start justify-between gap-3", children: [_jsxs("div", { className: "min-w-0", children: [_jsxs("div", { className: "flex flex-wrap items-center gap-1.5", children: [_jsx("span", { className: "truncate text-sm font-medium text-fg", children: member.name }), member.isCurrentUser ? _jsx(Badge, { variant: "outline", children: "You" }) : null, member.isSuperAdmin ? _jsx(Badge, { variant: "warning", children: "Protected" }) : null] }), _jsx("div", { className: "truncate text-xs text-fg-muted", children: member.email }), _jsx("div", { className: "mt-0.5 text-xs text-fg-muted", children: scopeLabel(assignment.scope) })] }), canManage && !locked ? _jsxs("div", { className: "flex shrink-0 gap-1", children: [_jsx(Button, { variant: "ghost", size: "sm", onClick: () => setEditing(editing === assignment.id ? null : assignment.id), children: editing === assignment.id ? 'Cancel' : 'Change scope' }), _jsx(Button, { variant: "ghost", size: "sm", className: "text-danger", onClick: () => void confirmDialog({ message: `Remove ${member.name} from ${role.name}?`, confirmLabel: 'Remove assignment', tone: 'danger' }).then((confirmed) => confirmed ? onRemove(assignment.id) : false), children: "Remove" })] }) : _jsx("span", { className: "text-xs text-fg-subtle", children: "Protected" })] }), editing === assignment.id ? _jsx(AssignmentScopeEditor, { assignmentId: assignment.id, initial: assignment.scope, options: scopeOptions, onSave: async (next) => { if (await onUpdateScope(assignment.id, next))
                                    setEditing(null); } }) : null] }, assignment.id));
                }) })) : _jsx(EmptyState, { icon: _jsx(Shield, {}), title: `No members have ${role.name}`, description: "Add active members to grant this role." })] }));
}
function AssignmentScopeEditor({ assignmentId, initial, options, onSave }) {
    const [scope, setScope] = React.useState(initial);
    return _jsxs("div", { className: "mt-3 space-y-3 rounded-lg border border-border bg-bg-subtle p-3", "data-assignment": assignmentId, children: [_jsx(ScopePicker, { value: scope, onChange: setScope, options: options }), _jsx("div", { className: "flex justify-end", children: _jsx(Button, { size: "sm", onClick: () => void onSave(scope), children: "Save scope" }) })] });
}
function RoleTabs({ value, onChange, extensions }) {
    const items = [{ value: 'details', label: 'Details' }, { value: 'permissions', label: 'Permissions' }, { value: 'members', label: 'Members' }, { value: 'activity', label: 'Activity' }, ...extensions.map((extension) => ({ value: extension.key, label: extension.label }))];
    return _jsx("nav", { className: "-mb-px flex gap-1 overflow-x-auto", "aria-label": "Role sections", children: items.map((item) => _jsx("button", { type: "button", onClick: () => onChange(item.value), className: cn('shrink-0 border-b-2 px-3 py-3 text-sm font-medium transition-colors', value === item.value ? 'border-primary text-primary' : 'border-transparent text-fg-muted hover:border-border-strong hover:text-fg'), children: item.label }, item.value)) });
}
function Metric({ label, value, mono = false }) {
    return _jsxs("div", { children: [_jsx("dt", { className: "text-xs font-medium uppercase tracking-wide text-fg-subtle", children: label }), _jsx("dd", { className: cn('mt-1 text-sm font-semibold text-fg', mono && 'font-mono'), children: value })] });
}
function scopeLabel(scope) {
    if (scope.type === 'tenant')
        return 'All records';
    if (scope.type === 'self')
        return 'Own records';
    if (scope.type === 'sites')
        return `${scope.siteIds.length} selected ${scope.siteIds.length === 1 ? 'site' : 'sites'}`;
    if (scope.type === 'people')
        return `${scope.personIds.length} selected ${scope.personIds.length === 1 ? 'person' : 'people'}`;
    if (scope.type === 'crews')
        return `${scope.crewIds.length} selected ${scope.crewIds.length === 1 ? 'crew' : 'crews'}`;
    return `${scope.departmentIds.length} departments, ${scope.groupIds.length} groups`;
}
function errorMessage(error) {
    return error instanceof Error ? error.message : 'The IAM operation failed.';
}
async function collectMembers(service) {
    const rows = await collectAll((page, perPage) => service.listMembers({ page, perPage, sort: 'name' }));
    return { rows, total: rows.length, page: 1, perPage: rows.length || 1 };
}
function collectRoles(service) {
    return collectAll((page, perPage) => service.listRoles({ page, perPage, sort: 'name' }));
}
function roleCan(role, capability) {
    if (role.capabilities)
        return Boolean(role.capabilities[capability]);
    if (capability === 'updateKey' || capability === 'delete')
        return !role.isBuiltIn;
    return true;
}
function RoleTypeFilters({ value, counts, onChange }) { const filters = [{ value: '', label: 'All', count: counts.built_in + counts.custom }, { value: 'built_in', label: 'Built-in', count: counts.built_in }, { value: 'custom', label: 'Custom', count: counts.custom }]; return _jsx("div", { className: "flex max-w-full overflow-x-auto rounded-lg border border-border bg-surface p-1", "aria-label": "Filter roles by type", children: filters.map((filter) => _jsxs("button", { type: "button", "aria-pressed": value === filter.value, onClick: () => onChange(filter.value), className: cn('flex shrink-0 items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors', value === filter.value ? 'bg-primary-subtle text-primary' : 'text-fg-muted hover:bg-surface-hover hover:text-fg'), children: [_jsx("span", { children: filter.label }), _jsx("span", { className: "tabular-nums text-fg-subtle", children: filter.count })] }, filter.value || 'all')) }); }
function memberCan(member, capability) {
    if (member.capabilities)
        return Boolean(member.capabilities[capability]);
    if (capability === 'updateProfile' || capability === 'resendInvite')
        return !member.isSuperAdmin;
    return !member.isCurrentUser && !member.isSuperAdmin;
}
function assertUniqueExtensions(extensions, reserved, surface) { const keys = new Set(reserved); for (const extension of extensions) {
    if (!extension.key.trim() || keys.has(extension.key))
        throw new Error(`Duplicate or reserved ${surface} detail tab key: ${extension.key || '(empty)'}`);
    keys.add(extension.key);
} }
//# sourceMappingURL=roles-admin.js.map