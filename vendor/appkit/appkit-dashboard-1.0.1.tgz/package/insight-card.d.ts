import { type AnalyticResult, type QueryResult, type VisualizationKey, type VisualizationSettings } from '@appkit/analytics';
export { DashboardMetricCard, DashboardPanel } from './dashboard-primitives.js';
export type { DashboardMetricCardProps, DashboardMetricTone, DashboardPanelProps, } from './dashboard-primitives.js';
export declare function InsightCard({ title, description, result, visualization, settings, className }: {
    title: string;
    description?: string | null;
    result: QueryResult;
    visualization: VisualizationKey;
    settings?: VisualizationSettings;
    className?: string;
}): import("react").JSX.Element;
export declare function InsightResultView({ result, visualization, settings }: {
    result: QueryResult;
    visualization: VisualizationKey;
    settings?: VisualizationSettings;
}): import("react").JSX.Element;
export declare function AdvancedInsightResultView({ result, visualization, settings }: {
    result: AnalyticResult;
    visualization: VisualizationKey;
    settings?: VisualizationSettings;
}): import("react").JSX.Element;
//# sourceMappingURL=insight-card.d.ts.map