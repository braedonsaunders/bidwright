import type { DashboardQuickAction } from './types.js';
export declare function normalizeQuickActions(actions: DashboardQuickAction[], options?: {
    maximum?: number;
}): DashboardQuickAction[];
export declare function reorderQuickActions(actions: DashboardQuickAction[], from: number, to: number): DashboardQuickAction[];
//# sourceMappingURL=quick-actions.d.ts.map