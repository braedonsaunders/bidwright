'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Loader2, Pin, PinOff, Trash2 } from 'lucide-react';
import { Badge, Button, Input, Label, cn } from '@appkit/ui';
import { DashboardGrid } from './dashboard-grid.js';
export function DashboardStudio({ initial, nodes, items, adapter, onRemoved, onSaved, categoryLabels, readOnly = false, className }) {
    const [draft, setDraft] = React.useState(initial);
    const [saveState, setSaveState] = React.useState('saved');
    const [error, setError] = React.useState(null);
    const [busy, setBusy] = React.useState(null);
    const first = React.useRef(true);
    const adapterRef = React.useRef(adapter);
    adapterRef.current = adapter;
    React.useEffect(() => {
        if (readOnly)
            return;
        if (first.current) {
            first.current = false;
            return;
        }
        setSaveState('dirty');
        const timer = window.setTimeout(async () => {
            setSaveState('saving');
            setError(null);
            try {
                const result = await adapterRef.current.save(draft);
                if (result.ok) {
                    setSaveState('saved');
                    onSaved?.(draft);
                }
                else {
                    setSaveState('error');
                    setError(result.error);
                }
            }
            catch (cause) {
                setSaveState('error');
                setError(cause instanceof Error ? cause.message : 'The dashboard could not be saved.');
            }
        }, 600);
        return () => window.clearTimeout(timer);
    }, [draft, onSaved, readOnly]);
    async function run(kind, task, commit) {
        setBusy(kind);
        setError(null);
        try {
            const result = await task();
            if (result.ok)
                commit?.();
            else
                setError(result.error);
        }
        catch (cause) {
            setError(cause instanceof Error ? cause.message : `The dashboard ${kind} operation failed.`);
        }
        finally {
            setBusy(null);
        }
    }
    const nameValid = draft.name.trim().length > 0;
    return (_jsxs("div", { className: cn('flex min-h-0 flex-1 flex-col overflow-hidden', className), children: [_jsxs("header", { className: "shrink-0 border-b border-border bg-surface px-5 py-4", children: [_jsxs("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [_jsxs("div", { className: "min-w-0", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("h1", { className: "truncate text-xl font-semibold text-fg", children: draft.name.trim() || 'Untitled dashboard' }), _jsx(Badge, { variant: draft.status === 'published' ? 'success' : 'outline', children: draft.status === 'published' ? 'Published' : 'Draft' })] }), _jsx("p", { className: "mt-1 text-xs text-fg-muted", children: saveState === 'saving' ? 'Saving changes…' : saveState === 'dirty' ? 'Unsaved changes' : saveState === 'error' ? 'Save failed' : 'All changes saved' })] }), _jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [adapter.pin ? _jsxs(Button, { type: "button", variant: "outline", size: "sm", disabled: readOnly || busy !== null, onClick: () => void run('pin', () => adapter.pin(!draft.pinned, draft), () => setDraft((current) => ({ ...current, pinned: !current.pinned }))), children: [busy === 'pin' ? _jsx(Loader2, { className: "size-4 animate-spin" }) : draft.pinned ? _jsx(PinOff, { size: 14 }) : _jsx(Pin, { size: 14 }), draft.pinned ? 'Unpin' : 'Pin to home'] }) : null, adapter.remove ? _jsxs(Button, { type: "button", variant: "ghost", size: "sm", className: "text-danger", disabled: readOnly || busy !== null, onClick: () => { if (globalThis.confirm('Delete this dashboard?'))
                                            void run('remove', () => adapter.remove(draft), onRemoved); }, children: [_jsx(Trash2, { size: 14 }), "Delete"] }) : null, adapter.publish ? _jsxs(Button, { type: "button", variant: draft.status === 'published' ? 'outline' : 'default', size: "sm", disabled: readOnly || busy !== null || (!nameValid && draft.status !== 'published'), onClick: () => { const published = draft.status !== 'published'; void run('publish', () => adapter.publish(published, draft), () => setDraft((current) => ({ ...current, status: published ? 'published' : 'draft' }))); }, children: [busy === 'publish' ? _jsx(Loader2, { className: "size-4 animate-spin" }) : null, draft.status === 'published' ? 'Unpublish' : 'Publish'] }) : null] })] }), !readOnly ? _jsxs("div", { className: "mt-4 grid gap-3 sm:grid-cols-[minmax(0,20rem)_minmax(0,1fr)]", children: [_jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { htmlFor: "dashboard-name", children: "Name" }), _jsx(Input, { id: "dashboard-name", value: draft.name, onChange: (event) => setDraft((current) => ({ ...current, name: event.target.value })), placeholder: "Operations overview" })] }), _jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { htmlFor: "dashboard-description", children: "Description" }), _jsx(Input, { id: "dashboard-description", value: draft.description ?? '', onChange: (event) => setDraft((current) => ({ ...current, description: event.target.value || null })), placeholder: "Optional" })] })] }) : draft.description ? _jsx("p", { className: "mt-2 text-sm text-fg-muted", children: draft.description }) : null, error ? _jsx("p", { role: "alert", className: "mt-3 text-sm text-danger", children: error }) : null] }), _jsx("main", { className: "app-scroll min-h-0 flex-1 overflow-y-auto bg-bg p-5", children: _jsx(DashboardGrid, { initialLayout: draft.layout, nodes: nodes, items: items, categoryLabels: categoryLabels, mode: readOnly ? 'view' : 'edit', onSave: readOnly ? undefined : async (layout) => {
                        const next = { ...draft, layout };
                        const result = await adapter.save(next);
                        if (result.ok) {
                            setDraft(next);
                            onSaved?.(next);
                        }
                        return result;
                    }, emptyLabel: readOnly ? 'This dashboard has no cards yet.' : 'Add a card to build this dashboard.' }) })] }));
}
//# sourceMappingURL=dashboard-studio.js.map