import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { resolveConditionalStyle } from '@appkit/analytics';
import { cn } from '@appkit/ui';
import { DashboardPanel } from './dashboard-primitives.js';
const SERIES_COLORS = ['var(--color-primary)', 'var(--color-info)', 'var(--color-success)', 'var(--color-warning)', 'var(--color-danger)'];
export { DashboardMetricCard, DashboardPanel } from './dashboard-primitives.js';
export function InsightCard({ title, description, result, visualization, settings, className }) {
    return _jsx(DashboardPanel, { title: title, className: className, children: _jsxs("div", { className: "flex h-full min-h-0 flex-col", children: [description ? _jsx("p", { className: "mb-3 shrink-0 text-xs text-fg-muted", children: description }) : null, _jsx("div", { className: "min-h-0 flex-1", children: _jsx(InsightResultView, { result: result, visualization: visualization, settings: settings }) })] }) });
}
export function InsightResultView({ result, visualization, settings = {} }) {
    if (!result.rows.length)
        return _jsx("div", { className: "grid h-full min-h-32 place-items-center text-sm text-fg-subtle", children: "No data for this query." });
    const dimension = result.columns.find((column) => column.role === 'dimension');
    const measures = result.columns.filter((column) => column.role === 'measure');
    const selected = typeof settings.valueField === 'string' ? result.columns.find((column) => column.key === settings.valueField) : measures[0];
    if (visualization === 'table')
        return _jsx(ResultTable, { result: result });
    if (visualization === 'scalar')
        return _jsx(Scalar, { result: result, column: selected, settings: settings });
    if (visualization === 'progress' || visualization === 'gauge')
        return _jsx(Gauge, { result: result, column: selected, settings: settings, compact: visualization === 'progress' });
    if (visualization === 'pie' || visualization === 'donut')
        return _jsx(Pie, { result: result, dimension: dimension, measure: selected, donut: visualization === 'donut' });
    if (visualization === 'funnel')
        return _jsx(Funnel, { result: result, dimension: dimension, measure: selected });
    if (visualization === 'pivot' || visualization === 'heatmap')
        return _jsx(ResultTable, { result: result });
    return _jsx(Cartesian, { result: result, dimension: dimension, measures: measures, kind: visualization });
}
export function AdvancedInsightResultView({ result, visualization, settings = {} }) {
    if (result.shape === 'pivot')
        return _jsx(PivotResultView, { result: result, heatmap: visualization === 'heatmap', settings: settings });
    const compatible = {
        columns: result.columns.map((column) => ({ key: column.key, label: column.label, role: column.role, semanticType: toSimpleSemanticType(column.semanticType) })),
        rows: result.rows,
        rowCount: result.rowCount,
        truncated: result.truncated,
        durationMs: result.durationMs ?? 0,
    };
    return _jsx(InsightResultView, { result: compatible, visualization: visualization, settings: settings });
}
function ResultTable({ result }) {
    return _jsx("div", { className: "app-scroll h-full overflow-auto rounded-lg border border-border", children: _jsxs("table", { className: "w-full border-collapse text-sm", children: [_jsx("thead", { className: "sticky top-0 bg-bg-subtle", children: _jsx("tr", { children: result.columns.map((column) => _jsx("th", { className: cn('border-b border-border px-3 py-2 text-left text-xs font-semibold text-fg-muted', column.role === 'measure' && 'text-right'), children: column.label }, column.key)) }) }), _jsx("tbody", { className: "divide-y divide-border", children: result.rows.map((row, index) => _jsx("tr", { className: "hover:bg-surface-hover", children: result.columns.map((column) => _jsx("td", { className: cn('px-3 py-2 text-fg', column.role === 'measure' && 'text-right tabular-nums'), children: formatValue(row[column.key], column.semanticType) }, column.key)) }, index)) })] }) });
}
function Scalar({ result, column, settings }) {
    const value = column ? result.rows[0]?.[column.key] : null;
    return _jsxs("div", { className: "flex h-full min-h-28 flex-col items-center justify-center text-center", children: [_jsxs("div", { className: "text-4xl font-semibold tabular-nums text-fg", children: [String(settings.prefix ?? ''), formatValue(value, column?.semanticType), String(settings.suffix ?? '')] }), column ? _jsx("div", { className: "mt-2 text-sm text-fg-muted", children: column.label }) : null] });
}
function Gauge({ result, column, settings, compact }) {
    const value = Number(column ? result.rows[0]?.[column.key] : 0) || 0;
    const goal = Number(settings.goal ?? 100) || 100;
    const percentage = Math.max(0, Math.min(100, value / goal * 100));
    if (compact)
        return _jsxs("div", { className: "flex h-full min-h-24 flex-col justify-center", children: [_jsxs("div", { className: "mb-2 flex items-baseline justify-between", children: [_jsx("span", { className: "text-2xl font-semibold tabular-nums text-fg", children: formatNumber(value) }), _jsxs("span", { className: "text-xs text-fg-muted", children: ["of ", formatNumber(goal)] })] }), _jsx("div", { className: "h-2.5 overflow-hidden rounded-full bg-bg-subtle", children: _jsx("div", { className: "h-full rounded-full bg-primary transition-[width]", style: { width: `${percentage}%` } }) })] });
    return _jsx("div", { className: "grid h-full min-h-36 place-items-center", children: _jsx("div", { className: "relative grid size-36 place-items-center rounded-full", style: { background: `conic-gradient(var(--color-primary) ${percentage}%, var(--color-bg-subtle) 0)` }, children: _jsx("div", { className: "grid size-28 place-items-center rounded-full bg-surface text-center", children: _jsxs("div", { children: [_jsx("div", { className: "text-2xl font-semibold tabular-nums", children: formatNumber(value) }), _jsxs("div", { className: "text-xs text-fg-muted", children: [Math.round(percentage), "%"] })] }) }) }) });
}
function Cartesian({ result, dimension, measures, kind }) {
    if (!dimension || !measures.length)
        return _jsx("div", { className: "grid h-full place-items-center text-sm text-fg-subtle", children: "Add a dimension and measure to chart." });
    const rows = result.rows.slice(0, 20);
    const values = rows.flatMap((row) => measures.map((measure) => Number(row[measure.key]) || 0));
    const maximum = Math.max(...values.map(Math.abs), 1);
    if (kind === 'row')
        return _jsx("div", { className: "app-scroll h-full space-y-2 overflow-auto pr-2", children: rows.map((row, index) => _jsxs("div", { className: "grid grid-cols-[minmax(80px,1fr)_3fr] items-center gap-3", children: [_jsx("div", { className: "truncate text-xs text-fg-muted", children: formatValue(row[dimension.key], dimension.semanticType) }), _jsx("div", { className: "flex h-6 items-center gap-1", children: measures.map((measure, series) => _jsx("div", { className: "h-4 rounded-sm", title: `${measure.label}: ${formatValue(row[measure.key], measure.semanticType)}`, style: { width: `${Math.abs(Number(row[measure.key]) || 0) / maximum * 100}%`, background: SERIES_COLORS[series % SERIES_COLORS.length] } }, measure.key)) })] }, index)) });
    const width = 720, height = 260, padding = 28;
    const plotWidth = width - padding * 2, plotHeight = height - padding * 2;
    if (kind === 'scatter') {
        const [xMeasure, yMeasure] = measures;
        if (!xMeasure || !yMeasure)
            return _jsx("div", { className: "grid h-full place-items-center text-sm text-fg-subtle", children: "Add two measures to plot a scatter chart." });
        const xValues = rows.map((row) => Number(row[xMeasure.key]) || 0), yValues = rows.map((row) => Number(row[yMeasure.key]) || 0);
        const xMax = Math.max(...xValues.map(Math.abs), 1), yMax = Math.max(...yValues.map(Math.abs), 1);
        return _jsxs("svg", { viewBox: `0 0 ${width} ${height}`, className: "h-full min-h-40 w-full", role: "img", "aria-label": "Scatter chart", children: [_jsx("line", { x1: padding, y1: height - padding, x2: width - padding, y2: height - padding, stroke: "var(--color-border)" }), _jsx("line", { x1: padding, y1: padding, x2: padding, y2: height - padding, stroke: "var(--color-border)" }), rows.map((row, index) => _jsx("circle", { cx: padding + xValues[index] / xMax * plotWidth, cy: padding + plotHeight - yValues[index] / yMax * plotHeight, r: "5", fill: "var(--color-primary)", opacity: "0.8", children: _jsx("title", { children: `${dimension ? row[dimension.key] : index + 1}: ${xValues[index]}, ${yValues[index]}` }) }, index))] });
    }
    const points = (measure) => rows.map((row, index) => ({ x: padding + (rows.length === 1 ? plotWidth / 2 : index / (rows.length - 1) * plotWidth), y: padding + plotHeight - (Number(row[measure.key]) || 0) / maximum * plotHeight }));
    return _jsxs("svg", { viewBox: `0 0 ${width} ${height}`, className: "h-full min-h-40 w-full", role: "img", "aria-label": `${kind} chart`, children: [_jsx("line", { x1: padding, y1: padding + plotHeight, x2: padding + plotWidth, y2: padding + plotHeight, stroke: "var(--color-border)" }), kind === 'bar' || kind === 'combo' ? rows.map((row, index) => measures.map((measure, series) => { if (kind === 'combo' && series > 0)
                return null; const group = plotWidth / Math.max(rows.length, 1), barWidth = Math.max(3, group / Math.max(kind === 'combo' ? 1 : measures.length, 1) * .72); const value = Math.abs(Number(row[measure.key]) || 0); return _jsx("rect", { x: padding + index * group + (kind === 'combo' ? 0 : series * barWidth) + group * .12, y: padding + plotHeight - value / maximum * plotHeight, width: barWidth, height: value / maximum * plotHeight, rx: 3, fill: SERIES_COLORS[series % SERIES_COLORS.length] }, `${index}-${measure.key}`); })) : null, kind !== 'bar' ? measures.map((measure, series) => { if (kind === 'combo' && series === 0)
                return null; const seriesPoints = points(measure); const path = seriesPoints.map((point, index) => `${index ? 'L' : 'M'} ${point.x} ${point.y}`).join(' '); return _jsxs("g", { children: [kind === 'area' ? _jsx("path", { d: `${path} L ${seriesPoints.at(-1)?.x} ${padding + plotHeight} L ${seriesPoints[0]?.x} ${padding + plotHeight} Z`, fill: SERIES_COLORS[series % SERIES_COLORS.length], opacity: "0.16" }) : null, _jsx("path", { d: path, fill: "none", stroke: SERIES_COLORS[series % SERIES_COLORS.length], strokeWidth: "3", strokeLinecap: "round", strokeLinejoin: "round" }), seriesPoints.map((point, index) => _jsx("circle", { cx: point.x, cy: point.y, r: "3", fill: SERIES_COLORS[series % SERIES_COLORS.length] }, index))] }, measure.key); }) : null, rows.map((row, index) => _jsx("text", { x: padding + (index + .5) / rows.length * plotWidth, y: height - 7, textAnchor: "middle", fontSize: "9", fill: "var(--color-fg-subtle)", children: String(row[dimension.key] ?? '').slice(0, 12) }, index))] });
}
function Funnel({ result, dimension, measure }) {
    if (!dimension || !measure)
        return _jsx("div", { className: "grid h-full place-items-center text-sm text-fg-subtle", children: "Add one dimension and one measure." });
    const rows = result.rows.slice(0, 10), maximum = Math.max(...rows.map((row) => Math.abs(Number(row[measure.key]) || 0)), 1);
    return _jsx("div", { className: "flex h-full flex-col items-center justify-center gap-1.5", children: rows.map((row, index) => { const value = Math.abs(Number(row[measure.key]) || 0); return _jsx("div", { className: "flex h-8 items-center justify-center rounded-md bg-primary-subtle px-3 text-xs text-primary", style: { width: `${Math.max(24, value / maximum * 100)}%` }, title: `${dimension.label}: ${String(row[dimension.key])}`, children: _jsxs("span", { className: "truncate", children: [formatValue(row[dimension.key], dimension.semanticType), " \u00B7 ", formatValue(row[measure.key], measure.semanticType)] }) }, index); }) });
}
function PivotResultView({ result, heatmap, settings }) {
    const rules = Array.isArray(settings.conditionalFormats) ? settings.conditionalFormats : [];
    const showRowTotals = settings.showRowTotals === true;
    return _jsx("div", { className: "app-scroll h-full overflow-auto rounded-lg border border-border", children: _jsxs("table", { className: "min-w-full border-collapse text-sm", children: [_jsx("thead", { className: "sticky top-0 z-10 bg-bg-subtle", children: _jsxs("tr", { children: [_jsx("th", { className: "border-b border-r border-border px-3 py-2 text-left text-xs font-semibold text-fg-muted", children: result.rowDimensions.map((column) => column.label).join(' · ') }), result.columnKeys.map((key, index) => _jsx("th", { className: "border-b border-border px-3 py-2 text-right text-xs font-semibold text-fg-muted", children: key.labels.join(' · ') }, index)), showRowTotals ? _jsx("th", { className: "border-b border-l border-border px-3 py-2 text-right text-xs font-semibold text-fg-muted", children: "Total" }) : null] }) }), _jsx("tbody", { children: result.rowKeys.map((rowKey, rowIndex) => { const values = result.columnKeys.map((_, columnIndex) => Number(result.cells[rowIndex]?.[columnIndex]?.[result.valueMeasures[0]?.key ?? '']) || 0); return _jsxs("tr", { className: "border-b border-border-subtle last:border-0", children: [_jsx("th", { className: "border-r border-border px-3 py-2 text-left font-medium text-fg", children: rowKey.labels.join(' · ') }), values.map((value, columnIndex) => { const style = heatmap ? resolveConditionalStyle(value, result.valueMeasures[0]?.key ?? '', rules.length ? rules : [{ type: 'scale', column: result.valueMeasures[0]?.key ?? '', min: Math.min(...values), max: Math.max(...values), lowTone: 'info', highTone: 'primary' }]) : {}; return _jsx("td", { className: cn('px-3 py-2 text-right tabular-nums text-fg', style.className), style: style.background ? { background: style.background } : undefined, children: formatNumber(value) }, columnIndex); }), showRowTotals ? _jsx("td", { className: "border-l border-border px-3 py-2 text-right font-semibold tabular-nums text-fg", children: formatNumber(values.reduce((sum, value) => sum + value, 0)) }) : null] }, rowIndex); }) })] }) });
}
function toSimpleSemanticType(type) {
    if (type === 'currency')
        return 'currency';
    if (type === 'measure' || type === 'percentage' || type === 'lat' || type === 'lng')
        return 'number';
    if (type === 'temporal')
        return 'date';
    if (type === 'category')
        return 'category';
    return 'text';
}
function Pie({ result, dimension, measure, donut }) {
    if (!dimension || !measure)
        return _jsx("div", { className: "grid h-full place-items-center text-sm text-fg-subtle", children: "Add one dimension and one measure." });
    const rows = result.rows.slice(0, 12);
    const values = rows.map((row) => Math.max(0, Number(row[measure.key]) || 0));
    const total = values.reduce((sum, value) => sum + value, 0) || 1;
    let offset = 0;
    return _jsxs("div", { className: "flex h-full min-h-40 items-center justify-center gap-5", children: [_jsx("svg", { viewBox: "0 0 120 120", className: "size-40 shrink-0 -rotate-90", role: "img", "aria-label": `${donut ? 'Donut' : 'Pie'} chart`, children: values.map((value, index) => { const fraction = value / total; const dash = `${fraction * 100} ${100 - fraction * 100}`; const current = offset; offset += fraction * 100; return _jsx("circle", { cx: "60", cy: "60", r: "45", fill: "none", stroke: SERIES_COLORS[index % SERIES_COLORS.length], strokeWidth: donut ? 20 : 45, pathLength: "100", strokeDasharray: dash, strokeDashoffset: -current }, index); }) }), _jsx("div", { className: "min-w-0 space-y-1.5", children: rows.slice(0, 6).map((row, index) => _jsxs("div", { className: "flex items-center gap-2 text-xs", children: [_jsx("span", { className: "size-2.5 rounded-sm", style: { background: SERIES_COLORS[index % SERIES_COLORS.length] } }), _jsx("span", { className: "max-w-32 truncate text-fg-muted", children: formatValue(row[dimension.key], dimension.semanticType) }), _jsx("span", { className: "ml-auto tabular-nums text-fg", children: formatValue(row[measure.key], measure.semanticType) })] }, index)) })] });
}
function formatNumber(value) { return new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 }).format(value); }
function formatValue(value, semanticType) {
    if (value == null)
        return '—';
    if (semanticType === 'currency')
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(Number(value));
    if (semanticType === 'number')
        return formatNumber(Number(value));
    if (semanticType === 'date') {
        const date = new Date(String(value));
        return Number.isNaN(date.valueOf()) ? String(value) : date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    }
    if (semanticType === 'boolean')
        return value ? 'Yes' : 'No';
    return String(value);
}
//# sourceMappingURL=insight-card.js.map