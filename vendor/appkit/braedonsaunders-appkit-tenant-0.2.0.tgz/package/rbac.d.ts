import type { PgDatabase } from 'drizzle-orm/pg-core';
import type { PgQueryResultHKT } from 'drizzle-orm/pg-core/session';
import { type RoleScope } from '@braedonsaunders/appkit-db';
export declare function permissionSetCovers(permissions: ReadonlySet<string>, permission: string): boolean;
/** Deny wins, including when a concrete deny carves a key out of a wildcard. */
export declare function applyPermissionOverrides(base: Iterable<string>, overrides: Iterable<{
    permission: string;
    effect: 'grant' | 'deny';
}>, catalogue: Iterable<string>): Set<string>;
/** The minimal shape `can`/`assertCan` need — a resolved request context. */
export type AccessCtx = {
    isSuperAdmin: boolean;
    permissions: Set<string>;
    scopes: RoleScope[];
};
export declare class ForbiddenError extends Error {
    readonly permission: string;
    readonly name = "ForbiddenError";
    constructor(permission: string);
}
export declare class ImpersonationBlockedError extends Error {
    readonly action?: string | undefined;
    readonly name = "ImpersonationBlockedError";
    constructor(action?: string | undefined);
}
export declare function assertNotImpersonating(ctx: {
    impersonation?: unknown | null;
}, action?: string): void;
/** Does this context hold `perm`? Super-admin holds everything; `module.*`
 *  wildcards grant any `module.x`; `.read.{all,site,self}` tiers cascade. */
export declare function can(ctx: AccessCtx, perm: string): boolean;
export declare function assertCan(ctx: AccessCtx, perm: string): void;
/** Narrow a role-assignment list to a single "switched-into" role, if set. */
export declare function effectiveRoleAssignments<T extends {
    roleId: string;
}>(activeRoleId: string | null | undefined, assignments: readonly T[]): T[];
export type MembershipAccessOptions = {
    /**
     * The application's complete permission key list. It is only required when
     * a concrete deny must carve one permission out of a wildcard role grant.
     */
    permissionCatalogue?: readonly string[];
};
/** Database-neutral Postgres contract shared by Drizzle's node-postgres and postgres-js drivers. */
export type MembershipAccessDatabase<TQueryResult extends PgQueryResultHKT = PgQueryResultHKT, TSchema extends Record<string, unknown> = Record<string, never>> = PgDatabase<TQueryResult, TSchema>;
export declare class PermissionCatalogueRequiredError extends Error {
    readonly name = "PermissionCatalogueRequiredError";
    constructor();
}
/**
 * Bind application-owned permission keys once while retaining the production
 * `(tx, membershipId, activeRoleId?)` resolver contract at every call site.
 */
export declare function createMembershipAccessResolver(options: MembershipAccessOptions): <TQueryResult extends PgQueryResultHKT, TSchema extends Record<string, unknown>>(tx: MembershipAccessDatabase<TQueryResult, TSchema>, membershipId: string, activeRoleId?: string | null) => Promise<{
    permissions: Set<string>;
    scopes: RoleScope[];
    appliedRoleId: string | null;
}>;
/**
 * Resolve a membership's effective permission set + scopes: the union of its
 * assigned roles' permission keys, plus per-user grants, minus per-user denies.
 * The first three arguments preserve the production source contract exactly.
 */
export declare function resolveMembershipAccess<TQueryResult extends PgQueryResultHKT, TSchema extends Record<string, unknown>>(tx: MembershipAccessDatabase<TQueryResult, TSchema>, membershipId: string, activeRoleId?: string | null, options?: MembershipAccessOptions): Promise<{
    permissions: Set<string>;
    scopes: RoleScope[];
    appliedRoleId: string | null;
}>;
export declare function canSeeSite(ctx: AccessCtx, siteId: string | null): boolean;
/** The single widest scope the context holds. */
export declare function widestScope(ctx: AccessCtx): RoleScope;
/** Concise alias retained for compatible application adapters. */
export declare const selfOnlyFilter: typeof widestScope;
export type TemplateAccessDescriptor = {
    status: 'draft' | 'published' | 'archived';
    allowedRoles: string[] | null | undefined;
    deletedAt?: Date | null;
};
export type TemplateAccessMode = 'operate' | 'browse-records' | 'builder-edit';
export type ResponsePayloadAccessDescriptor = {
    status: string;
    locked: boolean;
    submittedBy: string | null;
};
export declare function isTemplateBuilder(ctx: AccessCtx): boolean;
export declare function canAccessTemplate(ctx: AccessCtx, template: TemplateAccessDescriptor, effectiveRoleKeys: ReadonlySet<string>, mode: TemplateAccessMode): boolean;
export declare function canEditResponsePayload(ctx: AccessCtx & {
    membership: {
        id: string;
    } | null;
}, response: ResponsePayloadAccessDescriptor): boolean;
//# sourceMappingURL=rbac.d.ts.map