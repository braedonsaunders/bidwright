# @braedonsaunders/appkit-tenant

Request context, tenant-bound DB helper, and RBAC (permissions, roles, super-admin) on top of @braedonsaunders/appkit-db.

## Install

```bash
pnpm add @braedonsaunders/appkit-tenant
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
