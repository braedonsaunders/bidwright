import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
import type { AppkitDb, RoleScope } from '@braedonsaunders/appkit-db';
import type { AppLocale } from '@braedonsaunders/appkit-i18n';
export type TenantDatabase<TSchema extends Record<string, unknown> = Record<string, never>> = NodePgDatabase<TSchema>;
export type ImpersonationInfo = {
    actor: {
        userId: string;
        name: string;
        email: string;
    };
    tenantId: string;
    expiresAt: Date;
};
export type RequestContextCore<TDatabase = TenantDatabase> = {
    userId: string;
    tenantId: string;
    isSuperAdmin: boolean;
    /** IANA timezone for the active identity. */
    timezone: string;
    /** Effective locale plus the tenant policy that produced it. */
    locale: AppLocale;
    defaultLocale: AppLocale;
    enabledLocales: readonly AppLocale[];
    localeOverride: AppLocale | null;
    membership: {
        id: string;
        displayName: string;
    } | null;
    permissions: Set<string>;
    scopes: RoleScope[];
    /** The single role a multi-role user switched into (narrows permissions/scopes). */
    activeRoleId?: string | null;
    /** Present only while a privileged actor is viewing the app as another user. */
    impersonation?: ImpersonationInfo | null;
    /** Present for public requests authenticated by an application API key. */
    apiKey?: {
        id: string;
        name: string;
    } | null;
    /** Tenant-bound DB helper. Every callback runs inside the selected tenant's RLS scope. */
    db: <T>(fn: (db: TDatabase) => Promise<T>) => Promise<T>;
};
/**
 * Resolved auth + tenant context for a request. Applications add domain-owned
 * identity data through `TExtension` instead of changing or forking the shared
 * context (for example, a linked employee id or jurisdiction terminology).
 */
export type RequestContext<TExtension extends object = object, TDatabase = TenantDatabase> = RequestContextCore<TDatabase> & TExtension;
export type SuperAdminContext<TDatabase = TenantDatabase> = {
    userId: string;
    isSuperAdmin: true;
    /** Cross-tenant DB helper. Use intentionally. */
    db: <T>(fn: (db: TDatabase) => Promise<T>) => Promise<T>;
};
export type RequestContextArgs<TExtension extends object = object> = Omit<RequestContextCore<never>, 'db'> & TExtension;
export type TenantContextRuntime<TDatabase> = {
    withTenant: <T>(baseDb: TDatabase, tenantId: string, fn: (db: TDatabase) => Promise<T>) => Promise<T>;
    withSuperAdmin: <T>(baseDb: TDatabase, fn: (db: TDatabase) => Promise<T>) => Promise<T>;
};
/**
 * Bind AppKit's portable request-context contract to any tenant-aware database
 * runtime. A consuming application can keep its existing `makeTenantContext`
 * call shape while its database package owns the RLS implementation.
 */
export declare function createTenantContextFactory<TDatabase>(runtime: TenantContextRuntime<TDatabase>): {
    makeTenantContext: <TExtension extends object = object>(baseDb: TDatabase, args: RequestContextArgs<TExtension>) => RequestContext<TExtension, TDatabase>;
    makeSuperAdminContext: (baseDb: TDatabase, userId: string) => SuperAdminContext<TDatabase>;
};
/** Build a request context over `@braedonsaunders/appkit-db`. */
export declare function makeTenantContext<TSchema extends Record<string, unknown>, TExtension extends object = object>(appkit: AppkitDb<TSchema>, args: RequestContextArgs<TExtension>): RequestContext<TExtension, TenantDatabase<TSchema>>;
export declare function makeSuperAdminContext<TSchema extends Record<string, unknown>>(appkit: AppkitDb<TSchema>, userId: string): SuperAdminContext<TenantDatabase<TSchema>>;
//# sourceMappingURL=context.d.ts.map