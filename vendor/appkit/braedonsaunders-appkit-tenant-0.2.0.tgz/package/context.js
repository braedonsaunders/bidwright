/**
 * Bind AppKit's portable request-context contract to any tenant-aware database
 * runtime. A consuming application can keep its existing `makeTenantContext`
 * call shape while its database package owns the RLS implementation.
 */
export function createTenantContextFactory(runtime) {
    function makeContext(baseDb, args) {
        return {
            ...args,
            db: (fn) => runtime.withTenant(baseDb, args.tenantId, fn),
        };
    }
    function makeAdminContext(baseDb, userId) {
        return {
            userId,
            isSuperAdmin: true,
            db: (fn) => runtime.withSuperAdmin(baseDb, fn),
        };
    }
    return { makeTenantContext: makeContext, makeSuperAdminContext: makeAdminContext };
}
/** Build a request context over `@braedonsaunders/appkit-db`. */
export function makeTenantContext(appkit, args) {
    return {
        ...args,
        db: (fn) => appkit.withTenant(args.tenantId, () => fn(appkit.db)),
    };
}
export function makeSuperAdminContext(appkit, userId) {
    return {
        userId,
        isSuperAdmin: true,
        db: (fn) => appkit.withSuperAdmin(fn),
    };
}
//# sourceMappingURL=context.js.map