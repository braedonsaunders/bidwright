# @braedonsaunders/appkit-tokens

The design foundation — semantic color, radius, elevation, and motion tokens. Light/dark. Tailwind v4, CSS-first.

## Install

```bash
pnpm add @braedonsaunders/appkit-tokens
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
